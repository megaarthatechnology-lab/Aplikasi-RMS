
import React, { createContext, useContext, useState, useEffect } from 'react';
import { authService } from '@/lib/auth';

const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session on mount
    const currentUser = authService.getCurrentUser();
    setUser(currentUser);
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    const result = authService.login(email, password);
    if (result.success) {
      setUser(result.user);
    }
    return result;
  };

  const loginWithGoogle = async () => {
    const result = authService.loginWithGoogle();
    if (result.success) {
      setUser(result.user);
    }
    return result;
  };

  const register = async (name, email, password) => {
    const result = authService.register(name, email, password);
    if (result.success) {
      setUser(result.user);
    }
    return result;
  };

  const logout = () => {
    authService.logout();
    setUser(null);
  };

  const value = {
    user,
    loading,
    login,
    loginWithGoogle,
    register,
    logout,
    isAuthenticated: !!user
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
