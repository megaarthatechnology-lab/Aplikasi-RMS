import React from 'react';
import { motion } from 'framer-motion';

const DepartmentChart = ({ data }) => {
  const maxCount = Math.max(...data.map(d => d.count), 0);

  return (
    <div className="glass-effect p-6 rounded-xl">
      <h3 className="text-xl font-semibold text-white mb-4">Karyawan per Departemen</h3>
      <div className="space-y-4">
        {data.map((item, index) => (
          <div key={item.name} className="flex items-center">
            <div className="w-32 text-sm text-slate-300 truncate">{item.name}</div>
            <div className="flex-1 bg-slate-700 rounded-full h-6 relative">
              <motion.div
                className="absolute top-0 left-0 h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full flex items-center justify-end pr-2"
                initial={{ width: 0 }}
                animate={{ width: `${(item.count / (maxCount || 1)) * 100}%` }}
                transition={{ duration: 0.5, delay: 0.2 + index * 0.1, ease: "easeOut" }}
              >
                <span className="text-white font-bold text-xs">{item.count}</span>
              </motion.div>
            </div>
          </div>
        ))}
         {data.length === 0 && (
          <p className="text-center text-slate-400 py-8">Tidak ada data departemen untuk ditampilkan.</p>
        )}
      </div>
    </div>
  );
};

export default DepartmentChart;