import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency } from '@/lib/utils';
import { getRawMaterialStatusBadge } from '@/lib/raw-materials-utils.jsx';

const RawMaterialsTable = ({ materials, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Inventaris Bahan Baku</CardTitle>
        <CardDescription>Menampilkan {materials.length} jenis bahan baku yang sesuai.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nama Bahan</TableHead>
                <TableHead>Stok</TableHead>
                <TableHead>Supplier & Biaya</TableHead>
                <TableHead>Info Tambahan</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {materials.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada data bahan baku</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan data baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                materials.map((m) => (
                  <TableRow key={m.id}>
                    <TableCell>
                      <div className="font-bold">{m.materialName}</div>
                      {m.description && <div className="text-xs text-slate-400 mt-1 max-w-xs truncate" title={m.description}>{m.description}</div>}
                    </TableCell>
                    <TableCell>
                        <div className="font-mono font-semibold text-lg">{m.quantityInStock}</div>
                        <div className="text-sm text-slate-400">{m.unit}</div>
                    </TableCell>
                    <TableCell>
                        <div className="font-medium">{m.supplierName}</div>
                        <div className="text-sm text-slate-400">{formatCurrency(m.costPerUnit)} / {m.unit}</div>
                    </TableCell>
                    <TableCell>
                        <div>Batas Order: <span className="font-semibold">{m.reorderLevel} {m.unit}</span></div>
                        <div className="text-sm text-slate-400">Pembelian Akhir: {format(new Date(m.lastPurchaseDate), 'dd MMM yyyy')}</div>
                    </TableCell>
                    <TableCell>{getRawMaterialStatusBadge(m.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(m)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(m.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default RawMaterialsTable;