import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { rawMaterialUnitOptions } from '@/lib/raw-materials-utils.jsx';
import { format } from 'date-fns';

const RawMaterialFormDialog = ({ isOpen, onClose, onSave, material, suppliers }) => {
  const getInitialFormData = () => ({
    materialName: '',
    quantityInStock: '',
    unit: '',
    supplierName: '',
    costPerUnit: '',
    lastPurchaseDate: format(new Date(), 'yyyy-MM-dd'),
    reorderLevel: '',
    description: '',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (material) {
        setFormData({
          ...material,
          quantityInStock: material.quantityInStock.toString(),
          costPerUnit: material.costPerUnit.toString(),
          reorderLevel: material.reorderLevel.toString(),
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [material, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredFields = ['materialName', 'quantityInStock', 'unit', 'supplierName', 'costPerUnit', 'lastPurchaseDate', 'reorderLevel'];
    for (const field of requiredFields) {
        const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
        if (formData[field] === '' || formData[field] === null) {
            toast({ title: '⚠️ Data Tidak Lengkap', description: `Mohon lengkapi field "${fieldName}" yang wajib diisi.`, variant: 'destructive' });
            return;
        }
    }
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{material ? 'Edit Bahan Baku' : 'Tambah Bahan Baku Baru'}</DialogTitle>
          <DialogDescription>{material ? 'Perbarui detail inventaris bahan baku.' : 'Tambahkan bahan baku baru ke inventaris.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div className="space-y-2">
                <Label htmlFor="materialName">Nama Bahan Baku *</Label>
                <Input id="materialName" value={formData.materialName} onChange={handleInputChange} placeholder="Pasir Beton, Semen Tipe I..." required />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="quantityInStock">Stok Saat Ini *</Label>
                    <Input id="quantityInStock" type="number" value={formData.quantityInStock} onChange={handleInputChange} placeholder="50" required min="0" step="any"/>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="unit">Satuan *</Label>
                    <Select value={formData.unit} onValueChange={(value) => handleSelectChange('unit', value)}>
                        <SelectTrigger><SelectValue placeholder="Pilih Satuan" /></SelectTrigger>
                        <SelectContent>{rawMaterialUnitOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="reorderLevel">Batas Order Ulang *</Label>
                    <Input id="reorderLevel" type="number" value={formData.reorderLevel} onChange={handleInputChange} placeholder="20" required min="0" step="any"/>
                </div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="supplierName">Nama Supplier *</Label>
                  <Input id="supplierName" value={formData.supplierName} onChange={handleInputChange} placeholder="PT. Sumber Batu Alam" required />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="costPerUnit">Biaya per Satuan (IDR) *</Label>
                    <Input id="costPerUnit" type="number" value={formData.costPerUnit} onChange={handleInputChange} placeholder="250000" required min="0" />
                </div>
            </div>
            <div className="space-y-2">
                <Label htmlFor="lastPurchaseDate">Tanggal Pembelian Terakhir *</Label>
                <Input id="lastPurchaseDate" type="date" value={formData.lastPurchaseDate} onChange={handleInputChange} required />
            </div>
            <div className="space-y-2">
                <Label htmlFor="description">Deskripsi</Label>
                <Textarea id="description" value={formData.description} onChange={handleInputChange} placeholder="Catatan tambahan mengenai bahan baku..." />
            </div>
            <DialogFooter className="pt-4">
                <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{material ? 'Perbarui Bahan' : 'Simpan Bahan'}</Button>
            </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default RawMaterialFormDialog;