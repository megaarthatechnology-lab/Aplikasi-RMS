import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, RotateCcw } from 'lucide-react';
import { Label } from '@/components/ui/label';

const FilterControls = ({ filters, setFilters, uniqueFilterData }) => {
  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFilters(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value === 'all' ? '' : value }));
  };

  const resetFilters = () => {
    setFilters({
      assetName: '',
      assetCode: '',
      currentLocation: '',
      building: '',
      responsiblePerson: '',
    });
  };

  return (
    <Card className="glass-effect">
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 items-end">
          <div className="xl:col-span-1">
            <Label htmlFor="assetName">Cari Nama Aset</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="assetName"
                placeholder="Excavator..."
                value={filters.assetName}
                onChange={handleInputChange}
                className="pl-10"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="assetCode">Kode Aset</Label>
            <Input
              id="assetCode"
              placeholder="EXC-001..."
              value={filters.assetCode}
              onChange={handleInputChange}
            />
          </div>
          <div>
            <Label htmlFor="currentLocation">Lokasi</Label>
            <Select value={filters.currentLocation} onValueChange={(value) => handleSelectChange('currentLocation', value)}>
              <SelectTrigger><SelectValue placeholder="Semua Lokasi"/></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Lokasi</SelectItem>
                {uniqueFilterData.currentLocations.map(loc => <SelectItem key={loc} value={loc}>{loc}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="building">Gedung/Lantai</Label>
            <Select value={filters.building} onValueChange={(value) => handleSelectChange('building', value)}>
              <SelectTrigger><SelectValue placeholder="Semua Gedung"/></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Gedung</SelectItem>
                {uniqueFilterData.buildings.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="responsiblePerson">Penanggung Jawab</Label>
            <Select value={filters.responsiblePerson} onValueChange={(value) => handleSelectChange('responsiblePerson', value)}>
              <SelectTrigger><SelectValue placeholder="Semua Orang"/></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Orang</SelectItem>
                {uniqueFilterData.responsiblePersons.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex justify-end">
            <Button variant="outline" onClick={resetFilters} className="w-full sm:w-auto">
              <RotateCcw className="mr-2 h-4 w-4" /> Reset
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterControls;