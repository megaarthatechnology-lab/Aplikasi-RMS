import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { assetCategories, conditionStatusOptions, assetStatusOptions } from '@/lib/asset-list-utils.jsx';
import { format } from 'date-fns';

const AssetFormDialog = ({ isOpen, onClose, onSave, asset }) => {
  const getInitialFormData = () => ({
    assetName: '',
    assetCode: '',
    category: '',
    purchaseDate: format(new Date(), 'yyyy-MM-dd'),
    purchasePrice: '',
    currentValue: '',
    conditionStatus: 'Good',
    location: '',
    description: '',
    status: 'Active',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (asset) {
        setFormData({
          ...asset,
          purchasePrice: asset.purchasePrice.toString(),
          currentValue: asset.currentValue.toString(),
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [asset, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredFields = ['assetName', 'assetCode', 'category', 'purchaseDate', 'purchasePrice', 'currentValue', 'conditionStatus', 'location', 'status'];
    for (const field of requiredFields) {
      const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      if (!formData[field]) {
        toast({ title: '⚠️ Data Tidak Lengkap', description: `Mohon lengkapi field "${fieldName}" yang wajib diisi.`, variant: 'destructive' });
        return;
      }
    }
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{asset ? 'Edit Aset' : 'Tambah Aset Baru'}</DialogTitle>
          <DialogDescription>{asset ? 'Perbarui informasi aset perusahaan.' : 'Tambahkan aset baru ke dalam inventaris.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="assetName">Nama Aset *</Label>
              <Input id="assetName" value={formData.assetName} onChange={handleInputChange} placeholder="Excavator Komatsu PC200" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="assetCode">Kode Aset *</Label>
              <Input id="assetCode" value={formData.assetCode} onChange={handleInputChange} placeholder="EXC-001" required />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Kategori *</Label>
              <Select value={formData.category} onValueChange={(value) => handleSelectChange('category', value)}>
                <SelectTrigger><SelectValue placeholder="Pilih Kategori" /></SelectTrigger>
                <SelectContent>{assetCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="purchaseDate">Tanggal Pembelian *</Label>
              <Input id="purchaseDate" type="date" value={formData.purchaseDate} onChange={handleInputChange} required />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="purchasePrice">Harga Pembelian (IDR) *</Label>
              <Input id="purchasePrice" type="number" value={formData.purchasePrice} onChange={handleInputChange} placeholder="850000000" required min="0" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currentValue">Nilai Saat Ini (IDR) *</Label>
              <Input id="currentValue" type="number" value={formData.currentValue} onChange={handleInputChange} placeholder="750000000" required min="0" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="conditionStatus">Kondisi *</Label>
              <Select value={formData.conditionStatus} onValueChange={(value) => handleSelectChange('conditionStatus', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{conditionStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{assetStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Lokasi *</Label>
            <Input id="location" value={formData.location} onChange={handleInputChange} placeholder="Site A - Jakarta, Warehouse - Tangerang..." required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Deskripsi</Label>
            <Textarea id="description" value={formData.description} onChange={handleInputChange} placeholder="Tambahkan deskripsi atau catatan tambahan tentang aset..." rows={3} />
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{asset ? 'Perbarui Aset' : 'Simpan Aset'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AssetFormDialog;