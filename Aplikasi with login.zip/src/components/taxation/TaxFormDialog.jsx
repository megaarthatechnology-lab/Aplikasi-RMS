import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { taxTypes, paymentMethods, paymentStatusOptions, filingStatusOptions, taxStatusOptions } from '@/lib/taxation-utils.jsx';
import { format } from 'date-fns';

const TaxFormDialog = ({ isOpen, onClose, onSave, record }) => {
  const getInitialFormData = () => ({
    taxType: 'PPh 21',
    taxIdentificationNumber: '',
    taxPeriod: format(new Date(), 'yyyy-MM'),
    taxBaseAmount: '',
    taxRate: '',
    taxAmountPayable: '',
    paymentDate: '',
    paymentMethod: '',
    paymentStatus: 'Unpaid',
    filingStatus: 'Not Filed',
    notes: '',
    status: 'Pending Payment',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (record) {
        setFormData({
          ...record,
          taxBaseAmount: record.taxBaseAmount.toString(),
          taxRate: record.taxRate.toString(),
          taxAmountPayable: record.taxAmountPayable.toString(),
          paymentDate: record.paymentDate || '',
          paymentMethod: record.paymentMethod || '',
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [record, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => {
      const newData = { ...prev, [id]: value };
      
      // Auto-calculate tax amount when base amount or rate changes
      if (id === 'taxBaseAmount' || id === 'taxRate') {
        const baseAmount = parseFloat(id === 'taxBaseAmount' ? value : newData.taxBaseAmount) || 0;
        const rate = parseFloat(id === 'taxRate' ? value : newData.taxRate) || 0;
        newData.taxAmountPayable = (baseAmount * rate / 100).toString();
      }
      
      return newData;
    });
  };
  
  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredFields = ['taxType', 'taxIdentificationNumber', 'taxPeriod', 'taxBaseAmount', 'taxRate', 'taxAmountPayable', 'paymentStatus', 'filingStatus', 'status'];
    for (const field of requiredFields) {
      const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      if (!formData[field]) {
        toast({ title: '⚠️ Data Tidak Lengkap', description: `Mohon lengkapi field "${fieldName}" yang wajib diisi.`, variant: 'destructive' });
        return;
      }
    }
    
    if (isNaN(parseFloat(formData.taxBaseAmount)) || isNaN(parseFloat(formData.taxRate)) || isNaN(parseFloat(formData.taxAmountPayable))) {
      toast({ title: '⚠️ Data Tidak Valid', description: 'Nilai numerik harus berupa angka yang valid.', variant: 'destructive' });
      return;
    }
    
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{record ? 'Edit Data Pajak' : 'Tambah Data Pajak Baru'}</DialogTitle>
          <DialogDescription>{record ? 'Perbarui informasi pajak perusahaan.' : 'Tambahkan catatan pajak baru ke dalam sistem.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="taxType">Jenis Pajak *</Label>
              <Select value={formData.taxType} onValueChange={(value) => handleSelectChange('taxType', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{taxTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="taxIdentificationNumber">NPWP *</Label>
              <Input id="taxIdentificationNumber" value={formData.taxIdentificationNumber} onChange={handleInputChange} placeholder="01.234.567.8-901.000" required />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="taxPeriod">Masa Pajak *</Label>
            <Input id="taxPeriod" type="month" value={formData.taxPeriod} onChange={handleInputChange} required />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="taxBaseAmount">Dasar Pengenaan Pajak (IDR) *</Label>
              <Input id="taxBaseAmount" type="number" value={formData.taxBaseAmount} onChange={handleInputChange} placeholder="150000000" required min="0" step="0.01" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="taxRate">Tarif Pajak (%) *</Label>
              <Input id="taxRate" type="number" value={formData.taxRate} onChange={handleInputChange} placeholder="5" required min="0" max="100" step="0.01" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="taxAmountPayable">Jumlah Pajak Terutang (IDR) *</Label>
              <Input id="taxAmountPayable" type="number" value={formData.taxAmountPayable} onChange={handleInputChange} placeholder="7500000" required min="0" step="0.01" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="paymentDate">Tanggal Pembayaran</Label>
              <Input id="paymentDate" type="date" value={formData.paymentDate} onChange={handleInputChange} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="paymentMethod">Metode Pembayaran</Label>
              <Select value={formData.paymentMethod} onValueChange={(value) => handleSelectChange('paymentMethod', value)}>
                <SelectTrigger><SelectValue placeholder="Pilih Metode" /></SelectTrigger>
                <SelectContent>{paymentMethods.map(method => <SelectItem key={method} value={method}>{method}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="paymentStatus">Status Pembayaran *</Label>
              <Select value={formData.paymentStatus} onValueChange={(value) => handleSelectChange('paymentStatus', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{paymentStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="filingStatus">Status Pelaporan *</Label>
              <Select value={formData.filingStatus} onValueChange={(value) => handleSelectChange('filingStatus', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{filingStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status Keseluruhan *</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{taxStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Catatan</Label>
            <Textarea id="notes" value={formData.notes} onChange={handleInputChange} placeholder="Tambahkan catatan atau keterangan tambahan..." rows={3} />
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{record ? 'Perbarui Data' : 'Simpan Data'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TaxFormDialog;