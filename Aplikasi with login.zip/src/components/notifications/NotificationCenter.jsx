import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, AlertTriangle, MessageSquare, Cog, Check, Trash2, BellOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';
import { id } from 'date-fns/locale';

const notificationIcons = {
  alert: <AlertTriangle className="h-5 w-5 text-yellow-400" />,
  message: <MessageSquare className="h-5 w-5 text-blue-400" />,
  system: <Cog className="h-5 w-5 text-purple-400" />,
};

const NotificationItem = ({ notification, onMarkAsRead, onDelete }) => {
  const timeAgo = formatDistanceToNow(new Date(notification.timestamp), { addSuffix: true, locale: id });

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -50 }}
      transition={{ duration: 0.3 }}
      className={`flex items-start p-4 space-x-4 border-b border-slate-700/50 last:border-b-0 hover:bg-slate-700/30 transition-colors duration-200 ${!notification.read ? 'bg-blue-500/10' : ''}`}
    >
      <div className="flex-shrink-0 pt-1">
        {notificationIcons[notification.type] || <Bell className="h-5 w-5 text-slate-400" />}
      </div>
      <div className="flex-1">
        <p className={`font-semibold text-sm ${!notification.read ? 'text-white' : 'text-slate-300'}`}>{notification.title}</p>
        <p className="text-xs text-slate-400 mt-1">{notification.description}</p>
        <p className="text-xs text-slate-500 mt-2">{timeAgo}</p>
      </div>
      <div className="flex flex-col space-y-2">
        {!notification.read && (
          <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-green-400 hover:bg-green-500/10" onClick={() => onMarkAsRead(notification.id)}>
            <Check className="h-4 w-4" />
          </Button>
        )}
        <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-red-400 hover:bg-red-500/10" onClick={() => onDelete(notification.id)}>
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </motion.div>
  );
};


const NotificationCenter = ({ notifications, setNotifications }) => {
  const sortedNotifications = [...notifications].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  
  const handleMarkAsRead = (id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };
  
  const handleDelete = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleMarkAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };
  
  return (
    <div className="flex flex-col h-full max-h-[70vh]">
      <header className="flex items-center justify-between p-4 border-b border-slate-700">
        <h3 className="text-lg font-semibold text-white">Notifikasi</h3>
        <Button variant="link" className="text-blue-400 h-auto p-0" onClick={handleMarkAllAsRead}>Tandai semua dibaca</Button>
      </header>
      
      <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-slate-700/50">
        <AnimatePresence>
          {sortedNotifications.length > 0 ? (
            sortedNotifications.map(notification => (
              <NotificationItem 
                key={notification.id} 
                notification={notification}
                onMarkAsRead={handleMarkAsRead}
                onDelete={handleDelete}
              />
            ))
          ) : (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center text-center p-8 h-full"
            >
              <BellOff className="h-12 w-12 text-slate-500 mb-4" />
              <p className="font-semibold text-slate-300">Tidak ada notifikasi</p>
              <p className="text-sm text-slate-400">Semua sudah Anda baca.</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default NotificationCenter;