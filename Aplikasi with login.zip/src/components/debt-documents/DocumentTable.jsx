import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical } from 'lucide-react';
import { format } from 'date-fns';
import { formatFileSize, getFileIcon } from '@/lib/debt-documents-utils.jsx';

const DocumentTable = ({ documents, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Daftar Dokumen</CardTitle>
        <CardDescription>Menampilkan {documents.length} dokumen yang sesuai.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[50px]"></TableHead>
                <TableHead>Nama Dokumen</TableHead>
                <TableHead>Referensi Hutang</TableHead>
                <TableHead>Tgl. Unggah</TableHead>
                <TableHead>Ukuran</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {documents.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada dokumen ditemukan</p>
                    <p className="text-sm">Coba sesuaikan filter atau unggah dokumen baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                documents.map((doc) => (
                  <TableRow key={doc.id}>
                    <TableCell>
                      {getFileIcon(doc.type)}
                    </TableCell>
                    <TableCell className="font-medium">
                      <div>{doc.name}</div>
                      {doc.description && <div className="text-xs text-slate-400 mt-1 truncate max-w-xs">{doc.description}</div>}
                    </TableCell>
                    <TableCell>{doc.debtCreditor}</TableCell>
                    <TableCell>{format(new Date(doc.uploadDate), 'dd MMM yyyy')}</TableCell>
                    <TableCell>{formatFileSize(doc.size, 2)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(doc)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit Deskripsi/Ref
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(doc.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default DocumentTable;