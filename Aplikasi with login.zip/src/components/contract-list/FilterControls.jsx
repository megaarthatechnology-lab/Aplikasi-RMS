
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, RotateCcw } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { contractStatusOptions } from '@/lib/contract-list-utils.jsx';

const FilterControls = ({ filters, setFilters }) => {
  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFilters(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value === 'all' ? '' : value }));
  };

  const resetFilters = () => {
    setFilters({
      searchTerm: '',
      contractStatus: '',
      startDate: '',
      endDate: '',
    });
  };

  return (
    <Card className="glass-effect">
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4 gap-4 items-end">
          <div className="xl:col-span-1">
            <Label htmlFor="searchTerm">Cari Kontrak</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="searchTerm"
                placeholder="No. kontrak, nama, supplier..."
                value={filters.searchTerm}
                onChange={handleInputChange}
                className="pl-10"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="contractStatus">Status Kontrak</Label>
            <Select value={filters.contractStatus} onValueChange={(value) => handleSelectChange('contractStatus', value)}>
              <SelectTrigger><SelectValue placeholder="Semua Status"/></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                {contractStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="lg:col-span-2 xl:col-span-1">
            <Label>Filter Tanggal Mulai Kontrak</Label>
            <div className="flex gap-2">
                <Input id="startDate" type="date" value={filters.startDate} onChange={handleInputChange} />
                <Input id="endDate" type="date" value={filters.endDate} onChange={handleInputChange} />
            </div>
          </div>
          <div className="flex justify-end">
             <Button variant="outline" onClick={resetFilters} className="w-full sm:w-auto">
                <RotateCcw className="mr-2 h-4 w-4" /> Reset
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterControls;
