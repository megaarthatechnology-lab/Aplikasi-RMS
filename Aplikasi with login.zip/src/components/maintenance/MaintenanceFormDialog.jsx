import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { maintenanceTypes, maintenanceStatusOptions } from '@/lib/maintenance-utils.jsx';
import { format } from 'date-fns';

const MaintenanceFormDialog = ({ isOpen, onClose, onSave, schedule }) => {
  const getInitialFormData = () => ({
    assetName: '',
    assetCode: '',
    maintenanceType: 'Preventive',
    lastMaintenanceDate: format(new Date(), 'yyyy-MM-dd'),
    nextMaintenanceDate: '',
    maintenanceInterval: '',
    responsibleTechnician: '',
    estimatedCost: '',
    description: '',
    status: 'Scheduled',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (schedule) {
        setFormData({
          ...schedule,
          estimatedCost: schedule.estimatedCost.toString(),
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [schedule, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredFields = ['assetName', 'assetCode', 'maintenanceType', 'lastMaintenanceDate', 'nextMaintenanceDate', 'responsibleTechnician', 'status'];
    for (const field of requiredFields) {
      const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      if (!formData[field]) {
        toast({ title: '⚠️ Data Tidak Lengkap', description: `Mohon lengkapi field "${fieldName}" yang wajib diisi.`, variant: 'destructive' });
        return;
      }
    }
    if (isNaN(parseFloat(formData.estimatedCost))) {
        toast({ title: '⚠️ Data Tidak Valid', description: 'Estimasi biaya harus berupa angka.', variant: 'destructive' });
        return;
    }
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{schedule ? 'Edit Jadwal Perawatan' : 'Tambah Jadwal Perawatan'}</DialogTitle>
          <DialogDescription>{schedule ? 'Perbarui detail jadwal perawatan aset.' : 'Buat jadwal perawatan baru untuk aset.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="assetName">Nama Aset *</Label>
              <Input id="assetName" value={formData.assetName} onChange={handleInputChange} placeholder="Excavator Komatsu PC200" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="assetCode">Kode Aset *</Label>
              <Input id="assetCode" value={formData.assetCode} onChange={handleInputChange} placeholder="EXC-001" required />
            </div>
          </div>
          
          <div className="space-y-2">
              <Label htmlFor="maintenanceType">Tipe Perawatan *</Label>
              <Select value={formData.maintenanceType} onValueChange={(value) => handleSelectChange('maintenanceType', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{maintenanceTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent>
              </Select>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="lastMaintenanceDate">Tanggal Perawatan Terakhir *</Label>
              <Input id="lastMaintenanceDate" type="date" value={formData.lastMaintenanceDate} onChange={handleInputChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="nextMaintenanceDate">Tanggal Perawatan Berikutnya *</Label>
              <Input id="nextMaintenanceDate" type="date" value={formData.nextMaintenanceDate} onChange={handleInputChange} required />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div className="space-y-2">
              <Label htmlFor="maintenanceInterval">Interval Perawatan</Label>
              <Input id="maintenanceInterval" value={formData.maintenanceInterval} onChange={handleInputChange} placeholder="90 hari, 500 jam, dll." />
            </div>
            <div className="space-y-2">
              <Label htmlFor="responsibleTechnician">Teknisi Penanggung Jawab *</Label>
              <Input id="responsibleTechnician" value={formData.responsibleTechnician} onChange={handleInputChange} placeholder="Budi Santoso" required />
            </div>
          </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="estimatedCost">Estimasi Biaya (IDR)</Label>
                    <Input id="estimatedCost" type="number" value={formData.estimatedCost} onChange={handleInputChange} placeholder="2500000" min="0" />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="status">Status *</Label>
                    <Select value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>{maintenanceStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
           </div>

          <div className="space-y-2">
            <Label htmlFor="description">Deskripsi / Catatan Pekerjaan</Label>
            <Textarea id="description" value={formData.description} onChange={handleInputChange} placeholder="General check-up, oil change, dll." rows={3} />
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{schedule ? 'Perbarui Jadwal' : 'Simpan Jadwal'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default MaintenanceFormDialog;