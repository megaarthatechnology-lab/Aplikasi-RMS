import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency } from '@/lib/utils';
import { getTransferStatusBadge } from '@/lib/bank-transfers-utils.jsx';

const BankTransfersTable = ({ transfers, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Daftar Transfer</CardTitle>
        <CardDescription>Menampilkan {transfers.length} data transfer yang sesuai.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Detail Transfer</TableHead>
                <TableHead>Jumlah</TableHead>
                <TableHead>Tanggal</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transfers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada data transfer</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan data transfer baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                transfers.map((t) => (
                  <TableRow key={t.id}>
                    <TableCell>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="font-bold">{t.senderBank}</div>
                          <div className="text-sm text-slate-400">{t.senderHolder}</div>
                          <div className="text-xs text-slate-500">{t.senderAccount}</div>
                        </div>
                        <ArrowRight className="h-5 w-5 text-slate-500 shrink-0" />
                        <div>
                          <div className="font-bold">{t.recipientBank}</div>
                          <div className="text-sm text-slate-400">{t.recipientHolder}</div>
                          <div className="text-xs text-slate-500">{t.recipientAccount}</div>
                        </div>
                      </div>
                      {t.description && <div className="text-xs text-slate-400 mt-2 pl-1 max-w-md truncate">Ket: {t.description}</div>}
                    </TableCell>
                    <TableCell className="font-semibold">{formatCurrency(t.amount)}</TableCell>
                    <TableCell>
                        <div>{format(new Date(t.transferDate), 'dd MMM yyyy')}</div>
                        <div className="text-xs text-slate-500 font-mono">{t.referenceNumber}</div>
                    </TableCell>
                    <TableCell>{getTransferStatusBadge(t.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(t)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(t.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default BankTransfersTable;