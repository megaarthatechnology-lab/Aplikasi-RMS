import React from 'react';
import { motion } from 'framer-motion';

const ProgressSummary = () => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: 0.5 }}
    className="glass-effect rounded-xl p-6"
  >
    <h3 className="text-xl font-semibold text-white mb-6">Ringkasan Progress</h3>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-lg p-4 border border-green-500/20">
        <h4 className="text-lg font-medium text-green-400 mb-2">Fase Selesai</h4>
        <p className="text-3xl font-bold text-green-400">2</p>
        <p className="text-slate-300 text-sm">Persiapan & Pondasi</p>
      </div>
      <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-lg p-4 border border-blue-500/20">
        <h4 className="text-lg font-medium text-blue-400 mb-2">Fase Berlangsung</h4>
        <p className="text-3xl font-bold text-blue-400">2</p>
        <p className="text-slate-300 text-sm">Struktur & Arsitektur</p>
      </div>
      <div className="bg-gradient-to-r from-slate-500/10 to-gray-500/10 rounded-lg p-4 border border-slate-500/20">
        <h4 className="text-lg font-medium text-slate-400 mb-2">Fase Belum Mulai</h4>
        <p className="text-3xl font-bold text-slate-400">1</p>
        <p className="text-slate-300 text-sm">Finishing & MEP</p>
      </div>
    </div>
  </motion.div>
);

export default ProgressSummary;