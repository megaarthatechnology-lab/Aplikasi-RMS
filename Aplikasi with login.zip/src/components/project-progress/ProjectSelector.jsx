import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Calendar, Filter } from 'lucide-react';

const ProjectSelector = ({ projects, selectedProject, setSelectedProject, handleAction }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: 0.1 }}
    className="glass-effect rounded-xl p-6"
  >
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">Pilih Proyek</label>
        <select
          value={selectedProject}
          onChange={(e) => setSelectedProject(e.target.value)}
          className="w-full bg-slate-700/50 border border-slate-600 rounded-lg text-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          {projects.map(project => (
            <option key={project.id} value={project.id}>
              {project.id} - {project.name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">Periode Laporan</label>
        <Button 
          variant="outline"
          onClick={() => handleAction('Pilih Periode')}
          className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 justify-start"
        >
          <Calendar className="h-4 w-4 mr-2" />
          Januari 2024
        </Button>
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">Filter</label>
        <Button 
          variant="outline"
          onClick={() => handleAction('Filter Progress')}
          className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 justify-start"
        >
          <Filter className="h-4 w-4 mr-2" />
          Semua Fase
        </Button>
      </div>
    </div>
  </motion.div>
);

export default ProjectSelector;