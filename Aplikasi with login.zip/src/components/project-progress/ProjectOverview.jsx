import React from 'react';
import { motion } from 'framer-motion';

const ProjectOverview = ({ totalProgress }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: 0.2 }}
    className="glass-effect rounded-xl p-6"
  >
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold text-white mb-2">Progress Keseluruhan</h3>
        <div className="relative w-24 h-24 mx-auto mb-2">
          <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="40"
              stroke="currentColor"
              strokeWidth="8"
              fill="transparent"
              className="text-slate-700"
            />
            <circle
              cx="50"
              cy="50"
              r="40"
              stroke="currentColor"
              strokeWidth="8"
              fill="transparent"
              strokeDasharray={`${2 * Math.PI * 40}`}
              strokeDashoffset={`${2 * Math.PI * 40 * (1 - totalProgress / 100)}`}
              className="text-blue-500"
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-2xl font-bold text-white">{totalProgress}%</span>
          </div>
        </div>
      </div>
      <div className="text-center">
        <h3 className="text-lg font-semibold text-white mb-2">Durasi Proyek</h3>
        <p className="text-2xl font-bold text-green-400">365</p>
        <p className="text-slate-400 text-sm">Hari</p>
      </div>
      <div className="text-center">
        <h3 className="text-lg font-semibold text-white mb-2">Fase Aktif</h3>
        <p className="text-2xl font-bold text-yellow-400">2</p>
        <p className="text-slate-400 text-sm">dari 5 fase</p>
      </div>
      <div className="text-center">
        <h3 className="text-lg font-semibold text-white mb-2">Milestone Tercapai</h3>
        <p className="text-2xl font-bold text-purple-400">1</p>
        <p className="text-slate-400 text-sm">dari 3 milestone</p>
      </div>
    </div>
  </motion.div>
);

export default ProjectOverview;