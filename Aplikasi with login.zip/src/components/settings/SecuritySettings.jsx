import React from 'react';
import { ShieldAlert, KeyRound, QrCode } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const SecuritySettings = () => {
    const { toast } = useToast();
    const showToast = () => {
        toast({
            title: "🚧 Fitur Dalam Pengembangan",
            description: "Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
        });
    };

    return (
        <Card className="glass-effect">
            <CardHeader>
                <CardTitle className="text-2xl">Pengaturan Keamanan</CardTitle>
                <CardDescription>Ubah kata sandi Anda, atur otentikasi dua faktor, dan amankan akun Anda.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
                <div className="p-4 rounded-lg bg-card-foreground/5 dark:bg-card-foreground/5">
                    <div className="flex items-start gap-4">
                        <KeyRound className="h-8 w-8 text-blue-400 mt-1" />
                        <div>
                            <h3 className="font-semibold text-base">Kata Sandi</h3>
                            <p className="text-sm text-muted-foreground mb-3">Ubah kata sandi Anda secara berkala untuk menjaga keamanan akun.</p>
                            <Button variant="outline" onClick={showToast}>Ubah Kata Sandi</Button>
                        </div>
                    </div>
                </div>
                <div className="p-4 rounded-lg bg-card-foreground/5 dark:bg-card-foreground/5">
                    <div className="flex items-start gap-4">
                        <QrCode className="h-8 w-8 text-green-400 mt-1" />
                        <div>
                            <h3 className="font-semibold text-base">Otentikasi Dua Faktor (2FA)</h3>
                            <p className="text-sm text-muted-foreground mb-3">Tambahkan lapisan keamanan ekstra pada akun Anda menggunakan aplikasi otentikator.</p>
                            <Button variant="outline" onClick={showToast}>Aktifkan 2FA</Button>
                        </div>
                    </div>
                </div>
                <div className="p-4 rounded-lg bg-card-foreground/5 dark:bg-card-foreground/5">
                    <div className="flex items-start gap-4">
                        <ShieldAlert className="h-8 w-8 text-yellow-400 mt-1" />
                        <div>
                            <h3 className="font-semibold text-base">Sesi Aktif</h3>
                            <p className="text-sm text-muted-foreground mb-3">Lihat dan kelola perangkat mana yang saat ini masuk ke akun Anda.</p>
                            <Button variant="outline" onClick={showToast}>Kelola Sesi</Button>
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};

export default SecuritySettings;