import React, { useState, useEffect } from 'react';
import { Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const initialNotificationPrefs = {
  alerts: true,
  messages: true,
  systemUpdates: true,
  delivery: 'realtime',
  pushNotifications: false,
};

const NotificationSettings = () => {
    const [prefs, setPrefs] = useState(initialNotificationPrefs);
    const { toast } = useToast();

    useEffect(() => {
        const savedPrefs = JSON.parse(localStorage.getItem('notificationPreferences')) || initialNotificationPrefs;
        setPrefs(savedPrefs);
    }, []);

    const handleToggle = (key) => {
        setPrefs(prev => ({ ...prev, [key]: !prev[key] }));
    };

    const handleSelectChange = (value) => {
        setPrefs(prev => ({ ...prev, delivery: value }));
    };

    const handleSave = () => {
        localStorage.setItem('notificationPreferences', JSON.stringify(prefs));
        toast({
            title: '✅ Preferensi Disimpan',
            description: 'Pengaturan notifikasi Anda telah berhasil diperbarui.',
        });
    };
    
    return (
        <Card className="glass-effect">
            <CardHeader>
                <CardTitle className="text-2xl">Pengaturan Notifikasi</CardTitle>
                <CardDescription>Pilih notifikasi mana yang ingin Anda terima dan bagaimana caranya.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
                <div className="space-y-6">
                    <div className="flex items-center justify-between p-4 rounded-lg bg-card-foreground/5 dark:bg-card-foreground/5">
                        <div>
                            <Label htmlFor="alerts-notif" className="font-semibold text-base">Notifikasi Peringatan</Label>
                            <p className="text-sm text-muted-foreground">Peringatan penting seperti tenggat waktu pembayaran.</p>
                        </div>
                        <Switch id="alerts-notif" checked={prefs.alerts} onCheckedChange={() => handleToggle('alerts')} />
                    </div>
                     <div className="flex items-center justify-between p-4 rounded-lg bg-card-foreground/5 dark:bg-card-foreground/5">
                        <div>
                            <Label htmlFor="messages-notif" className="font-semibold text-base">Notifikasi Pesan</Label>
                            <p className="text-sm text-muted-foreground">Pesan dari manajer proyek atau anggota tim.</p>
                        </div>
                        <Switch id="messages-notif" checked={prefs.messages} onCheckedChange={() => handleToggle('messages')} />
                    </div>
                     <div className="flex items-center justify-between p-4 rounded-lg bg-card-foreground/5 dark:bg-card-foreground/5">
                        <div>
                            <Label htmlFor="system-notif" className="font-semibold text-base">Pembaruan Sistem</Label>
                            <p className="text-sm text-muted-foreground">Informasi tentang fitur baru dan pemeliharaan.</p>
                        </div>
                        <Switch id="system-notif" checked={prefs.systemUpdates} onCheckedChange={() => handleToggle('systemUpdates')} />
                    </div>
                </div>

                <div className="border-t border-border pt-8 space-y-6">
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                        <div>
                            <Label className="text-base font-semibold">Frekuensi Pengiriman</Label>
                            <p className="text-sm text-muted-foreground">Pilih seberapa sering Anda ingin menerima ringkasan.</p>
                        </div>
                        <Select value={prefs.delivery} onValueChange={handleSelectChange}>
                            <SelectTrigger className="w-full md:w-[240px]">
                                <SelectValue placeholder="Pilih frekuensi" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="realtime">Real-time</SelectItem>
                                <SelectItem value="daily">Ringkasan Harian</SelectItem>
                                <SelectItem value="weekly">Ringkasan Mingguan</SelectItem>
                            </SelectContent>
                        </Select>
                     </div>
                     <div className="flex items-center justify-between p-4 rounded-lg bg-card-foreground/5 dark:bg-card-foreground/5">
                        <div>
                            <Label htmlFor="push-notif" className="font-semibold text-base">Push Notifications</Label>
                            <p className="text-sm text-muted-foreground">Terima notifikasi langsung di browser Anda.</p>
                        </div>
                        <Switch id="push-notif" checked={prefs.pushNotifications} onCheckedChange={() => handleToggle('pushNotifications')} />
                    </div>
                </div>
                
                <div className="flex justify-end pt-4">
                    <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700 text-white"><Save className="mr-2 h-4 w-4" /> Simpan Perubahan</Button>
                </div>
            </CardContent>
        </Card>
    );
};

export default NotificationSettings;