import React from 'react';
import { Sun, Moon, Languages, Text, Layout, Columns } from 'lucide-react';
import { useAppearance } from '@/components/settings/AppearanceProvider';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';

const AppearanceSettings = () => {
    const { theme, setTheme, fontSize, setFontSize, sidebarLayout, setSidebarLayout } = useAppearance();
    const { toast } = useToast();

    const handleLanguageChange = () => {
        toast({
            title: "🌐 Fitur Bahasa",
            description: "Dukungan multi-bahasa akan segera hadir!",
        });
    };

    return (
        <Card className="glass-effect">
            <CardHeader>
                <CardTitle className="text-2xl">Preferensi Tampilan</CardTitle>
                <CardDescription>Sesuaikan tampilan dan nuansa aplikasi agar sesuai dengan preferensi Anda.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
                {/* Theme Selection */}
                <div>
                    <Label className="text-base font-semibold">Tema</Label>
                    <p className="text-sm text-muted-foreground mb-4">Pilih antara tema terang atau gelap.</p>
                    <div className="grid grid-cols-2 gap-4">
                        <Button
                            variant="outline"
                            className={cn(
                                "h-24 flex-col gap-2",
                                theme === 'light' && "ring-2 ring-blue-500 border-blue-500"
                            )}
                            onClick={() => setTheme('light')}
                        >
                            <Sun className="h-6 w-6" />
                            <span>Light</span>
                        </Button>
                        <Button
                            variant="outline"
                            className={cn(
                                "h-24 flex-col gap-2",
                                theme === 'dark' && "ring-2 ring-blue-500 border-blue-500"
                            )}
                            onClick={() => setTheme('dark')}
                        >
                            <Moon className="h-6 w-6" />
                            <span>Dark</span>
                        </Button>
                    </div>
                </div>

                {/* Font Size */}
                <div>
                    <Label className="text-base font-semibold">Ukuran Font</Label>
                    <p className="text-sm text-muted-foreground mb-4">Sesuaikan ukuran font di seluruh aplikasi.</p>
                    <div className="flex items-center gap-4">
                        <Text className="h-5 w-5 text-muted-foreground" />
                        <Slider
                            min={12}
                            max={20}
                            step={1}
                            value={[fontSize]}
                            onValueChange={(value) => setFontSize(value[0])}
                        />
                        <Text className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <p className="text-center text-sm text-muted-foreground mt-2">Ukuran saat ini: {fontSize}px</p>
                </div>

                {/* Sidebar Layout */}
                <div>
                    <Label className="text-base font-semibold">Tata Letak Sidebar</Label>
                    <p className="text-sm text-muted-foreground mb-4">Pilih gaya menu navigasi samping.</p>
                    <div className="grid grid-cols-2 gap-4">
                        <Button
                            variant="outline"
                            className={cn(
                                "h-24 flex-col gap-2",
                                sidebarLayout === 'spacious' && "ring-2 ring-blue-500 border-blue-500"
                            )}
                            onClick={() => setSidebarLayout('spacious')}
                        >
                            <Layout className="h-6 w-6" />
                            <span>Spacious</span>
                        </Button>
                        <Button
                            variant="outline"
                            className={cn(
                                "h-24 flex-col gap-2",
                                sidebarLayout === 'compact' && "ring-2 ring-blue-500 border-blue-500"
                            )}
                            onClick={() => setSidebarLayout('compact')}
                        >
                            <Columns className="h-6 w-6" />
                            <span>Compact</span>
                        </Button>
                    </div>
                </div>

                {/* Language */}
                <div>
                    <Label className="text-base font-semibold">Bahasa</Label>
                    <p className="text-sm text-muted-foreground mb-4">Pilih bahasa tampilan antarmuka.</p>
                    <Select defaultValue="id" onValueChange={handleLanguageChange}>
                        <SelectTrigger className="w-full md:w-1/2">
                            <SelectValue placeholder="Pilih bahasa" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="id">Bahasa Indonesia</SelectItem>
                            <SelectItem value="en">English (US)</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            </CardContent>
        </Card>
    );
};

export default AppearanceSettings;