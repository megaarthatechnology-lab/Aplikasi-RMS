import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PlusCircle, Trash2 } from 'lucide-react';
import { formatCurrency } from '@/lib/invoice-utils';

const InvoiceItems = ({ items, onItemsChange }) => {
  const handleItemChange = (id, field, value) => {
    const newItems = items.map(item => {
      if (item.id === id) {
        const newItem = { ...item, [field]: value };
        if (field === 'quantity' || field === 'price') {
            newItem.total = (newItem.quantity || 0) * (newItem.price || 0);
        }
        return newItem;
      }
      return item;
    });
    onItemsChange(newItems);
  };

  const addItem = () => {
    onItemsChange([...items, { id: Date.now(), name: '', quantity: 1, price: 0, total: 0 }]);
  };

  const removeItem = (id) => {
    if (items.length > 1) {
      onItemsChange(items.filter(item => item.id !== id));
    }
  };

  return (
    <div className="space-y-3">
        <div className="grid grid-cols-12 gap-2 text-sm font-medium text-slate-300">
            <div className="col-span-5">Deskripsi Item</div>
            <div className="col-span-2">Jumlah</div>
            <div className="col-span-2">Harga Satuan</div>
            <div className="col-span-2 text-right">Total</div>
            <div className="col-span-1"></div>
        </div>
      {items.map((item, index) => (
        <div key={item.id} className="grid grid-cols-12 gap-2 items-center">
          <Input
            className="col-span-5"
            placeholder="Nama item atau jasa"
            value={item.name}
            onChange={(e) => handleItemChange(item.id, 'name', e.target.value)}
          />
          <Input
            className="col-span-2"
            type="number"
            placeholder="1"
            min="1"
            value={item.quantity}
            onChange={(e) => handleItemChange(item.id, 'quantity', parseFloat(e.target.value))}
          />
          <Input
            className="col-span-2"
            type="number"
            placeholder="0"
            min="0"
            value={item.price}
            onChange={(e) => handleItemChange(item.id, 'price', parseFloat(e.target.value))}
          />
          <div className="col-span-2 text-right font-medium text-slate-200">
            {formatCurrency((item.quantity || 0) * (item.price || 0))}
          </div>
          <div className="col-span-1 flex justify-end">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => removeItem(item.id)}
              disabled={items.length <= 1}
              className="text-red-500 hover:text-red-400 disabled:text-slate-600 disabled:cursor-not-allowed"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ))}
      <Button type="button" variant="outline" size="sm" onClick={addItem} className="mt-2">
        <PlusCircle className="mr-2 h-4 w-4" /> Tambah Item
      </Button>
    </div>
  );
};

export default InvoiceItems;