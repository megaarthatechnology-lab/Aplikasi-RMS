import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, RotateCcw } from 'lucide-react';
import { frequencyOptions, statusOptions } from '@/lib/recurring-transactions-utils.jsx';

const FilterControls = ({ filters, setFilters }) => {
  const handleInputChange = (e) => {
    setFilters(prev => ({ ...prev, searchTerm: e.target.value }));
  };

  const handleSelectChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const resetFilters = () => {
    setFilters({ searchTerm: '', status: 'all', frequency: 'all' });
  };

  return (
    <Card className="glass-effect">
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div className="relative md:col-span-2">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Cari berdasarkan nama, kategori, atau deskripsi..."
              value={filters.searchTerm}
              onChange={handleInputChange}
              className="pl-10"
            />
          </div>
          <Select value={filters.status} onValueChange={(value) => handleSelectChange('status', value)}>
            <SelectTrigger><SelectValue placeholder="Pilih Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Status</SelectItem>
              {statusOptions.map(status => (
                <SelectItem key={status.value} value={status.value}>{status.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filters.frequency} onValueChange={(value) => handleSelectChange('frequency', value)}>
            <SelectTrigger><SelectValue placeholder="Pilih Frekuensi" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Frekuensi</SelectItem>
              {frequencyOptions.map(freq => (
                <SelectItem key={freq.value} value={freq.value}>{freq.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="mt-4 flex justify-end">
            <Button variant="outline" onClick={resetFilters}>
                <RotateCcw className="mr-2 h-4 w-4" /> Reset Filter
            </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterControls;