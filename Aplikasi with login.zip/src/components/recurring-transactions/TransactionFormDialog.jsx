import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { frequencyOptions, categoryOptions, statusOptions } from '@/lib/recurring-transactions-utils.jsx';
import { format } from 'date-fns';

const TransactionFormDialog = ({ isOpen, onClose, onSave, transaction }) => {
  const getInitialFormData = () => ({
    name: '',
    amount: '',
    frequency: 'monthly',
    startDate: format(new Date(), 'yyyy-MM-dd'),
    endDate: format(new Date(), 'yyyy-MM-dd'),
    category: 'Operasional',
    description: '',
    status: 'active',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
        if (transaction) {
          setFormData({
            name: transaction.name,
            amount: transaction.amount.toString(),
            frequency: transaction.frequency,
            startDate: transaction.startDate,
            endDate: transaction.endDate,
            category: transaction.category,
            description: transaction.description || '',
            status: transaction.status,
          });
        } else {
          setFormData(getInitialFormData());
        }
    }
  }, [transaction, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.amount || !formData.startDate || !formData.endDate) {
      toast({ title: '⚠️ Data Tidak Lengkap', description: 'Mohon lengkapi semua field yang wajib diisi.', variant: 'destructive' });
      return;
    }
    if(new Date(formData.endDate) < new Date(formData.startDate)) {
      toast({ title: '⚠️ Tanggal Tidak Valid', description: 'Tanggal akhir tidak boleh sebelum tanggal mulai.', variant: 'destructive' });
      return;
    }
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{transaction ? 'Edit Transaksi Berulang' : 'Tambah Transaksi Berulang'}</DialogTitle>
          <DialogDescription>{transaction ? 'Perbarui informasi transaksi.' : 'Buat transaksi berulang baru.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nama Transaksi *</Label>
            <Input id="name" value={formData.name} onChange={handleInputChange} placeholder="Contoh: Sewa Kantor" required />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Jumlah (IDR) *</Label>
              <Input id="amount" type="number" value={formData.amount} onChange={handleInputChange} placeholder="15000000" required min="0" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="frequency">Frekuensi *</Label>
              <Select value={formData.frequency} onValueChange={(value) => handleSelectChange('frequency', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{frequencyOptions.map(f => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">Tanggal Mulai *</Label>
              <Input id="startDate" type="date" value={formData.startDate} onChange={handleInputChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endDate">Tanggal Akhir *</Label>
              <Input id="endDate" type="date" value={formData.endDate} onChange={handleInputChange} required />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Kategori *</Label>
              <Select value={formData.category} onValueChange={(value) => handleSelectChange('category', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{categoryOptions.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{statusOptions.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Deskripsi</Label>
            <Textarea id="description" value={formData.description} onChange={handleInputChange} placeholder="Tambahkan deskripsi atau catatan tambahan..." />
          </div>
          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{transaction ? 'Perbarui Transaksi' : 'Tambah Transaksi'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TransactionFormDialog;