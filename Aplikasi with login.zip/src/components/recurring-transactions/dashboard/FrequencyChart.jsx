import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import { motion } from 'framer-motion';

const COLORS = {
  daily: '#8884d8',
  weekly: '#82ca9d',
  monthly: '#ffc658',
  yearly: '#ff8042',
};
const RADIAN = Math.PI / 180;

const CustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);

  return (
    <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central">
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

const FrequencyChart = ({ transactions }) => {
  const frequencyData = transactions.reduce((acc, t) => {
    if (t.status === 'active') {
      acc[t.frequency] = (acc[t.frequency] || 0) + 1;
    }
    return acc;
  }, {});

  const chartData = Object.keys(frequencyData).map(key => ({
    name: key.charAt(0).toUpperCase() + key.slice(1),
    value: frequencyData[key],
  }));

  return (
    <Card className="glass-effect h-full">
      <CardHeader>
        <CardTitle>Frekuensi Transaksi</CardTitle>
        <CardDescription>Distribusi transaksi aktif berdasarkan frekuensi.</CardDescription>
      </CardHeader>
      <CardContent>
        {chartData.length > 0 ? (
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={CustomLabel}
                outerRadius={100}
                innerRadius={60}
                fill="#8884d8"
                dataKey="value"
                paddingAngle={5}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[entry.name.toLowerCase()]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--background))',
                  borderColor: 'hsl(var(--border))',
                  color: 'hsl(var(--foreground))',
                }}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        ) : (
           <div className="flex items-center justify-center h-[250px] text-muted-foreground">
             Tidak ada data transaksi aktif.
           </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FrequencyChart;