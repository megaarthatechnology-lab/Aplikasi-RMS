
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { paymentTermOptions, deliveryTermOptions, contractStatusOptions } from '@/lib/contract-buyer-utils.jsx';
import { format } from 'date-fns';

const BuyerContractFormDialog = ({ isOpen, onClose, onSave, contract }) => {
  const getInitialFormData = () => ({
    buyerName: '',
    contractNumber: '',
    contractName: '',
    startDate: format(new Date(), 'yyyy-MM-dd'),
    endDate: '',
    contractValue: '',
    paymentTerms: 'Per Milestone',
    deliveryTerms: 'Turnkey Project',
    notes: '',
    contractStatus: 'Draft',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (contract) {
        setFormData({
          ...contract,
          contractValue: contract.contractValue.toString(),
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [contract, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredFields = ['buyerName', 'contractNumber', 'contractName', 'startDate', 'endDate', 'contractValue', 'contractStatus'];
    for (const field of requiredFields) {
      const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      if (!formData[field]) {
        toast({ title: '⚠️ Data Tidak Lengkap', description: `Mohon lengkapi field "${fieldName}" yang wajib diisi.`, variant: 'destructive' });
        return;
      }
    }
    if (isNaN(parseFloat(formData.contractValue))) {
        toast({ title: '⚠️ Data Tidak Valid', description: 'Nilai kontrak harus berupa angka.', variant: 'destructive' });
        return;
    }
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{contract ? 'Edit Kontrak Pembeli' : 'Tambah Kontrak Pembeli'}</DialogTitle>
          <DialogDescription>{contract ? 'Perbarui detail kontrak dengan pembeli.' : 'Buat catatan kontrak baru dengan pembeli.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="buyerName">Nama Pembeli *</Label>
              <Input id="buyerName" value={formData.buyerName} onChange={handleInputChange} placeholder="PT. Properti Megah" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contractName">Nama Kontrak *</Label>
              <Input id="contractName" value={formData.contractName} onChange={handleInputChange} placeholder="Pembangunan Apartemen" required />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="contractNumber">Nomor Kontrak *</Label>
            <Input id="contractNumber" value={formData.contractNumber} onChange={handleInputChange} placeholder="BUY-2025-001" required />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">Tanggal Mulai Kontrak *</Label>
              <Input id="startDate" type="date" value={formData.startDate} onChange={handleInputChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endDate">Tanggal Berakhir Kontrak *</Label>
              <Input id="endDate" type="date" value={formData.endDate} onChange={handleInputChange} required />
            </div>
          </div>
          
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                  <Label htmlFor="contractValue">Nilai Kontrak (IDR) *</Label>
                  <Input id="contractValue" type="number" value={formData.contractValue} onChange={handleInputChange} placeholder="15000000000" min="0" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contractStatus">Status Kontrak *</Label>
                <Select value={formData.contractStatus} onValueChange={(value) => handleSelectChange('contractStatus', value)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{contractStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                  <Label htmlFor="paymentTerms">Syarat Pembayaran *</Label>
                  <Select value={formData.paymentTerms} onValueChange={(value) => handleSelectChange('paymentTerms', value)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{paymentTermOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}</SelectContent>
                  </Select>
              </div>
              <div className="space-y-2">
                  <Label htmlFor="deliveryTerms">Syarat Pengiriman/Penyelesaian *</Label>
                  <Select value={formData.deliveryTerms} onValueChange={(value) => handleSelectChange('deliveryTerms', value)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{deliveryTermOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}</SelectContent>
                  </Select>
              </div>
           </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Catatan</Label>
            <Textarea id="notes" value={formData.notes} onChange={handleInputChange} placeholder="Deskripsi singkat mengenai isi dan cakupan kontrak..." rows={3} />
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{contract ? 'Perbarui Kontrak' : 'Simpan Kontrak'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default BuyerContractFormDialog;
