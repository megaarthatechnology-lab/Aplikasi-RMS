
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LayoutDashboard, BarChart3, Book, Briefcase, Users, Truck, Wrench, FileText, Coins, Landmark, FileCog, Shield, Settings, X, ChevronDown, ChevronRight, Coins as HandCoins, Building2, ScrollText, Warehouse, Fuel, Cog, Database, FileSpreadsheet, FileBarChart, Wallet, FileClock, History, Receipt, Banknote, ListChecks, Percent, ArrowRightLeft, HeartHandshake as Handshake, FileType, LogOut } from 'lucide-react';
import { useAppearance } from '@/components/settings/AppearanceProvider';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';

const menuItems = [{
  icon: LayoutDashboard,
  text: 'Dashboard',
  path: '/'
}, {
  icon: FileText,
  text: 'Akuntansi',
  path: '/accounting',
  submenu: [{
    text: 'Bagan Akun',
    path: '/chart-of-accounts'
  }, {
    text: 'Jurnal & Buku Besar',
    path: '/journal'
  }, {
    text: 'Transaksi Berulang',
    path: '/recurring-transactions'
  }]
}, {
  icon: FileSpreadsheet,
  text: 'Laporan Keuangan',
  path: '/reports',
  submenu: [{
    text: 'Laporan Laba Rugi',
    path: '/income-statement'
  }, {
    text: 'Laporan Perubahan Ekuitas',
    path: 'equity-statement'
  }, {
    text: 'Neraca',
    path: '/balance-sheet'
  }, {
    text: 'Laporan Arus Kas',
    path: '/cash-flow'
  }, {
    text: 'Catatan Keuangan',
    path: '/financial-notes'
  }]
}, {
  icon: HandCoins,
  text: 'Hutang & Piutang',
  path: '/debt-receivables',
  submenu: [{
    text: 'Manajemen Hutang',
    path: '/debt-management'
  }, {
    text: 'Dokumen Hutang',
    path: '/debt-documents'
  }, {
    text: 'Jadwal Hutang',
    path: '/debt-schedule'
  }, {
    text: 'Daftar Piutang',
    path: '/receivables-list'
  }, {
    text: 'Daftar Invoice',
    path: '/invoice-list'
  }, {
    text: 'Invoice Lunas',
    path: '/paid-invoices'
  }]
}, {
  icon: Banknote,
  text: 'Pembayaran & Kas',
  path: '/payment-cash',
  submenu: [{
    text: 'Pembayaran',
    path: '/payments'
  }, {
    text: 'Transfer Bank',
    path: '/bank-transfers'
  }]
}, {
  icon: Briefcase,
  text: 'Proyek',
  path: '/projects',
  submenu: [{
    text: 'Daftar Proyek',
    path: '/project-list'
  }, {
    text: 'Progres Proyek',
    path: '/project-progress'
  }]
}, {
  icon: Users,
  text: 'Karyawan',
  path: '/employees',
  submenu: [{
    text: 'Daftar Karyawan',
    path: '/employee-list'
  }, {
    text: 'Rekap Karyawan',
    path: '/employee-recap'
  }]
}, {
  icon: Truck,
  text: 'Logistik & Material',
  path: '/logistics',
  submenu: [{
    text: 'Mutasi Alat',
    path: '/equipment-mutation'
  }, {
    text: 'Pemakaian Material',
    path: '/material-usage'
  }, {
    text: 'Pemakaian Bahan Baku',
    path: '/raw-material-usage'
  }, {
    text: 'Pemakaian Oli & BBM',
    path: '/oil-fuel-usage'
  }, {
    text: 'Pemakaian Sparepart',
    path: '/sparepart-usage'
  }]
}, {
  icon: Building2,
  text: 'Manajemen Aset',
  path: '/asset-management',
  submenu: [{
    text: 'Daftar Aset',
    path: '/asset-list'
  }, {
    text: 'Lokasi Aset',
    path: '/asset-location'
  }, {
    text: 'Jadwal Perawatan',
    path: '/maintenance-schedule'
  }, {
    text: 'Dokumen Aset',
    path: '/asset-documents'
  }]
}, {
  icon: Handshake,
  text: 'Manajemen Kontrak',
  path: '/contract-management',
  submenu: [{
    text: 'Daftar Kontrak',
    path: '/contract-list'
  }, {
    text: 'Kontrak per Supplier',
    path: '/contract-by-supplier'
  }, {
    text: 'Kontrak per Barang',
    path: '/contract-by-item'
  }, {
    text: 'Kontrak per Pembeli',
    path: '/contract-by-buyer'
  }]
}, {
  icon: Percent,
  text: 'Perpajakan',
  path: '/taxation'
}, {
  icon: Shield,
  text: 'Panel Admin',
  path: '/admin-panel'
}];

const SubMenu = ({
  item,
  activePath,
  sidebarLayout
}) => {
  const [isOpen, setIsOpen] = React.useState(item.submenu.some(sub => activePath.startsWith(sub.path)));
  const isCompact = sidebarLayout === 'compact';
  return <div>
      <div className={cn("menu-item flex items-center justify-between cursor-pointer w-full text-left rounded-lg text-foreground/80", isCompact ? "px-2 py-2" : "px-4 py-3")} onClick={() => setIsOpen(!isOpen)}>
        <div className="flex items-center gap-3">
          <item.icon className={cn("flex-shrink-0", isCompact ? "h-5 w-5" : "h-6 w-6")} />
          {!isCompact && <span className="font-medium">{item.text}</span>}
        </div>
        {!isCompact && (isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />)}
      </div>
      {isOpen && !isCompact && <motion.div initial={{
      height: 0,
      opacity: 0
    }} animate={{
      height: 'auto',
      opacity: 1
    }} exit={{
      height: 0,
      opacity: 0
    }} className="ml-6 pl-4 border-l border-border">
          {item.submenu.map(subItem => <Link to={subItem.path} key={subItem.path}>
              <div className={cn("submenu-item block px-4 py-2 my-1 rounded-md text-sm", activePath.startsWith(subItem.path) ? 'bg-accent text-accent-foreground font-semibold' : 'text-foreground/70')}>
                {subItem.text}
              </div>
            </Link>)}
        </motion.div>}
    </div>;
};

const Sidebar = ({
  onClose
}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { sidebarLayout } = useAppearance();
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const isCompact = sidebarLayout === 'compact';

  const handleLogout = () => {
    logout();
    toast({
      title: "👋 Logout Berhasil",
      description: "Anda telah keluar dari sistem."
    });
    navigate('/login');
  };

  return <div className={cn("flex flex-col h-full sidebar-gradient border-r border-border transition-all duration-300", isCompact ? "w-20" : "w-80")}>
      <div className={cn("flex items-center justify-between h-20 border-b border-border", isCompact ? "px-4" : "px-6")}>
        <div className="flex items-center gap-2">
            <img alt="Company logo" className="h-8 w-8" src="https://images.unsplash.com/photo-1691405167344-c3bbc9710ad2" />
            {!isCompact && <span className="text-xl font-bold text-foreground">RMS Akuntansi</span>}
        </div>
        <button onClick={onClose} className="lg:hidden text-foreground/70 hover:text-foreground">
          <X />
        </button>
      </div>

      {!isCompact && user && (
        <div className="px-6 py-4 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-semibold">
              {user.name?.charAt(0).toUpperCase() || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground truncate">{user.name}</p>
              <p className="text-xs text-muted-foreground truncate">{user.email}</p>
            </div>
          </div>
        </div>
      )}

      <nav className="flex-1 overflow-y-auto overflow-x-hidden p-4 scrollbar-thin">
        <ul className="space-y-2">
          {menuItems.map(item => <li key={item.path}>
              {item.submenu ? <SubMenu item={item} activePath={location.pathname} sidebarLayout={sidebarLayout} /> : <Link to={item.path}>
                  <div className={cn("menu-item flex items-center gap-3 rounded-lg text-foreground/80", isCompact ? "px-2 py-2 justify-center" : "px-4 py-3", location.pathname === item.path && 'bg-accent text-accent-foreground font-semibold')}>
                    <item.icon className={cn("flex-shrink-0", isCompact ? "h-5 w-5" : "h-6 w-6")} />
                    {!isCompact && <span className="font-medium">{item.text}</span>}
                  </div>
                </Link>}
            </li>)}
        </ul>
      </nav>

      <div className={cn("border-t border-border mt-auto", isCompact ? "p-2" : "p-4")}>
         <Link to="/settings">
          <div className={cn("menu-item flex items-center gap-3 rounded-lg text-foreground/80 mb-2", isCompact ? "px-2 py-2 justify-center" : "px-4 py-3", location.pathname === '/settings' && 'bg-accent text-accent-foreground font-semibold')}>
            <Settings className={cn("flex-shrink-0", isCompact ? "h-5 w-5" : "h-6 w-6")} />
            {!isCompact && <span className="font-medium">Pengaturan</span>}
          </div>
        </Link>
        
        <button onClick={handleLogout} className="w-full">
          <div className={cn("menu-item flex items-center gap-3 rounded-lg text-foreground/80 hover:bg-red-600/10 hover:text-red-400", isCompact ? "px-2 py-2 justify-center" : "px-4 py-3")}>
            <LogOut className={cn("flex-shrink-0", isCompact ? "h-5 w-5" : "h-6 w-6")} />
            {!isCompact && <span className="font-medium">Logout</span>}
          </div>
        </button>
      </div>
    </div>;
};

export default Sidebar;
