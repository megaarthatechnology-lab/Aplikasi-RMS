import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { documentTypes, documentStatusOptions } from '@/lib/asset-documents-utils.jsx';
import { format } from 'date-fns';

const DocumentFormDialog = ({ isOpen, onClose, onSave, document }) => {
  const getInitialFormData = () => ({
    assetName: '',
    assetCode: '',
    documentType: 'Lainnya',
    documentName: '',
    uploadDate: format(new Date(), 'yyyy-MM-dd'),
    documentDescription: '',
    fileReference: '',
    expiryDate: '',
    responsiblePerson: '',
    status: 'Active',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (document) {
        setFormData({
            ...document,
            expiryDate: document.expiryDate ? format(new Date(document.expiryDate), 'yyyy-MM-dd') : '',
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [document, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredFields = ['assetName', 'assetCode', 'documentType', 'documentName', 'uploadDate', 'fileReference', 'responsiblePerson', 'status'];
    for (const field of requiredFields) {
      const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      if (!formData[field]) {
        toast({ title: '⚠️ Data Tidak Lengkap', description: `Mohon lengkapi field "${fieldName}" yang wajib diisi.`, variant: 'destructive' });
        return;
      }
    }
    // Convert expiry date back to ISO or null
    const finalData = {
        ...formData,
        expiryDate: formData.expiryDate ? new Date(formData.expiryDate).toISOString() : null,
    };
    onSave(finalData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{document ? 'Edit Dokumen Aset' : 'Tambah Dokumen Aset'}</DialogTitle>
          <DialogDescription>{document ? 'Perbarui detail dokumen aset.' : 'Unggah dan catat dokumen baru untuk sebuah aset.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="assetName">Nama Aset *</Label>
              <Input id="assetName" value={formData.assetName} onChange={handleInputChange} placeholder="Excavator Komatsu PC200" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="assetCode">Kode Aset *</Label>
              <Input id="assetCode" value={formData.assetCode} onChange={handleInputChange} placeholder="EXC-001" required />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label htmlFor="documentName">Nama Dokumen *</Label>
                <Input id="documentName" value={formData.documentName} onChange={handleInputChange} placeholder="Sertifikat Laik Operasi (SLO)" required />
            </div>
            <div className="space-y-2">
                <Label htmlFor="documentType">Tipe Dokumen *</Label>
                <Select value={formData.documentType} onValueChange={(value) => handleSelectChange('documentType', value)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{documentTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent>
                </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="uploadDate">Tanggal Upload *</Label>
              <Input id="uploadDate" type="date" value={formData.uploadDate} onChange={handleInputChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="expiryDate">Tanggal Kadaluarsa (Opsional)</Label>
              <Input id="expiryDate" type="date" value={formData.expiryDate} onChange={handleInputChange} />
            </div>
          </div>
          
          <div className="space-y-2">
              <Label htmlFor="fileReference">Referensi File / Path *</Label>
              <Input id="fileReference" value={formData.fileReference} onChange={handleInputChange} placeholder="/docs/EXC-001_SLO.pdf" required />
              <p className="text-xs text-muted-foreground">Ini adalah path atau link ke file, bukan upload file langsung.</p>
          </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="responsiblePerson">Penanggung Jawab *</Label>
                    <Input id="responsiblePerson" value={formData.responsiblePerson} onChange={handleInputChange} placeholder="Andi Wijaya" required />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="status">Status Dokumen *</Label>
                    <Select value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>{documentStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
           </div>

          <div className="space-y-2">
            <Label htmlFor="documentDescription">Deskripsi</Label>
            <Textarea id="documentDescription" value={formData.documentDescription} onChange={handleInputChange} placeholder="Deskripsi singkat mengenai isi dan kegunaan dokumen..." rows={3} />
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{document ? 'Perbarui Dokumen' : 'Simpan Dokumen'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default DocumentFormDialog;