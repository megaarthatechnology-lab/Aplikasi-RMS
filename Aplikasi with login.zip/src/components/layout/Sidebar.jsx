import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Book, Briefcase, Building2, ChevronDown, ChevronRight, ClipboardList,
  FileText, Landmark, LayoutDashboard, Package, Receipt, Repeat,
  Settings, ShoppingCart, Truck, Users, Wrench
} from 'lucide-react';
import { cn } from '@/lib/utils';

const menuItems = [
  {
    title: 'Daftar Perkiraan',
    icon: Book,
    submenus: [
      { title: 'Jurnal & Buku Besar', path: '/jurnal-buku-besar' },
    ],
  },
  {
    title: 'Laporan Keuangan',
    icon: FileText,
    submenus: [
      { title: 'Laporan Laba/Rugi', path: '/laporan-laba-rugi' },
      { title: 'Laporan Perubahan Ekuitas', path: '/laporan-perubahan-ekuitas' },
      { title: 'Neraca', path: '/neraca' },
      { title: 'Laporan Arus Kas', path: '/laporan-arus-kas' },
      { title: 'Catatan Atas Laporan Keuangan', path: '/catatan-laporan-keuangan' },
    ],
  },
  {
    title: 'Daftar Proyek',
    icon: Briefcase,
    submenus: [
      { title: 'Laporan Progres Proyek', path: '/laporan-progres-proyek' },
    ],
  },
  {
    title: 'Pegawai Proyek',
    icon: Users,
    submenus: [
      { title: 'Rekap Karyawan', path: '/rekap-karyawan' },
      { title: 'Mutasi Alat', path: '/mutasi-alat' },
    ],
  },
  {
    title: 'Pemakaian Bahan',
    icon: Wrench,
    submenus: [
      { title: 'Pemakaian Bahan Baku', path: '/pemakaian-bahan-baku' },
      { title: 'Pemakaian Oli & BBM', path: '/pemakaian-oli-bbm' },
      { title: 'Pemakaian Sparepart', path: '/pemakaian-sparepart' },
    ],
  },
  {
    title: 'Transaksi Berulang',
    icon: Repeat,
    path: '/transaksi-berulang',
  },
  {
    title: 'Hutang',
    icon: Receipt,
    submenus: [
      { title: 'Info Dokumen Hutang', path: '/info-dokumen-hutang' },
      { title: 'Jadwal Pembayaran Hutang', path: '/jadwal-pembayaran-hutang' },
    ],
  },
  {
    title: 'Daftar Piutang',
    icon: ClipboardList,
    submenus: [
      { title: 'Invoice Dikeluarkan', path: '/daftar-invoice-keluar' },
      { title: 'Invoice Dibayar', path: '/daftar-invoice-bayar' },
    ],
  },
  {
    title: 'Perpajakan',
    icon: Landmark,
    submenus: [
      { title: 'Pajak Bayar Dimuka', path: '/pajak-bayar-dimuka' },
    ],
  },
  {
    title: 'Pembayaran',
    icon: Landmark,
    submenus: [
      { title: 'Pembayaran & Transfer Bank', path: '/pembayaran-transfer-bank' },
    ],
  },
  {
    title: 'Aset',
    icon: Building2,
    submenus: [
      { title: 'Daftar Aset', path: '/daftar-aset' },
      { title: 'Lokasi Aset', path: '/lokasi-aset' },
      { title: 'Jadwal Perawatan Aset', path: '/jadwal-perawatan-aset' },
      { title: 'Monitoring Dokumen Aset', path: '/monitoring-dokumen-aset' },
    ],
  },
  {
    title: 'Daftar Kontrak',
    icon: Package,
    submenus: [
      { title: 'Sort by Supplier', path: '/kontrak-by-supplier' },
      { title: 'Sort by Jenis Barang', path: '/kontrak-by-jenis-barang' },
      { title: 'Sort by Buyer', path: '/kontrak-by-buyer' },
    ],
  },
];

const NavItem = ({ item }) => {
  const [isOpen, setIsOpen] = useState(false);
  const hasSubmenus = item.submenus && item.submenus.length > 0;

  const baseLinkClasses = "flex items-center p-3 my-1 rounded-lg transition-colors duration-200";
  const inactiveLinkClasses = "text-gray-300 hover:bg-gray-700 hover:text-white";
  const activeLinkClasses = "bg-purple-600 text-white shadow-lg";

  if (!hasSubmenus) {
    return (
      <NavLink
        to={item.path}
        className={({ isActive }) => cn(baseLinkClasses, isActive ? activeLinkClasses : inactiveLinkClasses)}
      >
        <item.icon className="w-5 h-5 mr-3 flex-shrink-0" />
        <span className="flex-1">{item.title}</span>
      </NavLink>
    );
  }

  return (
    <div>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(baseLinkClasses, "w-full text-left", inactiveLinkClasses)}
      >
        <item.icon className="w-5 h-5 mr-3 flex-shrink-0" />
        <span className="flex-1">{item.title}</span>
        <motion.div animate={{ rotate: isOpen ? 90 : 0 }}>
          <ChevronRight className="w-4 h-4" />
        </motion.div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="pl-6 overflow-hidden"
          >
            {item.submenus.map((submenu) => (
              <NavLink
                key={submenu.title}
                to={submenu.path}
                className={({ isActive }) => cn("flex items-center p-2 my-1 rounded-md text-sm transition-colors", isActive ? "text-purple-400 font-semibold" : "text-gray-400 hover:text-white")}
              >
                {submenu.title}
              </NavLink>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const Sidebar = () => {
  return (
    <div className="w-64 bg-gray-800 text-white flex flex-col h-screen p-4 shadow-2xl">
      <div className="flex items-center mb-8 p-2">
        <img  alt="Logo Perusahaan Akuntansi" class="w-10 h-10 mr-3" src="https://images.unsplash.com/photo-1649916418827-bc6ca1f9a30a" />
        <h1 className="text-xl font-bold tracking-wider">AkuntansiPro</h1>
      </div>
      <nav className="flex-1 overflow-y-auto pr-2">
        <NavLink
          to="/"
          className={({ isActive }) => cn("flex items-center p-3 my-1 rounded-lg transition-colors duration-200", isActive ? "bg-purple-600 text-white shadow-lg" : "text-gray-300 hover:bg-gray-700 hover:text-white")}
        >
          <LayoutDashboard className="w-5 h-5 mr-3" />
          <span>Dashboard</span>
        </NavLink>
        {menuItems.map((item) => (
          <NavItem key={item.title} item={item} />
        ))}
      </nav>
      <div className="mt-auto">
        <button className="flex items-center p-3 w-full rounded-lg text-gray-300 hover:bg-gray-700 hover:text-white">
          <Settings className="w-5 h-5 mr-3" />
          <span>Pengaturan</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;