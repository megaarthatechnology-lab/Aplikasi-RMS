import React from 'react';
import { Bell, Search, UserCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const Header = ({ pageTitle }) => {
  const { toast } = useToast();

  const handleSearch = () => {
    toast({
      title: "Fitur Dalam Pengembangan 🚧",
      description: "Fitur pencarian ini belum diimplementasikan. Anda bisa memintanya di prompt berikutnya! 🚀",
    });
  };

  return (
    <header className="bg-gray-800/50 backdrop-blur-sm border-b border-gray-700 p-4 flex items-center justify-between sticky top-0 z-10">
      <h1 className="text-2xl font-bold text-white">{pageTitle}</h1>
      <div className="flex items-center gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Cari transaksi, laporan..."
            className="bg-gray-700 border border-gray-600 text-white placeholder-gray-400 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full pl-10 p-2.5 transition"
            onFocus={handleSearch}
          />
        </div>
        <Button variant="ghost" size="icon" className="text-gray-300 hover:bg-gray-700 hover:text-white">
          <Bell className="h-6 w-6" />
        </Button>
        <Button variant="ghost" size="icon" className="text-gray-300 hover:bg-gray-700 hover:text-white">
          <UserCircle className="h-6 w-6" />
        </Button>
      </div>
    </header>
  );
};

export default Header;