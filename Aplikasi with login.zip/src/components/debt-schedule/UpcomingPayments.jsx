import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableRow } from '@/components/ui/table';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';
import { formatCurrency } from '@/lib/debt-utils';
import { CalendarClock } from 'lucide-react';

const UpcomingPayments = ({ schedules, debts }) => {
  const upcoming = useMemo(() => {
    const allUpcoming = [];
    const today = new Date('2025-11-17');

    Object.keys(schedules).forEach(debtId => {
      const debt = debts.find(d => d.id.toString() === debtId);
      if (debt) {
        const firstPending = schedules[debtId]
          .map(p => ({...p, paymentDate: new Date(p.paymentDate)}))
          .filter(p => p.status === 'pending' && p.paymentDate >= today)
          .sort((a, b) => a.paymentDate - b.paymentDate)[0];
        
        if (firstPending) {
          allUpcoming.push({
            ...firstPending,
            debtId: debtId,
            creditor: debt.creditor,
          });
        }
      }
    });

    return allUpcoming.sort((a, b) => a.paymentDate - b.paymentDate).slice(0, 5);
  }, [schedules, debts]);

  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CalendarClock className="w-6 h-6 text-blue-400" />
          <span>5 Pembayaran Terdekat</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {upcoming.length > 0 ? (
          <div className="overflow-x-auto">
            <Table>
              <TableBody>
                {upcoming.map(p => (
                  <TableRow key={`${p.debtId}-${p.paymentNumber}`}>
                    <TableCell className="font-medium text-slate-200">{p.creditor}</TableCell>
                    <TableCell className="text-right font-semibold text-lg text-amber-400">{formatCurrency(p.paymentAmount)}</TableCell>
                    <TableCell className="text-right text-slate-400">
                      {format(p.paymentDate, 'dd MMMM yyyy', { locale: id })}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="text-center py-8 text-slate-400">
            <p>Tidak ada pembayaran yang akan datang.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default UpcomingPayments;