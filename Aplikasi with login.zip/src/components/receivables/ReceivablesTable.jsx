import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency, getReceivableStatusBadge } from '@/lib/receivables-utils.jsx';

const ReceivablesTable = ({ receivables, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Daftar Piutang</CardTitle>
        <CardDescription>Menampilkan {receivables.length} data piutang yang sesuai.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Pelanggan</TableHead>
                <TableHead>No. Invoice</TableHead>
                <TableHead>Jumlah</TableHead>
                <TableHead>Tgl. Terbit</TableHead>
                <TableHead>Jatuh Tempo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {receivables.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada data piutang</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan data piutang baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                receivables.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">
                        <div>{r.customerName}</div>
                        {r.description && <div className="text-xs text-slate-400 mt-1 truncate max-w-xs">{r.description}</div>}
                    </TableCell>
                    <TableCell>{r.invoiceNumber}</TableCell>
                    <TableCell>{formatCurrency(r.amount)}</TableCell>
                    <TableCell>{format(new Date(r.issueDate), 'dd MMM yyyy')}</TableCell>
                    <TableCell>{format(new Date(r.dueDate), 'dd MMM yyyy')}</TableCell>
                    <TableCell>{getReceivableStatusBadge(r.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(r)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(r.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default ReceivablesTable;