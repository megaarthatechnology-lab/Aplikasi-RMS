import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { receivableStatusOptions } from '@/lib/receivables-utils.jsx';
import { format } from 'date-fns';

const ReceivableFormDialog = ({ isOpen, onClose, onSave, receivable }) => {
  const getInitialFormData = () => ({
    customerName: '',
    amount: '',
    invoiceNumber: '',
    issueDate: format(new Date(), 'yyyy-MM-dd'),
    dueDate: format(new Date(), 'yyyy-MM-dd'),
    status: 'pending',
    description: '',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (receivable) {
        setFormData({
          customerName: receivable.customerName,
          amount: receivable.amount.toString(),
          invoiceNumber: receivable.invoiceNumber,
          issueDate: receivable.issueDate,
          dueDate: receivable.dueDate,
          status: receivable.status,
          description: receivable.description || '',
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [receivable, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.customerName || !formData.amount || !formData.invoiceNumber || !formData.issueDate || !formData.dueDate) {
      toast({ title: '⚠️ Data Tidak Lengkap', description: 'Mohon lengkapi semua field yang wajib diisi.', variant: 'destructive' });
      return;
    }
    if (new Date(formData.dueDate) < new Date(formData.issueDate)) {
      toast({ title: '⚠️ Tanggal Tidak Valid', description: 'Tanggal jatuh tempo tidak boleh sebelum tanggal terbit.', variant: 'destructive' });
      return;
    }
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{receivable ? 'Edit Piutang' : 'Tambah Piutang Baru'}</DialogTitle>
          <DialogDescription>{receivable ? 'Perbarui informasi piutang.' : 'Buat catatan piutang baru.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div className="space-y-2">
                <Label htmlFor="customerName">Nama Pelanggan *</Label>
                <Input id="customerName" value={formData.customerName} onChange={handleInputChange} placeholder="Contoh: PT. Maju Mundur" required />
            </div>
            <div className="space-y-2">
                <Label htmlFor="invoiceNumber">No. Invoice *</Label>
                <Input id="invoiceNumber" value={formData.invoiceNumber} onChange={handleInputChange} placeholder="INV/2025/11/001" required />
            </div>
          </div>
          <div className="space-y-2">
              <Label htmlFor="amount">Jumlah (IDR) *</Label>
              <Input id="amount" type="number" value={formData.amount} onChange={handleInputChange} placeholder="150000000" required min="0" />
            </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="issueDate">Tanggal Terbit *</Label>
              <Input id="issueDate" type="date" value={formData.issueDate} onChange={handleInputChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate">Tanggal Jatuh Tempo *</Label>
              <Input id="dueDate" type="date" value={formData.dueDate} onChange={handleInputChange} required />
            </div>
          </div>
           <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{receivableStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          <div className="space-y-2">
            <Label htmlFor="description">Deskripsi</Label>
            <Textarea id="description" value={formData.description} onChange={handleInputChange} placeholder="Tambahkan deskripsi atau catatan tambahan..." />
          </div>
          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{receivable ? 'Perbarui Data' : 'Tambah Piutang'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ReceivableFormDialog;