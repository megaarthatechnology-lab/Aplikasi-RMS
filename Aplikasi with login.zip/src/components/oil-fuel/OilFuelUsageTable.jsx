import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency } from '@/lib/utils';
import { getOilFuelStatusBadge } from '@/lib/oil-fuel-utils.jsx';
import { Badge } from '@/components/ui/badge';

const OilFuelUsageTable = ({ usages, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Daftar Pemakaian Oli & BBM</CardTitle>
        <CardDescription>Menampilkan {usages.length} catatan pemakaian yang sesuai.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nama Produk</TableHead>
                <TableHead>Jumlah & Satuan</TableHead>
                <TableHead>Referensi & Tanggal</TableHead>
                <TableHead>Biaya</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {usages.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada data pemakaian</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan data baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                usages.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell>
                      <div className="font-bold">{u.productName}</div>
                      {u.description && <div className="text-xs text-slate-400 mt-1 max-w-xs truncate" title={u.description}>{u.description}</div>}
                    </TableCell>
                    <TableCell>
                        <span className="font-mono font-semibold">{u.quantity}</span> {u.unit}
                    </TableCell>
                    <TableCell>
                        <Badge variant="secondary">{u.reference}</Badge>
                        <div className="text-sm text-slate-400 mt-1">{format(new Date(u.date), 'dd MMM yyyy')}</div>
                    </TableCell>
                    <TableCell className="font-semibold">{formatCurrency(u.cost)}</TableCell>
                    <TableCell>{getOilFuelStatusBadge(u.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(u)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(u.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default OilFuelUsageTable;