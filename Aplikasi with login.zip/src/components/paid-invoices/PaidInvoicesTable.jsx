import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { format } from 'date-fns';
import { formatCurrency } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const PaidInvoicesTable = ({ invoices }) => {
  return (
    <Card className="glass-effect print:shadow-none print:border-none print:bg-white print:text-black">
      <CardHeader className="print-hidden">
        <CardTitle>Riwayat Invoice Lunas</CardTitle>
        <CardDescription>Menampilkan {invoices.length} invoice yang telah dibayar.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="print:border-b-2 print:border-black">
                <TableHead className="print:text-black">No. Invoice</TableHead>
                <TableHead className="print:text-black">Pelanggan</TableHead>
                <TableHead className="print:text-black">Tgl. Pembayaran</TableHead>
                <TableHead className="print:text-black">Metode Bayar</TableHead>
                <TableHead className="text-right print:text-black">Jumlah</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoices.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-12 text-muted-foreground print:text-black">
                    <p className="font-semibold">Tidak ada invoice lunas ditemukan</p>
                    <p className="text-sm">Coba sesuaikan filter pencarian Anda.</p>
                  </TableCell>
                </TableRow>
              ) : (
                invoices.map((i) => (
                  <TableRow key={i.id} className="print:border-b print:border-gray-300">
                    <TableCell className="font-mono print:text-black">{i.invoiceNumber}</TableCell>
                    <TableCell className="font-medium print:text-black">{i.customerName}</TableCell>
                    <TableCell className="print:text-black">{format(new Date(i.paymentDate), 'dd MMM yyyy')}</TableCell>
                    <TableCell>
                        <Badge variant="secondary" className="bg-slate-700 text-slate-200 print:bg-gray-200 print:text-black">{i.paymentMethod}</Badge>
                    </TableCell>
                    <TableCell className="text-right font-semibold print:text-black">{formatCurrency(i.amount)}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default PaidInvoicesTable;