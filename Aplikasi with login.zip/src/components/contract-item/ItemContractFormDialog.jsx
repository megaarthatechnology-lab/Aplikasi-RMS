
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { contractStatusOptions } from '@/lib/contract-item-utils.jsx';
import { format } from 'date-fns';

const ItemContractFormDialog = ({ isOpen, onClose, onSave, contract }) => {
  const getInitialFormData = () => ({
    itemName: '',
    itemCode: '',
    contractNumber: '',
    supplierName: '',
    unitPrice: '',
    minOrderQuantity: '',
    maxOrderQuantity: '',
    startDate: format(new Date(), 'yyyy-MM-dd'),
    endDate: '',
    contractStatus: 'Draft',
    notes: '',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (contract) {
        setFormData({
          ...contract,
          unitPrice: contract.unitPrice.toString(),
          minOrderQuantity: contract.minOrderQuantity.toString(),
          maxOrderQuantity: contract.maxOrderQuantity.toString(),
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [contract, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredFields = ['itemName', 'itemCode', 'contractNumber', 'supplierName', 'unitPrice', 'minOrderQuantity', 'maxOrderQuantity', 'startDate', 'endDate', 'contractStatus'];
    for (const field of requiredFields) {
      const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      if (!formData[field]) {
        toast({ title: '⚠️ Data Tidak Lengkap', description: `Mohon lengkapi field "${fieldName}" yang wajib diisi.`, variant: 'destructive' });
        return;
      }
    }
    if (isNaN(parseFloat(formData.unitPrice)) || isNaN(parseInt(formData.minOrderQuantity, 10)) || isNaN(parseInt(formData.maxOrderQuantity, 10))) {
        toast({ title: '⚠️ Data Tidak Valid', description: 'Harga dan kuantitas harus berupa angka.', variant: 'destructive' });
        return;
    }
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{contract ? 'Edit Kontrak Item' : 'Tambah Kontrak Item'}</DialogTitle>
          <DialogDescription>{contract ? 'Perbarui detail kontrak untuk item ini.' : 'Buat catatan kontrak baru untuk sebuah item.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="itemName">Nama Item *</Label>
              <Input id="itemName" value={formData.itemName} onChange={handleInputChange} placeholder="Semen PCC" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="itemCode">Kode Item *</Label>
              <Input id="itemCode" value={formData.itemCode} onChange={handleInputChange} placeholder="MT-CEM-001" required />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="contractNumber">Nomor Kontrak *</Label>
              <Input id="contractNumber" value={formData.contractNumber} onChange={handleInputChange} placeholder="ITM-2025-001" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="supplierName">Nama Supplier *</Label>
              <Input id="supplierName" value={formData.supplierName} onChange={handleInputChange} placeholder="PT. Semen Abadi" required />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="unitPrice">Harga per Unit (IDR) *</Label>
              <Input id="unitPrice" type="number" value={formData.unitPrice} onChange={handleInputChange} placeholder="1200000" min="0" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="minOrderQuantity">Min. Order Quantity *</Label>
              <Input id="minOrderQuantity" type="number" value={formData.minOrderQuantity} onChange={handleInputChange} placeholder="100" min="0" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="maxOrderQuantity">Max. Order Quantity *</Label>
              <Input id="maxOrderQuantity" type="number" value={formData.maxOrderQuantity} onChange={handleInputChange} placeholder="1000" min="0" required />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">Tanggal Mulai Kontrak *</Label>
              <Input id="startDate" type="date" value={formData.startDate} onChange={handleInputChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endDate">Tanggal Berakhir Kontrak *</Label>
              <Input id="endDate" type="date" value={formData.endDate} onChange={handleInputChange} required />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="contractStatus">Status Kontrak *</Label>
            <Select value={formData.contractStatus} onValueChange={(value) => handleSelectChange('contractStatus', value)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{contractStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Catatan</Label>
            <Textarea id="notes" value={formData.notes} onChange={handleInputChange} placeholder="Deskripsi atau catatan tambahan..." rows={3} />
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{contract ? 'Perbarui Kontrak' : 'Simpan Kontrak'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ItemContractFormDialog;
