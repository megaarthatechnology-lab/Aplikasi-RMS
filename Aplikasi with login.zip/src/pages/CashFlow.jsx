import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Calendar, Download, Printer, TrendingUp, TrendingDown, ChevronsRight, ChevronsLeft, Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const CashFlow = () => {
  const { toast } = useToast();

  const handleAction = (action) => {
    toast({
      title: `📊 ${action}`,
      description: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const cashFlowData = {
    operating: {
      inflows: [
        { name: 'Penerimaan dari Pelanggan', amount: 2800000000 },
        { name: 'Penerimaan Bunga', amount: 25000000 },
      ],
      outflows: [
        { name: 'Pembayaran kepada Pemasok', amount: 1800000000 },
        { name: 'Pembayaran Gaji dan Tunjangan', amount: 800000000 },
        { name: 'Pembayaran Beban Operasional', amount: 150000000 },
        { name: 'Pembayaran Bunga', amount: 30000000 },
        { name: 'Pembayaran Pajak', amount: 75000000 },
      ],
    },
    investing: {
      inflows: [
        { name: 'Penjualan Aset Tetap', amount: 50000000 },
      ],
      outflows: [
        { name: 'Pembelian Peralatan Baru', amount: 250000000 },
        { name: 'Investasi Jangka Panjang', amount: 100000000 },
      ],
    },
    financing: {
      inflows: [
        { name: 'Penerimaan dari Pinjaman Bank', amount: 400000000 },
      ],
      outflows: [
        { name: 'Pembayaran Pokok Pinjaman', amount: 150000000 },
        { name: 'Pembayaran Dividen', amount: 200000000 },
      ],
    },
    beginningCashBalance: 120000000,
  };

  const totalInflowsOperating = cashFlowData.operating.inflows.reduce((sum, item) => sum + item.amount, 0);
  const totalOutflowsOperating = cashFlowData.operating.outflows.reduce((sum, item) => sum + item.amount, 0);
  const netOperatingCashFlow = totalInflowsOperating - totalOutflowsOperating;

  const totalInflowsInvesting = cashFlowData.investing.inflows.reduce((sum, item) => sum + item.amount, 0);
  const totalOutflowsInvesting = cashFlowData.investing.outflows.reduce((sum, item) => sum + item.amount, 0);
  const netInvestingCashFlow = totalInflowsInvesting - totalOutflowsInvesting;

  const totalInflowsFinancing = cashFlowData.financing.inflows.reduce((sum, item) => sum + item.amount, 0);
  const totalOutflowsFinancing = cashFlowData.financing.outflows.reduce((sum, item) => sum + item.amount, 0);
  const netFinancingCashFlow = totalInflowsFinancing - totalOutflowsFinancing;

  const netCashChange = netOperatingCashFlow + netInvestingCashFlow + netFinancingCashFlow;
  const endingCashBalance = cashFlowData.beginningCashBalance + netCashChange;

  const formatCurrency = (amount) => {
    const formatted = new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(Math.abs(amount));
    return amount < 0 ? `(${formatted})` : formatted;
  };

  const Section = ({ title, inflows, outflows, net, color }) => (
    <div className="mb-8">
      <h3 className={`text-lg font-semibold text-${color}-400 mb-4`}>{title}</h3>
      <div className="space-y-2">
        {inflows.map((item, index) => (
          <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30">
            <span className="text-slate-300 flex items-center"><Plus className="h-4 w-4 mr-2 text-green-500"/>{item.name}</span>
            <span className="text-white font-semibold">{formatCurrency(item.amount)}</span>
          </div>
        ))}
        {outflows.map((item, index) => (
          <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30">
            <span className="text-slate-300 flex items-center"><Minus className="h-4 w-4 mr-2 text-red-500"/>{item.name}</span>
            <span className="text-white font-semibold">{formatCurrency(item.amount)}</span>
          </div>
        ))}
      </div>
      <div className={`flex justify-between items-center py-3 border-t-2 border-${color}-500/50 mt-2`}>
        <span className={`text-${color}-400 font-semibold`}>ARUS KAS BERSIH DARI {title.toUpperCase()}</span>
        <span className={`font-bold text-lg ${net >= 0 ? `text-${color}-400` : 'text-red-400'}`}>{formatCurrency(net)}</span>
      </div>
    </div>
  );

  return (
    <>
      <Helmet>
        <title>Laporan Arus Kas - Sistem Akuntansi Profesional</title>
        <meta name="description" content="Laporan arus kas yang merinci aliran kas dari aktivitas operasi, investasi, dan pendanaan." />
        <style type="text/css">{`
            @media print {
              body * {
                visibility: hidden;
              }
              .printable-area, .printable-area * {
                visibility: visible;
              }
              .printable-area {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
              }
              .no-print {
                display: none;
              }
            }
        `}</style>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between no-print"
        >
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Laporan Arus Kas</h1>
            <p className="text-slate-400">Analisis aliran masuk dan keluar kas perusahaan</p>
          </div>
          <div className="flex space-x-2 mt-4 md:mt-0">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-800 border-slate-700 text-white">
                <DropdownMenuItem onSelect={() => handleAction('Export to PDF')}>Export ke PDF</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleAction('Export to Excel')}>Export ke Excel</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button 
              onClick={handlePrint}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
            >
              <Printer className="h-4 w-4 mr-2" />
              Cetak
            </Button>
          </div>
        </motion.div>

        {/* Period Selection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass-effect rounded-xl p-6 no-print"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Periode</label>
              <Button 
                variant="outline"
                onClick={() => handleAction('Pilih Periode')}
                className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 justify-start"
              >
                <Calendar className="h-4 w-4 mr-2" />
                Januari 2024
              </Button>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Metode</label>
              <select className="w-full bg-slate-700/50 border border-slate-600 rounded-lg text-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500">
                <option>Metode Langsung</option>
                <option>Metode Tidak Langsung</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Summary Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 no-print"
        >
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Operasi</h3>
            <p className={`text-2xl font-bold ${netOperatingCashFlow >= 0 ? 'text-green-400' : 'text-red-400'}`}>{formatCurrency(netOperatingCashFlow)}</p>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Investasi</h3>
            <p className={`text-2xl font-bold ${netInvestingCashFlow >= 0 ? 'text-green-400' : 'text-red-400'}`}>{formatCurrency(netInvestingCashFlow)}</p>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Pendanaan</h3>
            <p className={`text-2xl font-bold ${netFinancingCashFlow >= 0 ? 'text-green-400' : 'text-red-400'}`}>{formatCurrency(netFinancingCashFlow)}</p>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Perubahan Kas Bersih</h3>
            <p className={`text-2xl font-bold ${netCashChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>{formatCurrency(netCashChange)}</p>
            <div className={`flex items-center justify-center mt-2 ${netCashChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {netCashChange >= 0 ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
              <span className="text-sm">{((netCashChange / cashFlowData.beginningCashBalance) * 100).toFixed(1)}%</span>
            </div>
          </div>
        </motion.div>

        <div className="printable-area">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="glass-effect rounded-xl overflow-hidden"
          >
            <div className="p-6 border-b border-slate-700/50">
              <h2 className="text-xl font-semibold text-white text-center">PT. KONSTRUKSI INDONESIA</h2>
              <p className="text-slate-400 text-center mt-1">LAPORAN ARUS KAS</p>
              <p className="text-slate-400 text-center">Untuk Periode yang Berakhir 31 Januari 2024</p>
            </div>

            <div className="p-6 space-y-6">
              <Section title="Aktivitas Operasi" inflows={cashFlowData.operating.inflows} outflows={cashFlowData.operating.outflows} net={netOperatingCashFlow} color="green" />
              <Section title="Aktivitas Investasi" inflows={cashFlowData.investing.inflows} outflows={cashFlowData.investing.outflows} net={netInvestingCashFlow} color="blue" />
              <Section title="Aktivitas Pendanaan" inflows={cashFlowData.financing.inflows} outflows={cashFlowData.financing.outflows} net={netFinancingCashFlow} color="purple" />

              {/* Summary Section */}
              <div className="space-y-4 pt-6 border-t-2 border-slate-600">
                <div className="flex justify-between items-center text-lg">
                  <span className="text-slate-300 font-semibold">Kenaikan (Penurunan) Bersih Kas</span>
                  <span className={`font-bold ${netCashChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>{formatCurrency(netCashChange)}</span>
                </div>
                <div className="flex justify-between items-center text-lg">
                  <span className="text-slate-300 font-semibold">Saldo Kas Awal Periode</span>
                  <span className="text-white font-bold">{formatCurrency(cashFlowData.beginningCashBalance)}</span>
                </div>
                <div className="bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-lg p-6 mt-4 border border-cyan-500/30">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold text-xl">SALDO KAS AKHIR PERIODE</span>
                    <span className="text-2xl font-bold gradient-text">{formatCurrency(endingCashBalance)}</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default CashFlow;