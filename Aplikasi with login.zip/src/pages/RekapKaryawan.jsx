import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const RekapKaryawan = () => {
  return <PlaceholderPage title="Rekap Karyawan" description="Halaman untuk rekap data karyawan proyek." />;
};

export default RekapKaryawan;