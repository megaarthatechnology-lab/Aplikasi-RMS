import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const MonitoringDokumenAset = () => {
  return <PlaceholderPage title="Monitoring Dokumen Aset" description="Halaman untuk monitoring dokumen aset." />;
};

export default MonitoringDokumenAset;