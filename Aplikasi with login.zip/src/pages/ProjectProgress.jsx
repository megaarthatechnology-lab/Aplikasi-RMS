import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Download, Printer, Calendar, Flag, TrendingUp, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const PROJECT_STATUS = {
  Planning: { label: 'Perencanaan', color: 'bg-yellow-500/20 text-yellow-400', progressColor: 'bg-yellow-500' },
  InProgress: { label: 'Berlangsung', color: 'bg-blue-500/20 text-blue-400', progressColor: 'bg-blue-500' },
  Completed: { label: 'Selesai', color: 'bg-green-500/20 text-green-400', progressColor: 'bg-green-500' },
  OnHold: { label: 'Ditunda', color: 'bg-slate-500/20 text-slate-400', progressColor: 'bg-slate-500' },
  Cancelled: { label: 'Dibatalkan', color: 'bg-red-500/20 text-red-400', progressColor: 'bg-red-500' },
};

const defaultProjects = [
  {
    id: 'PRJ-001',
    name: 'Pembangunan Gedung Perkantoran ABC',
    description: 'Proyek pembangunan gedung 10 lantai di pusat kota dengan fasilitas modern.',
    status: 'InProgress',
    startDate: '2024-01-01',
    endDate: '2025-12-31',
    progress: 65,
  },
  {
    id: 'PRJ-002',
    name: 'Renovasi Pabrik XYZ',
    description: 'Renovasi dan modernisasi lini produksi pabrik untuk meningkatkan efisiensi.',
    status: 'Planning',
    startDate: '2025-02-01',
    endDate: '2025-08-31',
    progress: 10,
  },
];

const ProjectProgress = () => {
  const { toast } = useToast();
  const [projects, setProjects] = useState([]);
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [currentProgress, setCurrentProgress] = useState(0);

  useEffect(() => {
    try {
      const savedProjects = localStorage.getItem('projectList');
      const parsedProjects = savedProjects ? JSON.parse(savedProjects) : defaultProjects;
      setProjects(parsedProjects);
      if (parsedProjects.length > 0) {
        const firstInProgress = parsedProjects.find(p => p.status === 'InProgress') || parsedProjects[0];
        setSelectedProjectId(firstInProgress.id);
        setCurrentProgress(firstInProgress.progress);
      }
    } catch (error) {
      console.error("Gagal memuat proyek dari localStorage:", error);
      setProjects(defaultProjects);
    }
  }, []);

  const selectedProject = projects.find(p => p.id === selectedProjectId);

  const handleProjectChange = (projectId) => {
    setSelectedProjectId(projectId);
    const project = projects.find(p => p.id === projectId);
    if (project) {
      setCurrentProgress(project.progress);
    }
  };

  const handleProgressUpdate = () => {
    const updatedProjects = projects.map(p =>
      p.id === selectedProjectId ? { ...p, progress: currentProgress } : p
    );
    setProjects(updatedProjects);
    try {
      localStorage.setItem('projectList', JSON.stringify(updatedProjects));
      toast({
        title: "Progres Diperbarui",
        description: `Progres untuk proyek "${selectedProject.name}" telah diperbarui menjadi ${currentProgress}%.`,
      });
    } catch (error) {
      console.error("Gagal menyimpan progres ke localStorage:", error);
      toast({
        variant: "destructive",
        title: "Gagal Menyimpan",
        description: "Tidak dapat menyimpan perubahan ke penyimpanan lokal.",
      });
    }
  };

  const handleAction = (action) => {
    toast({
      title: `📊 ${action}`,
      description: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <>
      <Helmet>
        <title>Laporan Progres Proyek - Sistem Akuntansi</title>
        <meta name="description" content="Laporan detail mengenai progres proyek konstruksi." />
        <style type="text/css">{`
            @media print {
              body * { visibility: hidden; }
              .printable-area, .printable-area * { visibility: visible; }
              .printable-area { position: absolute; left: 0; top: 0; width: 100%; }
              .no-print { display: none; }
            }
        `}</style>
      </Helmet>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between no-print"
        >
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Laporan Progres Proyek</h1>
            <p className="text-slate-400">Analisis detail progres dan status proyek.</p>
          </div>
          <div className="flex space-x-2 mt-4 md:mt-0">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                  <Download className="h-4 w-4 mr-2" /> Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-800 border-slate-700 text-white">
                <DropdownMenuItem onSelect={() => handleAction('Export to PDF')}>Export ke PDF</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleAction('Export to Excel')}>Export ke Excel</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button onClick={handlePrint} className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700">
              <Printer className="h-4 w-4 mr-2" /> Cetak
            </Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass-effect rounded-xl p-6 no-print"
        >
          <Label htmlFor="project-select" className="text-slate-300">Pilih Proyek</Label>
          <Select value={selectedProjectId} onValueChange={handleProjectChange}>
            <SelectTrigger id="project-select" className="mt-2">
              <SelectValue placeholder="Pilih sebuah proyek..." />
            </SelectTrigger>
            <SelectContent>
              {projects.map(project => (
                <SelectItem key={project.id} value={project.id}>{project.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </motion.div>

        {selectedProject ? (
          <div className="printable-area">
            <motion.div
              key={selectedProjectId}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="glass-effect rounded-xl p-6"
            >
              <div className="border-b border-slate-700/50 pb-6 mb-6">
                <h2 className="text-2xl font-bold text-white">{selectedProject.name}</h2>
                <p className="text-slate-400 mt-1">{selectedProject.description}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-slate-800/50 p-4 rounded-lg flex items-center">
                  <div className="p-3 rounded-full bg-blue-500/20 mr-4">
                    <Flag className="h-6 w-6 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Status</p>
                    <p className={`font-semibold ${PROJECT_STATUS[selectedProject.status]?.color.replace('bg-', 'text-')}`}>{PROJECT_STATUS[selectedProject.status]?.label}</p>
                  </div>
                </div>
                <div className="bg-slate-800/50 p-4 rounded-lg flex items-center">
                  <div className="p-3 rounded-full bg-green-500/20 mr-4">
                    <Calendar className="h-6 w-6 text-green-400" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Timeline</p>
                    <p className="font-semibold text-white">{formatDate(selectedProject.startDate)} - {formatDate(selectedProject.endDate)}</p>
                  </div>
                </div>
                <div className="bg-slate-800/50 p-4 rounded-lg flex items-center">
                  <div className="p-3 rounded-full bg-purple-500/20 mr-4">
                    <TrendingUp className="h-6 w-6 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Progres Saat Ini</p>
                    <p className="font-semibold text-white">{selectedProject.progress}%</p>
                  </div>
                </div>
              </div>

              <div className="no-print">
                <h3 className="text-xl font-semibold text-white mb-4">Perbarui Progres Proyek</h3>
                <div className="bg-slate-800/50 p-6 rounded-lg">
                  <div className="flex items-center justify-between mb-4">
                    <Label htmlFor="progress-slider" className="text-lg font-medium">Persentase Progres: <span className="font-bold text-blue-400">{currentProgress}%</span></Label>
                    <div className="w-24">
                      <Input
                        type="number"
                        value={currentProgress}
                        onChange={(e) => setCurrentProgress(Math.max(0, Math.min(100, Number(e.target.value))))}
                        className="text-center"
                      />
                    </div>
                  </div>
                  <Slider
                    id="progress-slider"
                    value={[currentProgress]}
                    onValueChange={(value) => setCurrentProgress(value[0])}
                    max={100}
                    step={1}
                  />
                  <div className="flex justify-end mt-6">
                    <Button onClick={handleProgressUpdate} disabled={currentProgress === selectedProject.progress}>
                      <Edit className="h-4 w-4 mr-2" /> Simpan Perubahan Progres
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12 glass-effect rounded-xl"
          >
            <p className="text-slate-400">Silakan pilih proyek untuk melihat laporannya.</p>
          </motion.div>
        )}
      </div>
    </>
  );
};

export default ProjectProgress;