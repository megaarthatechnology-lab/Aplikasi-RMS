import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const KontrakBySupplier = () => {
  return <PlaceholderPage title="Kontrak Berdasarkan Pemasok" description="Halaman untuk melihat kontrak berdasarkan pemasok." />;
};

export default KontrakBySupplier;