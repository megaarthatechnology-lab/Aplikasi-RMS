import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

import StatCards from '@/components/employee-recap/StatCards';
import DepartmentChart from '@/components/employee-recap/DepartmentChart';
import StatusDonutChart from '@/components/employee-recap/StatusDonutChart';
import SalaryDistributionChart from '@/components/employee-recap/SalaryDistributionChart';

const defaultEmployees = [
  { id: 'EMP-001', name: 'Budi Santoso', position: 'Manajer Proyek', department: 'Teknik Sipil', salary: 15000000, status: 'Active' },
  { id: 'EMP-002', name: 'Citra Lestari', position: 'Arsitek', department: 'Desain', salary: 12000000, status: 'Active' },
  { id: 'EMP-003', name: 'Agus Wijaya', position: 'Mandor Lapangan', department: 'Konstruksi', salary: 8000000, status: 'OnLeave' },
  { id: 'EMP-004', name: 'Dewi Anggraini', position: 'Admin Proyek', department: 'Administrasi', salary: 6000000, status: 'Active' },
  { id: 'EMP-005', name: 'Eko Prasetyo', position: 'Pekerja Konstruksi', department: 'Konstruksi', salary: 4500000, status: 'Terminated' },
  { id: 'EMP-006', name: 'Fitriani', position: 'Estimator', department: 'Teknik Sipil', salary: 9000000, status: 'Active' },
  { id: 'EMP-007', name: 'Gunawan', position: 'Pekerja Konstruksi', department: 'Konstruksi', salary: 4800000, status: 'Active' },
];

const EmployeeRecap = () => {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    try {
      const savedEmployees = localStorage.getItem('employeeList');
      if (savedEmployees) {
        setEmployees(JSON.parse(savedEmployees));
      } else {
        setEmployees(defaultEmployees);
      }
    } catch (error) {
      console.error("Gagal memuat data karyawan dari localStorage:", error);
      setEmployees(defaultEmployees);
    }
  }, []);

  const employeeStats = useMemo(() => {
    if (employees.length === 0) {
      return {
        totalEmployees: 0,
        averageSalary: 0,
        totalDepartments: 0,
        mostCommonPosition: 'N/A',
        departmentDistribution: [],
        statusDistribution: [],
        salaryDistribution: [],
      };
    }

    // Basic Stats
    const totalEmployees = employees.length;
    const totalSalary = employees.reduce((sum, e) => sum + Number(e.salary), 0);
    const averageSalary = totalSalary / totalEmployees;
    const totalDepartments = new Set(employees.map(e => e.department)).size;

    // Position Stats
    const positionCounts = employees.reduce((acc, e) => {
      acc[e.position] = (acc[e.position] || 0) + 1;
      return acc;
    }, {});
    const mostCommonPosition = Object.entries(positionCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

    // Department Distribution
    const departmentCounts = employees.reduce((acc, e) => {
      acc[e.department] = (acc[e.department] || 0) + 1;
      return acc;
    }, {});
    const departmentDistribution = Object.entries(departmentCounts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);

    // Status Distribution
    const statusMap = { Active: 'Aktif', OnLeave: 'Cuti', Terminated: 'Diberhentikan' };
    const statusCounts = employees.reduce((acc, e) => {
      const statusName = statusMap[e.status] || 'Lainnya';
      acc[statusName] = (acc[statusName] || 0) + 1;
      return acc;
    }, {});
    const statusDistribution = Object.entries(statusCounts).map(([name, count]) => ({ name, count }));

    // Salary Distribution
    const salaryRanges = [
      { range: '< 5 Jt', min: 0, max: 4999999, count: 0 },
      { range: '5-10 Jt', min: 5000000, max: 10000000, count: 0 },
      { range: '10-15 Jt', min: 10000001, max: 15000000, count: 0 },
      { range: '> 15 Jt', min: 15000001, max: Infinity, count: 0 },
    ];
    employees.forEach(e => {
      const salary = Number(e.salary);
      const foundRange = salaryRanges.find(r => salary >= r.min && salary <= r.max);
      if (foundRange) {
        foundRange.count++;
      }
    });

    return {
      totalEmployees,
      averageSalary,
      totalDepartments,
      mostCommonPosition,
      departmentDistribution,
      statusDistribution,
      salaryDistribution: salaryRanges,
    };
  }, [employees]);

  return (
    <>
      <Helmet>
        <title>Rekap Karyawan - Sistem Akuntansi</title>
        <meta name="description" content="Analisis dan visualisasi data karyawan, termasuk statistik, demografi departemen, dan distribusi gaji." />
      </Helmet>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl font-bold gradient-text mb-2">Rekap Karyawan</h1>
          <p className="text-slate-400">Analisis visual dari data sumber daya manusia Anda.</p>
        </motion.div>

        <StatCards stats={employeeStats} />

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="lg:col-span-3"
          >
            <DepartmentChart data={employeeStats.departmentDistribution} />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="lg:col-span-2"
          >
            <StatusDonutChart data={employeeStats.statusDistribution} />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
        >
          <SalaryDistributionChart data={employeeStats.salaryDistribution} />
        </motion.div>
      </div>
    </>
  );
};

export default EmployeeRecap;