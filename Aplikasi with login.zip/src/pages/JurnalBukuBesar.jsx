import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const JurnalBukuBesar = () => {
  return <PlaceholderPage title="Jurnal & Buku Besar" description="Halaman untuk mengelola jurnal dan buku besar." />;
};

export default JurnalBukuBesar;