import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const MutasiAlat = () => {
  return <PlaceholderPage title="Mutasi Alat" description="Halaman untuk mengelola mutasi alat proyek." />;
};

export default MutasiAlat;