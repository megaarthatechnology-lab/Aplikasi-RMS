import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowUpRight, DollarSign, Receipt, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
const StatCard = ({
  title,
  value,
  icon: Icon,
  change,
  changeType
}) => <motion.div className="bg-gray-800 p-6 rounded-xl border border-gray-700/50 shadow-lg flex flex-col justify-between" whileHover={{
  y: -5,
  boxShadow: "0 10px 15px -3px rgba(99, 102, 241, 0.2), 0 4px 6px -2px rgba(99, 102, 241, 0.1)"
}} transition={{
  type: 'spring',
  stiffness: 300
}}>
    <div className="flex items-center justify-between mb-4">
      <p className="text-sm font-medium text-gray-400">{title}</p>
      <div className="bg-gray-700 p-2 rounded-lg">
        <Icon className="h-5 w-5 text-purple-400" />
      </div>
    </div>
    <div>
      <h3 className="text-3xl font-bold text-white">{value}</h3>
      <div className="flex items-center text-xs mt-1">
        <span className={`flex items-center font-semibold ${changeType === 'increase' ? 'text-green-400' : 'text-red-400'}`}>
          <ArrowUpRight className={`w-4 h-4 mr-1 ${changeType === 'decrease' && 'rotate-180'}`} />
          {change}
        </span>
        <span className="text-gray-500 ml-2">vs bulan lalu</span>
      </div>
    </div>
  </motion.div>;
const Dashboard = () => {
  const {
    toast
  } = useToast();
  const handleNotImplemented = () => {
    toast({
      title: "Fitur Dalam Pengembangan 🚧",
      description: "Fitur ini belum diimplementasikan. Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };
  return <>
      <Helmet>
        <title>Dashboard - AkuntansiPro</title>
        <meta name="description" content="Halaman utama dashboard AkuntansiPro." />
      </Helmet>
      <div className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard title="Total Pendapatan" value="Rp 1.2M" icon={DollarSign} change="+12.5%" changeType="increase" />
          <StatCard title="Total Pengeluaran" value="Rp 750Jt" icon={Receipt} change="+8.1%" changeType="increase" />
          <StatCard title="Laba Bersih" value="Rp 450Jt" icon={DollarSign} change="-2.3%" changeType="decrease" />
          <StatCard title="Klien Aktif" value="89" icon={Users} change="+5" changeType="increase" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.2
        }} className="lg:col-span-2 bg-gray-800 p-6 rounded-xl border border-gray-700/50 shadow-lg">
            <h2 className="text-xl font-semibold text-white mb-4">Cashflow</h2>
            <div className="h-64 flex items-center justify-center">
              <img alt="Grafik Arus Kas" class="w-full h-full object-contain" src="https://images.unsplash.com/photo-1616261167032-b16d2df8333b" />
            </div>
          </motion.div>
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.3
        }} className="bg-gray-800 p-6 rounded-xl border border-gray-700/50 shadow-lg">
            <h2 className="text-xl font-semibold text-white mb-4">Hutang & Piutang</h2>
            <div className="h-64 flex items-center justify-center">
              <img alt="Grafik Hutang vs Piutang" class="w-full h-full object-contain" src="https://images.unsplash.com/photo-1618044733300-9472054094ee" />
            </div>
          </motion.div>
        </div>

        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        delay: 0.4
      }} className="bg-gray-800 p-6 rounded-xl border border-gray-700/50 shadow-lg">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-white">Transaksi Terbaru</h2>
            <Button variant="ghost" onClick={handleNotImplemented}>Lihat Semua</Button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-gray-400">
              <thead className="text-xs text-gray-300 uppercase bg-gray-700/50">
                <tr>
                  <th scope="col" className="px-6 py-3">Tanggal</th>
                  <th scope="col" className="px-6 py-3">Deskripsi</th>
                  <th scope="col" className="px-6 py-3">Kategori</th>
                  <th scope="col" className="px-6 py-3">Jumlah</th>
                  <th scope="col" className="px-6 py-3">Status</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-700 hover:bg-gray-700/30">
                  <td className="px-6 py-4">2025-07-01</td>
                  <td className="px-6 py-4 text-white">Pembayaran Gaji Karyawan</td>
                  <td className="px-6 py-4">Operasional</td>
                  <td className="px-6 py-4 text-red-400">- Rp 150.000.000</td>
                  <td className="px-6 py-4"><span className="bg-green-900 text-green-300 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Selesai</span></td>
                </tr>
                <tr className="border-b border-gray-700 hover:bg-gray-700/30">
                  <td className="px-6 py-4">2025-06-28</td>
                  <td className="px-6 py-4 text-white">Penerimaan Invoice #INV-0123</td>
                  <td className="px-6 py-4">Pendapatan</td>
                  <td className="px-6 py-4 text-green-400">+ Rp 75.000.000</td>
                  <td className="px-6 py-4"><span className="bg-green-900 text-green-300 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Selesai</span></td>
                </tr>
                <tr className="border-b border-gray-700 hover:bg-gray-700/30">
                  <td className="px-6 py-4">2025-06-25</td>
                  <td className="px-6 py-4 text-white">Pembelian Bahan Baku</td>
                  <td className="px-6 py-4">HPP</td>
                  <td className="px-6 py-4 text-red-400">- Rp 45.000.000</td>
                  <td className="px-6 py-4"><span className="bg-yellow-900 text-yellow-300 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Tertunda</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </>;
};
export default Dashboard;