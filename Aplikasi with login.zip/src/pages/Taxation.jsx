import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getTaxRecords, saveTaxRecords } from '@/lib/taxation-api';

import FilterControls from '@/components/taxation/FilterControls';
import TaxationTable from '@/components/taxation/TaxationTable';
import TaxFormDialog from '@/components/taxation/TaxFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const Taxation = () => {
  const [taxRecords, setTaxRecords] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    taxType: '',
    taxPeriod: '',
    paymentStatus: '',
    filingStatus: '',
    startDate: '',
    endDate: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [recordToDelete, setRecordToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getTaxRecords();
    setTaxRecords(data);
  };

  const filteredRecords = useMemo(() => {
    return taxRecords.filter(record => {
      const searchMatch = !filters.searchTerm || 
        record.taxType.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        record.taxIdentificationNumber.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        (record.notes && record.notes.toLowerCase().includes(filters.searchTerm.toLowerCase()));
      
      const typeMatch = !filters.taxType || record.taxType === filters.taxType;
      const periodMatch = !filters.taxPeriod || record.taxPeriod === filters.taxPeriod;
      const paymentStatusMatch = !filters.paymentStatus || record.paymentStatus === filters.paymentStatus;
      const filingStatusMatch = !filters.filingStatus || record.filingStatus === filters.filingStatus;

      if (filters.startDate || filters.endDate) {
        if (!record.paymentDate) return false;
        const paymentDate = new Date(record.paymentDate);
        const startDate = filters.startDate ? new Date(filters.startDate) : null;
        const endDate = filters.endDate ? new Date(filters.endDate) : null;
        if (startDate) startDate.setHours(0, 0, 0, 0);
        if (endDate) endDate.setHours(23, 59, 59, 999);
        const dateRangeMatch = (!startDate || paymentDate >= startDate) && (!endDate || paymentDate <= endDate);
        return searchMatch && typeMatch && periodMatch && paymentStatusMatch && filingStatusMatch && dateRangeMatch;
      }

      return searchMatch && typeMatch && periodMatch && paymentStatusMatch && filingStatusMatch;
    });
  }, [taxRecords, filters]);

  const handleOpenForm = (record = null) => {
    setSelectedRecord(record);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedRecord(null);
  };

  const handleSaveRecord = (formData) => {
    let updatedRecords;
    const parsedData = {
      ...formData,
      taxBaseAmount: parseFloat(formData.taxBaseAmount),
      taxRate: parseFloat(formData.taxRate),
      taxAmountPayable: parseFloat(formData.taxAmountPayable),
    };

    if (selectedRecord) {
      updatedRecords = taxRecords.map(r => (r.id === selectedRecord.id ? { ...selectedRecord, ...parsedData } : r));
      toast({ title: "✅ Sukses", description: "Data pajak berhasil diperbarui." });
    } else {
      const newRecord = { ...parsedData, id: Date.now() };
      updatedRecords = [...taxRecords, newRecord];
      toast({ title: "✅ Sukses", description: "Data pajak baru berhasil ditambahkan." });
    }
    saveTaxRecords(updatedRecords);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setRecordToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedRecords = taxRecords.filter(r => r.id !== recordToDelete);
    saveTaxRecords(updatedRecords);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setRecordToDelete(null);
    toast({
      title: "🗑️ Data Dihapus",
      description: "Data pajak telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Perpajakan - Sistem Akuntansi</title>
        <meta name="description" content="Kelola dan lacak semua kewajiban perpajakan perusahaan dengan detail lengkap." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Manajemen Perpajakan</h1>
            <p className="text-muted-foreground">Kelola pembayaran dan pelaporan pajak perusahaan secara terpusat.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Tambah Data Pajak
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <TaxationTable
          records={filteredRecords}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <TaxFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveRecord}
        record={selectedRecord}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data pajak secara permanen dari sistem. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default Taxation;