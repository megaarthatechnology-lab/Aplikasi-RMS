import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getSparepartUsages, saveSparepartUsages } from '@/lib/sparepart-usage-api';

import FilterControls from '@/components/sparepart-usage/FilterControls';
import SparepartUsageTable from '@/components/sparepart-usage/SparepartUsageTable';
import SparepartUsageFormDialog from '@/components/sparepart-usage/SparepartUsageFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const SparepartUsage = () => {
  const [usages, setUsages] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    reference: '',
    supplier: '',
    startDate: '',
    endDate: '',
    minCost: '',
    maxCost: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedUsage, setSelectedUsage] = useState(null);
  const [usageToDelete, setUsageToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getSparepartUsages();
    setUsages(data);
  };

  const uniqueData = useMemo(() => {
      const allUsages = getSparepartUsages();
      const references = [...new Set(allUsages.map(u => u.reference))];
      const suppliers = [...new Set(allUsages.map(u => u.supplierName))];
      return { references, suppliers };
  }, []);

  const filteredUsages = useMemo(() => {
    return usages.filter(u => {
      const searchTermMatch = u.partName.toLowerCase().includes(filters.searchTerm.toLowerCase());
      const referenceMatch = !filters.reference || u.reference === filters.reference;
      const supplierMatch = !filters.supplier || u.supplierName === filters.supplier;

      const usageDate = new Date(u.date);
      const startDate = filters.startDate ? new Date(filters.startDate) : null;
      const endDate = filters.endDate ? new Date(filters.endDate) : null;
      if (startDate) startDate.setHours(0, 0, 0, 0);
      if (endDate) endDate.setHours(23, 59, 59, 999);
      const dateRangeMatch = (!startDate || usageDate >= startDate) && (!endDate || usageDate <= endDate);
      
      const minCost = filters.minCost ? parseFloat(filters.minCost) : null;
      const maxCost = filters.maxCost ? parseFloat(filters.maxCost) : null;
      const costMatch = (minCost === null || u.cost >= minCost) && (maxCost === null || u.cost <= maxCost);

      return searchTermMatch && referenceMatch && supplierMatch && dateRangeMatch && costMatch;
    });
  }, [usages, filters]);

  const handleOpenForm = (usage = null) => {
    setSelectedUsage(usage);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedUsage(null);
  };

  const handleSaveUsage = (formData) => {
    let updatedUsages;
    const parsedData = {
      ...formData,
      quantity: parseFloat(formData.quantity),
      cost: parseFloat(formData.cost),
    };

    if (selectedUsage) {
      updatedUsages = usages.map(u => (u.id === selectedUsage.id ? { ...selectedUsage, ...parsedData } : u));
      toast({ title: "✅ Sukses", description: "Data pemakaian spare part berhasil diperbarui." });
    } else {
      const newUsage = { ...parsedData, id: Date.now() };
      updatedUsages = [...usages, newUsage];
      toast({ title: "✅ Sukses", description: "Catatan pemakaian baru berhasil ditambahkan." });
    }
    saveSparepartUsages(updatedUsages);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setUsageToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedUsages = usages.filter(u => u.id !== usageToDelete);
    saveSparepartUsages(updatedUsages);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setUsageToDelete(null);
    toast({
      title: "🗑️ Catatan Dihapus",
      description: "Data pemakaian spare part telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Pemakaian Spare Part - Sistem Akuntansi</title>
        <meta name="description" content="Kelola, tambah, edit, dan lacak semua pemakaian spare part untuk kendaraan dan peralatan." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Pemakaian Spare Part</h1>
            <p className="text-muted-foreground">Lacak semua penggunaan suku cadang untuk pemeliharaan dan perbaikan.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Catat Pemakaian
          </Button>
        </div>

        <FilterControls 
            filters={filters} 
            setFilters={setFilters} 
            references={uniqueData.references}
            suppliers={uniqueData.suppliers}
        />

        <SparepartUsageTable
          usages={filteredUsages}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <SparepartUsageFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveUsage}
        usage={selectedUsage}
        references={uniqueData.references}
        suppliers={uniqueData.suppliers}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data pemakaian secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default SparepartUsage;