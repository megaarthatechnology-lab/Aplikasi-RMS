import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const JadwalPembayaranHutang = () => {
  return <PlaceholderPage title="Jadwal Pembayaran Hutang" description="Halaman untuk melihat jadwal pembayaran hutang." />;
};

export default JadwalPembayaranHutang;