import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Edit, Trash2, MoreHorizontal, Search, User, Shield, KeyRound, BarChart, Filter, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const USER_ROLES = {
  SuperAdmin: { label: 'Super Admin', color: 'text-red-400' },
  FinanceManager: { label: 'Manajer Keuangan', color: 'text-blue-400' },
  ProjectManager: { label: 'Manajer Proyek', color: 'text-green-400' },
  Viewer: { label: 'Pengamat', color: 'text-slate-400' },
};

const ACCESS_LEVELS = {
  FullAccess: { label: 'Akses Penuh' },
  ReadWrite: { label: 'Baca & Tulis' },
  ReadOnly: { label: 'Hanya Baca' },
};

const USER_STATUS = {
  Active: { label: 'Aktif', color: 'bg-green-500/20 text-green-400', icon: <CheckCircle /> },
  Suspended: { label: 'Ditangguhkan', color: 'bg-red-500/20 text-red-400', icon: <XCircle /> },
};

const defaultUsers = [
  {
    id: 'USR-001',
    name: 'Admin Utama',
    email: 'super.admin@perusahaan.com',
    role: 'SuperAdmin',
    accessLevel: 'FullAccess',
    status: 'Active',
  },
  {
    id: 'USR-002',
    name: 'Kepala Keuangan',
    email: 'finance.head@perusahaan.com',
    role: 'FinanceManager',
    accessLevel: 'ReadWrite',
    status: 'Active',
  },
  {
    id: 'USR-003',
    name: 'Manajer Proyek Senior',
    email: 'pm.senior@perusahaan.com',
    role: 'ProjectManager',
    accessLevel: 'ReadWrite',
    status: 'Active',
  },
  {
    id: 'USR-004',
    name: 'Auditor Eksternal',
    email: 'auditor@external.com',
    role: 'Viewer',
    accessLevel: 'ReadOnly',
    status: 'Suspended',
  },
];

const AdminPanel = () => {
  const { toast } = useToast();
  const [users, setUsers] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [userData, setUserData] = useState({
    id: '', name: '', email: '', role: 'Viewer', accessLevel: 'ReadOnly', status: 'Active'
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');

  useEffect(() => {
    try {
      const savedUsers = localStorage.getItem('adminUsers');
      if (savedUsers) {
        setUsers(JSON.parse(savedUsers));
      } else {
        setUsers(defaultUsers);
        localStorage.setItem('adminUsers', JSON.stringify(defaultUsers));
      }
    } catch (error) {
      console.error("Gagal memuat data pengguna dari localStorage:", error);
      setUsers(defaultUsers);
    }
  }, []);

  const saveUsersToLocalStorage = (updatedUsers) => {
    try {
      localStorage.setItem('adminUsers', JSON.stringify(updatedUsers));
    } catch (error) {
      console.error("Gagal menyimpan data pengguna ke localStorage:", error);
      toast({
        variant: "destructive",
        title: "Gagal Menyimpan Data",
        description: "Tidak dapat menyimpan perubahan ke penyimpanan lokal.",
      });
    }
  };

  const handleOpenDialog = (user = null) => {
    setCurrentUser(user);
    if (user) {
      setUserData(user);
    } else {
      const newId = `USR-${String(Date.now()).slice(-4)}`;
      setUserData({
        id: newId, name: '', email: '', role: 'Viewer', accessLevel: 'ReadOnly', status: 'Active'
      });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setCurrentUser(null);
  };

  const handleSaveUser = () => {
    if (!userData.name || !userData.email) {
      toast({
        variant: "destructive",
        title: "Gagal Menyimpan",
        description: "Nama dan Email harus diisi.",
      });
      return;
    }

    let updatedUsers;
    if (currentUser) {
      updatedUsers = users.map((u) =>
        u.id === currentUser.id ? { ...userData } : u
      );
      toast({ title: "Data Pengguna Diperbarui", description: `Data untuk "${userData.name}" berhasil diperbarui.` });
    } else {
      updatedUsers = [...users, userData];
      toast({ title: "Pengguna Ditambahkan", description: `Pengguna baru "${userData.name}" berhasil ditambahkan.` });
    }
    setUsers(updatedUsers);
    saveUsersToLocalStorage(updatedUsers);
    handleCloseDialog();
  };

  const handleDeleteUser = (userId) => {
    const updatedUsers = users.filter((u) => u.id !== userId);
    setUsers(updatedUsers);
    saveUsersToLocalStorage(updatedUsers);
    toast({ title: "Pengguna Dihapus", description: "Data pengguna telah berhasil dihapus." });
  };

  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            user.email.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = roleFilter === 'All' || user.role === roleFilter;
      return matchesSearch && matchesFilter;
    });
  }, [users, searchTerm, roleFilter]);

  return (
    <>
      <Helmet>
        <title>Panel Admin - Sistem Akuntansi</title>
        <meta name="description" content="Kelola pengguna, peran, dan hak akses untuk sistem akuntansi." />
      </Helmet>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Panel Admin</h1>
            <p className="text-slate-400">Kelola pengguna sistem, peran, dan tingkat akses.</p>
          </div>
          <Button onClick={() => handleOpenDialog()} className="mt-4 md:mt-0 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
            <Plus className="h-4 w-4 mr-2" />
            Tambah Pengguna
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass-effect p-4 rounded-xl flex flex-col md:flex-row gap-4"
        >
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 h-5 w-5" />
            <Input 
              placeholder="Cari berdasarkan nama atau email..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-slate-400" />
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Filter Peran" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">Semua Peran</SelectItem>
                {Object.entries(USER_ROLES).map(([key, { label }]) => (
                  <SelectItem key={key} value={key}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="glass-effect rounded-xl overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="border-b-slate-700 hover:bg-slate-800/60">
                  <TableHead><User className="inline-block h-4 w-4 mr-1" /> Nama Pengguna</TableHead>
                  <TableHead><Shield className="inline-block h-4 w-4 mr-1" /> Peran</TableHead>
                  <TableHead><KeyRound className="inline-block h-4 w-4 mr-1" /> Tingkat Akses</TableHead>
                  <TableHead><BarChart className="inline-block h-4 w-4 mr-1" /> Status</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <AnimatePresence>
                  {filteredUsers.length > 0 ? filteredUsers.map((user) => (
                    <motion.tr
                      key={user.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="border-b-slate-800"
                    >
                      <TableCell className="font-medium">
                        <div>{user.name}</div>
                        <div className="text-xs text-slate-400">{user.email}</div>
                      </TableCell>
                      <TableCell>
                        <span className={`font-semibold ${USER_ROLES[user.role]?.color}`}>
                          {USER_ROLES[user.role]?.label}
                        </span>
                      </TableCell>
                      <TableCell className="text-slate-300">{ACCESS_LEVELS[user.accessLevel]?.label}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1.5 ${USER_STATUS[user.status]?.color}`}>
                          {React.cloneElement(USER_STATUS[user.status]?.icon, { className: "h-3.5 w-3.5" })}
                          {USER_STATUS[user.status]?.label}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:bg-slate-700/50">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700 text-white">
                            <DropdownMenuItem onSelect={() => handleOpenDialog(user)} className="flex items-center">
                              <Edit className="h-4 w-4 mr-2" /> Edit
                            </DropdownMenuItem>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="flex items-center text-red-400 focus:bg-red-500/10 focus:text-red-400" disabled={user.role === 'SuperAdmin'}>
                                  <Trash2 className="h-4 w-4 mr-2" /> Hapus
                                </DropdownMenuItem>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Anda yakin ingin menghapus?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tindakan ini akan menghapus pengguna "{user.name}" secara permanen.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Batal</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDeleteUser(user.id)} className="bg-red-600 hover:bg-red-700">
                                    Hapus
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </motion.tr>
                  )) : (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center h-24 text-slate-400">
                        Tidak ada data pengguna yang cocok dengan kriteria Anda.
                      </TableCell>
                    </TableRow>
                  )}
                </AnimatePresence>
              </TableBody>
            </Table>
          </div>
        </motion.div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>{currentUser ? 'Edit Pengguna' : 'Tambah Pengguna Baru'}</DialogTitle>
              <DialogDescription>
                {currentUser ? 'Perbarui detail pengguna di bawah ini.' : 'Isi detail untuk pengguna baru.'}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                 <div className="space-y-2">
                    <Label htmlFor="name">Nama Lengkap</Label>
                    <Input id="name" value={userData.name} onChange={(e) => setUserData({ ...userData, name: e.target.value })} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="email">Alamat Email</Label>
                    <Input id="email" type="email" value={userData.email} onChange={(e) => setUserData({ ...userData, email: e.target.value })} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="role">Peran Pengguna</Label>
                  <Select value={userData.role} onValueChange={(value) => setUserData({ ...userData, role: value })} disabled={userData.role === 'SuperAdmin'}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(USER_ROLES).map(([key, { label }]) => (
                        <SelectItem key={key} value={key} disabled={key === 'SuperAdmin' && currentUser?.role !== 'SuperAdmin'}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="accessLevel">Tingkat Akses</Label>
                  <Select value={userData.accessLevel} onValueChange={(value) => setUserData({ ...userData, accessLevel: value })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(ACCESS_LEVELS).map(([key, { label }]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
               <div className="space-y-2">
                  <Label htmlFor="status">Status Akun</Label>
                  <Select value={userData.status} onValueChange={(value) => setUserData({ ...userData, status: value })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(USER_STATUS).map(([key, { label }]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
            </div>
            <DialogFooter>
              <DialogClose asChild><Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">Batal</Button></DialogClose>
              <Button onClick={handleSaveUser} className="bg-blue-600 hover:bg-blue-700">Simpan Perubahan</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default AdminPanel;