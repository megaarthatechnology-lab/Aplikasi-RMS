import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { User, Bell, Shield, Palette, Settings as CogIcon } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

import ProfileSettings from '@/components/settings/ProfileSettings';
import NotificationSettings from '@/components/settings/NotificationSettings';
import SecuritySettings from '@/components/settings/SecuritySettings';
import AppearanceSettings from '@/components/settings/AppearanceSettings';
import SystemConfigSettings from '@/components/settings/SystemConfigSettings';

const Settings = () => {
  return (
    <>
      <Helmet>
        <title>Pengaturan - Sistem Akuntansi</title>
        <meta name="description" content="Kelola profil, notifikasi, keamanan, dan tampilan aplikasi Anda." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-8"
      >
        <div>
          <h1 className="text-3xl font-bold gradient-text mb-2">Pengaturan Aplikasi</h1>
          <p className="text-muted-foreground">
            Kelola profil, notifikasi, keamanan, dan preferensi sistem Anda.
          </p>
        </div>

        <Tabs defaultValue="profile" className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-card/80 backdrop-blur-sm">
                <TabsTrigger value="profile"><User className="w-4 h-4 mr-2"/>Profil</TabsTrigger>
                <TabsTrigger value="notifications"><Bell className="w-4 h-4 mr-2"/>Notifikasi</TabsTrigger>
                <TabsTrigger value="appearance"><Palette className="w-4 h-4 mr-2"/>Tampilan</TabsTrigger>
                <TabsTrigger value="security"><Shield className="w-4 h-4 mr-2"/>Keamanan</TabsTrigger>
                <TabsTrigger value="system"><CogIcon className="w-4 h-4 mr-2"/>Sistem</TabsTrigger>
            </TabsList>
            
            <motion.div
                key="tab-content"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="mt-6"
            >
                <TabsContent value="profile">
                    <ProfileSettings />
                </TabsContent>
                <TabsContent value="notifications">
                    <NotificationSettings />
                </TabsContent>
                <TabsContent value="appearance">
                     <AppearanceSettings />
                </TabsContent>
                <TabsContent value="security">
                     <SecuritySettings />
                </TabsContent>
                <TabsContent value="system">
                     <SystemConfigSettings />
                </TabsContent>
            </motion.div>
        </Tabs>
      </motion.div>
    </>
  );
};

export default Settings;