import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { getTransactions, saveTransactions } from '@/lib/recurring-transactions-api';

import FilterControls from '@/components/recurring-transactions/FilterControls';
import RecurringTransactionsTable from '@/components/recurring-transactions/RecurringTransactionsTable';
import TransactionFormDialog from '@/components/recurring-transactions/TransactionFormDialog';
import TransactionHistoryDialog from '@/components/recurring-transactions/TransactionHistoryDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const RecurringTransactionsManage = () => {
  const [transactions, setTransactions] = useState([]);
  const [filters, setFilters] = useState({ searchTerm: '', status: 'all', frequency: 'all' });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [transactionToDelete, setTransactionToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getTransactions();
    setTransactions(data);
  };

  const filteredTransactions = useMemo(() => {
    return transactions
      .map(t => ({
        ...t,
        nextExecution: t.nextExecutionDate ? t.nextExecutionDate.toISOString().split('T')[0] : '-'
      }))
      .filter(t => {
        const searchTermMatch = t.name.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
          (t.category && t.category.toLowerCase().includes(filters.searchTerm.toLowerCase())) ||
          (t.description && t.description.toLowerCase().includes(filters.searchTerm.toLowerCase()));
        const statusMatch = filters.status === 'all' || t.status === filters.status;
        const frequencyMatch = filters.frequency === 'all' || t.frequency === filters.frequency;
        return searchTermMatch && statusMatch && frequencyMatch;
      });
  }, [transactions, filters]);

  const handleOpenForm = (transaction = null) => {
    setSelectedTransaction(transaction);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedTransaction(null);
  };

  const handleSaveTransaction = (formData) => {
    let updatedTransactions;
    if (selectedTransaction) {
      // Edit existing
      updatedTransactions = transactions.map(t =>
        t.id === selectedTransaction.id ? { ...selectedTransaction, ...formData, amount: parseFloat(formData.amount) } : t
      );
      toast({ title: "✅ Sukses", description: "Transaksi berhasil diperbarui." });
    } else {
      // Add new
      const newTransaction = {
        id: Date.now(),
        ...formData,
        amount: parseFloat(formData.amount),
        history: [],
      };
      updatedTransactions = [...transactions, newTransaction];
      toast({ title: "✅ Sukses", description: "Transaksi baru berhasil ditambahkan." });
    }
    saveTransactions(updatedTransactions);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setTransactionToDelete(id);
    setIsDeleteConfirmOpen(true);
  };
  
  const handleDeleteConfirm = () => {
    const updatedTransactions = transactions.filter(t => t.id !== transactionToDelete);
    saveTransactions(updatedTransactions);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setTransactionToDelete(null);
    toast({
      title: "🗑️ Transaksi Dihapus",
      description: "Transaksi berulang telah berhasil dihapus.",
      variant: "destructive"
    });
  };
  
  const handleToggleStatus = (id, newStatus) => {
    const updatedTransactions = transactions.map(t =>
      t.id === id ? { ...t, status: newStatus } : t
    );
    saveTransactions(updatedTransactions);
    reloadData();
    toast({ title: "🔄 Status Diperbarui", description: `Status transaksi diubah menjadi ${newStatus}.` });
  };
  
  const handleViewHistory = (transaction) => {
    setSelectedTransaction(transaction);
    setIsHistoryOpen(true);
  };

  const handleExecute = (id) => {
    const allTransactions = getTransactions();
    const transaction = allTransactions.find(t => t.id === id);
    if (!transaction) return;

    const newHistoryEntry = {
        date: new Date().toISOString(),
        amount: transaction.amount,
        status: 'Success'
    };

    const updatedTransactions = allTransactions.map(t =>
        t.id === id ? { ...t, history: [...(t.history || []), newHistoryEntry] } : t
    );
    
    saveTransactions(updatedTransactions);
    reloadData();
    toast({ title: "🚀 Eksekusi Manual", description: `Transaksi "${transaction.name}" berhasil dieksekusi.` });
  };

  return (
    <>
      <Helmet>
        <title>Kelola Transaksi Berulang - Sistem Akuntansi</title>
        <meta name="description" content="Kelola, tambah, edit, dan hapus semua transaksi berulang Anda." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Kelola Transaksi Berulang</h1>
            <p className="text-muted-foreground">
              Lihat, filter, dan kelola semua jadwal pembayaran Anda di satu tempat.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" asChild>
              <Link to="/recurring-transactions">
                <ArrowLeft className="mr-2 h-4 w-4" /> Kembali ke Dashboard
              </Link>
            </Button>
            <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
              <PlusCircle className="mr-2 h-4 w-4" /> Tambah Transaksi
            </Button>
          </div>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <RecurringTransactionsTable
          transactions={filteredTransactions}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
          onToggleStatus={handleToggleStatus}
          onViewHistory={handleViewHistory}
          onExecute={handleExecute}
        />
      </motion.div>

      <TransactionFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveTransaction}
        transaction={selectedTransaction}
      />

      <TransactionHistoryDialog
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        transaction={selectedTransaction}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda benar-benar yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini tidak dapat dibatalkan. Ini akan menghapus transaksi secara permanen dari daftar Anda.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default RecurringTransactionsManage;