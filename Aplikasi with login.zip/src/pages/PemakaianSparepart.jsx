import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const PemakaianSparepart = () => {
  return <PlaceholderPage title="Pemakaian Sparepart" description="Halaman untuk mencatat pemakaian sparepart." />;
};

export default PemakaianSparepart;