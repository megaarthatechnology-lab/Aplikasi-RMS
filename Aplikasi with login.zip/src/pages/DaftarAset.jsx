import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const DaftarAset = () => {
  return <PlaceholderPage title="Daftar Aset" description="Halaman untuk melihat daftar aset perusahaan." />;
};

export default DaftarAset;