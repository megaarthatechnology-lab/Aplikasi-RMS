import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const LaporanPerubahanEkuitas = () => {
  return <PlaceholderPage title="Laporan Perubahan Ekuitas" description="Halaman untuk melihat laporan perubahan ekuitas." />;
};

export default LaporanPerubahanEkuitas;