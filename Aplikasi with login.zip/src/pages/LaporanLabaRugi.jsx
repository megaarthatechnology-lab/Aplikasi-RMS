import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const LaporanLabaRugi = () => {
  return <PlaceholderPage title="Laporan Laba Rugi" description="Halaman untuk melihat laporan laba rugi." />;
};

export default LaporanLabaRugi;