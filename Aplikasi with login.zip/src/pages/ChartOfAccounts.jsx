import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Filter, Edit, Trash2, Eye, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const ChartOfAccounts = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [accounts, setAccounts] = useState([
    { code: '1000', name: 'Kas', type: 'Aset Lancar', balance: 'Rp 150.000.000' },
    { code: '1100', name: 'Bank BCA', type: 'Aset Lancar', balance: 'Rp 500.000.000' },
    { code: '1200', name: 'Piutang Usaha', type: 'Aset Lancar', balance: 'Rp 300.000.000' },
    { code: '1300', name: 'Persediaan', type: 'Aset Lancar', balance: 'Rp 200.000.000' },
    { code: '1400', name: 'Peralatan', type: 'Aset Tetap', balance: 'Rp 800.000.000' },
    { code: '2000', name: 'Hutang Usaha', type: 'Kewajiban Lancar', balance: 'Rp 180.000.000' },
    { code: '2100', name: 'Hutang Bank', type: 'Kewajiban Jangka Panjang', balance: 'Rp 400.000.000' },
    { code: '3000', name: 'Modal Saham', type: 'Ekuitas', balance: 'Rp 1.000.000.000' },
    { code: '4000', name: 'Pendapatan Jasa', type: 'Pendapatan', balance: 'Rp 2.450.000.000' },
    { code: '5000', name: 'Beban Gaji', type: 'Beban', balance: 'Rp 800.000.000' }
  ]);

  const [newAccount, setNewAccount] = useState({
    code: '',
    name: '',
    type: '',
    balance: '0'
  });

  const accountTypes = [
    'Aset Lancar',
    'Aset Tetap',
    'Kewajiban Lancar',
    'Kewajiban Jangka Panjang',
    'Ekuitas',
    'Pendapatan',
    'Beban'
  ];

  const handleAddAccount = (e) => {
    e.preventDefault();
    
    if (!newAccount.code || !newAccount.name || !newAccount.type) {
      toast({
        title: "⚠️ Data Tidak Lengkap",
        description: "Mohon lengkapi semua field yang diperlukan!",
        variant: "destructive"
      });
      return;
    }

    const formattedBalance = newAccount.balance === '0' ? 'Rp 0' : `Rp ${parseInt(newAccount.balance).toLocaleString('id-ID')}`;
    
    setAccounts([...accounts, { ...newAccount, balance: formattedBalance }]);
    
    toast({
      title: "✅ Akun Berhasil Ditambahkan",
      description: `Akun ${newAccount.name} (${newAccount.code}) telah ditambahkan ke daftar perkiraan.`
    });

    setShowAddModal(false);
    setNewAccount({ code: '', name: '', type: '', balance: '0' });
  };

  const handleAction = (action, account = null) => {
    toast({
      title: `📊 ${action}`,
      description: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };

  const filteredAccounts = accounts.filter(account => {
    const searchMatch = account.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      account.code.includes(searchTerm);
    const filterMatch = filterType === 'All' || account.type === filterType;
    return searchMatch && filterMatch;
  });

  return (
    <>
      <Helmet>
        <title>Daftar Perkiraan - Sistem Akuntansi Profesional</title>
        <meta name="description" content="Kelola daftar perkiraan akun dengan mudah. Lihat, tambah, edit, dan hapus akun keuangan perusahaan." />
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Daftar Perkiraan</h1>
            <p className="text-slate-400">Kelola chart of accounts perusahaan Anda</p>
          </div>
          <Button 
            onClick={() => setShowAddModal(true)}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 mt-4 md:mt-0"
          >
            <Plus className="h-4 w-4 mr-2" />
            Tambah Akun
          </Button>
        </motion.div>

        {/* Search and Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass-effect rounded-xl p-6"
        >
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Cari berdasarkan kode atau nama akun..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="outline" 
                  className="border-slate-600 text-slate-300 hover:bg-slate-700 w-full md:w-auto"
                >
                  <Filter className="h-4 w-4 mr-2" />
                  {filterType === 'All' ? 'Filter Jenis' : filterType}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 bg-slate-800 border-slate-700 text-white">
                <DropdownMenuLabel>Filter berdasarkan Jenis Akun</DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-slate-700" />
                <DropdownMenuRadioGroup value={filterType} onValueChange={setFilterType}>
                  <DropdownMenuRadioItem value="All">Semua Jenis</DropdownMenuRadioItem>
                  {accountTypes.map(type => (
                    <DropdownMenuRadioItem key={type} value={type}>{type}</DropdownMenuRadioItem>
                  ))}
                </DropdownMenuRadioGroup>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </motion.div>

        {/* Accounts Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="glass-effect rounded-xl overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-800/50">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Kode Akun</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Nama Akun</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Jenis</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Saldo</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-300">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                <AnimatePresence>
                  {filteredAccounts.length > 0 ? (
                    filteredAccounts.map((account, index) => (
                      <motion.tr
                        key={account.code}
                        layout
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        className="hover:bg-slate-800/30 transition-colors"
                      >
                        <td className="px-6 py-4">
                          <span className="font-mono text-blue-400 font-semibold">{account.code}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-white font-medium">{account.name}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            account.type.includes('Aset') ? 'bg-green-500/20 text-green-400' :
                            account.type.includes('Kewajiban') ? 'bg-red-500/20 text-red-400' :
                            account.type.includes('Ekuitas') ? 'bg-blue-500/20 text-blue-400' :
                            account.type.includes('Pendapatan') ? 'bg-purple-500/20 text-purple-400' :
                            'bg-orange-500/20 text-orange-400'
                          }`}>
                            {account.type}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-white font-semibold">{account.balance}</span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center justify-center space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleAction('Lihat Detail', account)}
                              className="text-slate-400 hover:text-blue-400 hover:bg-blue-500/10"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleAction('Edit Akun', account)}
                              className="text-slate-400 hover:text-yellow-400 hover:bg-yellow-500/10"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleAction('Hapus Akun', account)}
                              className="text-slate-400 hover:text-red-400 hover:bg-red-500/10"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </motion.tr>
                    ))
                  ) : (
                     <motion.tr initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                        <td colSpan="5" className="text-center py-12 px-6">
                            <p className="text-slate-400">Tidak ada akun yang cocok dengan pencarian atau filter Anda.</p>
                        </td>
                    </motion.tr>
                  )}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* Summary Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Total Akun</h3>
            <p className="text-3xl font-bold gradient-text">{accounts.length}</p>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Akun Aktif</h3>
            <p className="text-3xl font-bold text-green-400">{accounts.length}</p>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Jenis Akun</h3>
            <p className="text-3xl font-bold text-blue-400">{accountTypes.length}</p>
          </div>
        </motion.div>
      </div>

      {/* Add Account Modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowAddModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-slate-800 rounded-2xl p-6 w-full max-w-md border border-slate-700 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">Tambah Akun Baru</h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowAddModal(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <form onSubmit={handleAddAccount} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Kode Akun <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={newAccount.code}
                    onChange={(e) => setNewAccount({ ...newAccount, code: e.target.value })}
                    placeholder="Contoh: 1500"
                    className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Nama Akun <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={newAccount.name}
                    onChange={(e) => setNewAccount({ ...newAccount, name: e.target.value })}
                    placeholder="Contoh: Investasi Jangka Pendek"
                    className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Jenis Akun <span className="text-red-400">*</span>
                  </label>
                  <select
                    value={newAccount.type}
                    onChange={(e) => setNewAccount({ ...newAccount, type: e.target.value })}
                    className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="">Pilih Jenis Akun</option>
                    {accountTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Saldo Awal
                  </label>
                  <input
                    type="number"
                    value={newAccount.balance}
                    onChange={(e) => setNewAccount({ ...newAccount, balance: e.target.value })}
                    placeholder="0"
                    className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="flex space-x-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAddModal(false)}
                    className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
                  >
                    Batal
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                  >
                    Simpan Akun
                  </Button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default ChartOfAccounts;