import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getAssetDocuments, saveAssetDocuments } from '@/lib/asset-documents-api';
import { getDynamicStatus } from '@/lib/asset-documents-utils';

import FilterControls from '@/components/asset-documents/FilterControls';
import AssetDocumentsTable from '@/components/asset-documents/AssetDocumentsTable';
import DocumentFormDialog from '@/components/asset-documents/DocumentFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const AssetDocuments = () => {
  const [documents, setDocuments] = useState([]);
  const [filters, setFilters] = useState({
    assetName: '',
    assetCode: '',
    documentType: '',
    status: '',
    startDate: '',
    endDate: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [documentToDelete, setDocumentToDelete] = useState(null);

  const { toast } = useToast();
  const today = new Date();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getAssetDocuments();
    setDocuments(data);
  };

  const filteredDocuments = useMemo(() => {
    return documents
      .map(doc => ({ ...doc, dynamicStatus: getDynamicStatus(doc, today) }))
      .filter(doc => {
        const nameMatch = !filters.assetName || doc.assetName.toLowerCase().includes(filters.assetName.toLowerCase());
        const codeMatch = !filters.assetCode || doc.assetCode.toLowerCase().includes(filters.assetCode.toLowerCase());
        const typeMatch = !filters.documentType || doc.documentType === filters.documentType;
        const statusMatch = !filters.status || doc.dynamicStatus.staticStatus === filters.status;

        const uploadDate = new Date(doc.uploadDate);
        const startDate = filters.startDate ? new Date(filters.startDate) : null;
        const endDate = filters.endDate ? new Date(filters.endDate) : null;
        if (startDate) startDate.setHours(0, 0, 0, 0);
        if (endDate) endDate.setHours(23, 59, 59, 999);
        const dateRangeMatch = (!startDate || uploadDate >= startDate) && (!endDate || uploadDate <= endDate);

        return nameMatch && codeMatch && typeMatch && statusMatch && dateRangeMatch;
      });
  }, [documents, filters, today]);

  const handleOpenForm = (doc = null) => {
    setSelectedDocument(doc);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedDocument(null);
  };

  const handleSaveDocument = (formData) => {
    let updatedDocuments;
    if (selectedDocument) {
      updatedDocuments = documents.map(doc => (doc.id === selectedDocument.id ? { ...selectedDocument, ...formData } : doc));
      toast({ title: "✅ Sukses", description: "Dokumen aset berhasil diperbarui." });
    } else {
      const newDocument = { ...formData, id: Date.now() };
      updatedDocuments = [...documents, newDocument];
      toast({ title: "✅ Sukses", description: "Dokumen aset baru berhasil ditambahkan." });
    }
    saveAssetDocuments(updatedDocuments);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setDocumentToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedDocuments = documents.filter(doc => doc.id !== documentToDelete);
    saveAssetDocuments(updatedDocuments);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setDocumentToDelete(null);
    toast({
      title: "🗑️ Dokumen Dihapus",
      description: "Dokumen aset telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Dokumen Aset - Sistem Akuntansi</title>
        <meta name="description" content="Kelola dan lacak semua dokumen penting yang terkait dengan aset perusahaan." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Manajemen Dokumen Aset</h1>
            <p className="text-muted-foreground">Unggah, lacak, dan kelola semua dokumen terkait aset.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Tambah Dokumen
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <AssetDocumentsTable
          documents={filteredDocuments}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <DocumentFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveDocument}
        document={selectedDocument}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data dokumen aset secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default AssetDocuments;