import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const KontrakByJenisBarang = () => {
  return <PlaceholderPage title="Kontrak Berdasarkan Jenis Barang" description="Halaman untuk melihat kontrak berdasarkan jenis barang." />;
};

export default KontrakByJenisBarang;