import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Calendar, Download, Printer, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const EquityStatement = () => {
  const { toast } = useToast();

  const handleAction = (action) => {
    toast({
      title: `📊 ${action}`,
      description: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const equityData = {
    modalSaham: {
      saldiAwal: 1000000000,
      penambahan: 0,
      pengurangan: 0,
      saldiAkhir: 1000000000
    },
    labaRugiDitahan: {
      saldiAwal: 450000000,
      labaRugiTahunBerjalan: 850000000,
      dividenDibayar: 200000000,
      saldiAkhir: 1100000000
    },
    cadanganUmum: {
      saldiAwal: 150000000,
      penambahan: 50000000,
      pengurangan: 0,
      saldiAkhir: 200000000
    }
  };

  const totalEkuitasAwal = equityData.modalSaham.saldiAwal + equityData.labaRugiDitahan.saldiAwal + equityData.cadanganUmum.saldiAwal;
  const totalEkuitasAkhir = equityData.modalSaham.saldiAkhir + equityData.labaRugiDitahan.saldiAkhir + equityData.cadanganUmum.saldiAkhir;

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  return (
    <>
      <Helmet>
        <title>Laporan Perubahan Ekuitas - Sistem Akuntansi Profesional</title>
        <meta name="description" content="Laporan perubahan ekuitas yang menunjukkan pergerakan modal saham, laba ditahan, dan komponen ekuitas lainnya." />
        <style type="text/css">{`
            @media print {
              body * {
                visibility: hidden;
              }
              .printable-area, .printable-area * {
                visibility: visible;
              }
              .printable-area {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
              }
              .no-print {
                display: none;
              }
            }
        `}</style>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between no-print"
        >
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Laporan Perubahan Ekuitas</h1>
            <p className="text-slate-400">Analisis perubahan komponen ekuitas perusahaan</p>
          </div>
          <div className="flex space-x-2 mt-4 md:mt-0">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-800 border-slate-700 text-white">
                <DropdownMenuItem onSelect={() => handleAction('Export to PDF')}>Export ke PDF</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleAction('Export to Excel')}>Export ke Excel</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button 
              onClick={handlePrint}
              className="bg-gradient-to-r from-purple-500 to-violet-600 hover:from-purple-600 hover:to-violet-700"
            >
              <Printer className="h-4 w-4 mr-2" />
              Cetak
            </Button>
          </div>
        </motion.div>

        {/* Period Selection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass-effect rounded-xl p-6 no-print"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Periode</label>
              <Button 
                variant="outline"
                onClick={() => handleAction('Pilih Periode')}
                className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 justify-start"
              >
                <Calendar className="h-4 w-4 mr-2" />
                Tahun 2024
              </Button>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Format Laporan</label>
              <select className="w-full bg-slate-700/50 border border-slate-600 rounded-lg text-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500">
                <option>Format Standar</option>
                <option>Format Komparatif</option>
                <option>Format Detail</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Summary Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 no-print"
        >
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Ekuitas Awal</h3>
            <p className="text-2xl font-bold text-blue-400">{formatCurrency(totalEkuitasAwal)}</p>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Perubahan Bersih</h3>
            <p className="text-2xl font-bold text-green-400">
              {formatCurrency(totalEkuitasAkhir - totalEkuitasAwal)}
            </p>
            <div className="flex items-center justify-center mt-2 text-green-400">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm">+46.9%</span>
            </div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Ekuitas Akhir</h3>
            <p className="text-2xl font-bold gradient-text">{formatCurrency(totalEkuitasAkhir)}</p>
          </div>
        </motion.div>

        <div className="printable-area">
          {/* Equity Statement */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="glass-effect rounded-xl overflow-hidden"
          >
            <div className="p-6 border-b border-slate-700/50">
              <h2 className="text-xl font-semibold text-white text-center">
                PT. KONSTRUKSI INDONESIA
              </h2>
              <p className="text-slate-400 text-center mt-1">LAPORAN PERUBAHAN EKUITAS</p>
              <p className="text-slate-400 text-center">Untuk Periode yang Berakhir 31 Desember 2024</p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-800/50">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Komponen Ekuitas</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">Saldo Awal</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">Penambahan</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">Pengurangan</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">Saldo Akhir</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/50">
                  {/* Modal Saham */}
                  <tr className="hover:bg-slate-800/30">
                    <td className="px-6 py-4">
                      <span className="text-white font-semibold">Modal Saham</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-slate-300">{formatCurrency(equityData.modalSaham.saldiAwal)}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-green-400">
                        {equityData.modalSaham.penambahan > 0 ? formatCurrency(equityData.modalSaham.penambahan) : '-'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-red-400">
                        {equityData.modalSaham.pengurangan > 0 ? `(${formatCurrency(equityData.modalSaham.pengurangan)})` : '-'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-white font-semibold">{formatCurrency(equityData.modalSaham.saldiAkhir)}</span>
                    </td>
                  </tr>

                  {/* Laba Rugi Ditahan */}
                  <tr className="hover:bg-slate-800/30">
                    <td className="px-6 py-4">
                      <span className="text-white font-semibold">Laba Rugi Ditahan</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-slate-300">{formatCurrency(equityData.labaRugiDitahan.saldiAwal)}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-green-400">{formatCurrency(equityData.labaRugiDitahan.labaRugiTahunBerjalan)}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-red-400">({formatCurrency(equityData.labaRugiDitahan.dividenDibayar)})</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-white font-semibold">{formatCurrency(equityData.labaRugiDitahan.saldiAkhir)}</span>
                    </td>
                  </tr>

                  {/* Sub-items for Laba Rugi Ditahan */}
                  <tr className="hover:bg-slate-800/30 bg-slate-800/20">
                    <td className="px-6 py-2 pl-12">
                      <span className="text-slate-400 text-sm">• Laba Rugi Tahun Berjalan</span>
                    </td>
                    <td className="px-6 py-2 text-right">
                      <span className="text-slate-400 text-sm">-</span>
                    </td>
                    <td className="px-6 py-2 text-right">
                      <span className="text-green-400 text-sm">{formatCurrency(equityData.labaRugiDitahan.labaRugiTahunBerjalan)}</span>
                    </td>
                    <td className="px-6 py-2 text-right">
                      <span className="text-slate-400 text-sm">-</span>
                    </td>
                    <td className="px-6 py-2 text-right">
                      <span className="text-slate-400 text-sm">-</span>
                    </td>
                  </tr>

                  <tr className="hover:bg-slate-800/30 bg-slate-800/20">
                    <td className="px-6 py-2 pl-12">
                      <span className="text-slate-400 text-sm">• Dividen Dibayar</span>
                    </td>
                    <td className="px-6 py-2 text-right">
                      <span className="text-slate-400 text-sm">-</span>
                    </td>
                    <td className="px-6 py-2 text-right">
                      <span className="text-slate-400 text-sm">-</span>
                    </td>
                    <td className="px-6 py-2 text-right">
                      <span className="text-red-400 text-sm">({formatCurrency(equityData.labaRugiDitahan.dividenDibayar)})</span>
                    </td>
                    <td className="px-6 py-2 text-right">
                      <span className="text-slate-400 text-sm">-</span>
                    </td>
                  </tr>

                  {/* Cadangan Umum */}
                  <tr className="hover:bg-slate-800/30">
                    <td className="px-6 py-4">
                      <span className="text-white font-semibold">Cadangan Umum</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-slate-300">{formatCurrency(equityData.cadanganUmum.saldiAwal)}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-green-400">{formatCurrency(equityData.cadanganUmum.penambahan)}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-red-400">
                        {equityData.cadanganUmum.pengurangan > 0 ? `(${formatCurrency(equityData.cadanganUmum.pengurangan)})` : '-'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-white font-semibold">{formatCurrency(equityData.cadanganUmum.saldiAkhir)}</span>
                    </td>
                  </tr>

                  {/* Total */}
                  <tr className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border-t-2 border-blue-500/50">
                    <td className="px-6 py-4">
                      <span className="text-white font-bold text-lg">TOTAL EKUITAS</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-blue-400 font-bold">{formatCurrency(totalEkuitasAwal)}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-green-400 font-bold">{formatCurrency(900000000)}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-red-400 font-bold">({formatCurrency(200000000)})</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-white font-bold text-lg">{formatCurrency(totalEkuitasAkhir)}</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </motion.div>
        </div>
        
        {/* Analysis Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="glass-effect rounded-xl p-6 no-print"
        >
          <h3 className="text-xl font-semibold text-white mb-4">Analisis Perubahan Ekuitas</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-lg font-medium text-slate-300 mb-3">Faktor Penambahan</h4>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="text-slate-400">Laba Bersih Tahun Berjalan</span>
                  <span className="text-green-400 font-semibold">{formatCurrency(850000000)}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-slate-400">Penambahan Cadangan</span>
                  <span className="text-green-400 font-semibold">{formatCurrency(50000000)}</span>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-medium text-slate-300 mb-3">Faktor Pengurangan</h4>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="text-slate-400">Dividen Dibayar</span>
                  <span className="text-red-400 font-semibold">{formatCurrency(200000000)}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-slate-400">Lainnya</span>
                  <span className="text-slate-400">-</span>
                </li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default EquityStatement;