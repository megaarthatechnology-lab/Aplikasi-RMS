import React from 'react';
import { motion } from 'framer-motion';
import { useKBar } from "kbar";
import { Menu, Bell, Search, User, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import NotificationCenter from '@/components/notifications/NotificationCenter';
import { Link } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';


const Header = ({ onMenuClick, sidebarOpen, notifications = [], setNotifications }) => {
  const { query } = useKBar();
  const { toast } = useToast();
  const unreadCount = (notifications || []).filter(n => !n.read).length;

  const handleProfileClick = () => {
    toast({
      title: "👤 Profil",
      description: "Halaman profil akan segera tersedia. Untuk saat ini, Anda dapat mengelola profil di halaman Pengaturan."
    });
  };

  return (
    <motion.header
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-slate-800/50 backdrop-blur-lg border-b border-slate-700/50 px-6 py-4"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={onMenuClick}
            className="text-slate-300 hover:text-white hover:bg-slate-700/50"
          >
            <Menu className="h-6 w-6" />
          </Button>
          
          <div className="hidden md:flex items-center space-x-2">
             <Button
              variant="outline"
              className="w-80 justify-start text-slate-400 border-slate-600 bg-slate-700/50 hover:bg-slate-700 hover:text-slate-300"
              onClick={query.toggle}
            >
              <Search className="h-4 w-4 mr-2" />
              Cari apa saja...
              <kbd className="pointer-events-none ml-auto inline-flex h-5 select-none items-center gap-1 rounded border border-slate-500 bg-slate-600 px-1.5 font-mono text-[10px] font-medium text-slate-300 opacity-100">
                <span className="text-xs">⌘</span>K
              </kbd>
            </Button>
          </div>
        </div>

        <div className="flex items-center space-x-2 md:space-x-4">
           <Button variant="ghost" size="icon" onClick={query.toggle} className="md:hidden text-slate-300 hover:text-white hover:bg-slate-700/50">
             <Search className="h-5 w-5" />
           </Button>

          <Popover>
            <PopoverTrigger asChild>
               <Button
                variant="ghost"
                size="icon"
                className="text-slate-300 hover:text-white hover:bg-slate-700/50 relative"
              >
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center animate-pulse">
                    {unreadCount}
                  </span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-96 p-0" align="end">
              <NotificationCenter notifications={notifications || []} setNotifications={setNotifications} />
            </PopoverContent>
          </Popover>

          <Link to="/settings">
            <Button
              variant="ghost"
              size="icon"
              className="text-slate-300 hover:text-white hover:bg-slate-700/50"
            >
              <Settings className="h-5 w-5" />
            </Button>
          </Link>

          <Button
            variant="ghost"
            onClick={handleProfileClick}
            className="flex items-center space-x-2 text-slate-300 hover:text-white hover:bg-slate-700/50 px-3 py-2"
          >
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-white" />
            </div>
            <div className="hidden md:block text-left">
              <div className="text-sm font-medium">Admin Akuntansi</div>
              <div className="text-xs text-slate-400">admin@perusahaan.com</div>
            </div>
          </Button>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;