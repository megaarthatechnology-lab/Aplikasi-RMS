import React from 'react';
import { motion } from 'framer-motion';
import { Construction } from 'lucide-react';

const PlaceholderPage = ({ title }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center h-full text-center p-8"
    >
      <div className="p-6 bg-slate-800/50 rounded-full mb-6">
        <Construction className="w-16 h-16 text-blue-400" />
      </div>
      <h1 className="text-3xl font-bold gradient-text mb-4">{title}</h1>
      <p className="text-slate-400 max-w-md">
        Halaman ini sedang dalam pengembangan. Fitur lengkap akan segera tersedia. Terima kasih atas kesabaran Anda!
      </p>
    </motion.div>
  );
};

export default PlaceholderPage;