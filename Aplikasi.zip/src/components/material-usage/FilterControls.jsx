import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, RotateCcw } from 'lucide-react';
import { Label } from '@/components/ui/label';

const FilterControls = ({ filters, setFilters, projectReferences }) => {
  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFilters(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value === 'all' ? '' : value }));
  };

  const resetFilters = () => {
    setFilters({
        searchTerm: '',
        projectReference: '',
        startDate: '',
        endDate: '',
        minCost: '',
        maxCost: '',
    });
  };

  return (
    <Card className="glass-effect">
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4 items-end">
          <div className="lg:col-span-2">
            <Label htmlFor="searchTerm">Cari Nama Material</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="searchTerm"
                placeholder="Semen, Besi, Cat..."
                value={filters.searchTerm}
                onChange={handleInputChange}
                className="pl-10"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="projectReference">Referensi Proyek</Label>
            <Select value={filters.projectReference} onValueChange={(value) => handleSelectChange('projectReference', value)}>
              <SelectTrigger><SelectValue placeholder="Semua Proyek"/></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Proyek</SelectItem>
                {projectReferences.map(ref => <SelectItem key={ref} value={ref}>{ref}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="lg:col-span-2 xl:col-span-1">
            <Label>Filter Tanggal</Label>
            <div className="flex gap-2">
                <Input id="startDate" type="date" value={filters.startDate} onChange={handleInputChange} />
                <Input id="endDate" type="date" value={filters.endDate} onChange={handleInputChange} />
            </div>
          </div>
          <div className="lg:col-span-2 xl:col-span-1">
            <Label>Filter Biaya</Label>
            <div className="flex gap-2">
                <Input id="minCost" type="number" placeholder="Min" value={filters.minCost} onChange={handleInputChange} />
                <Input id="maxCost" type="number" placeholder="Max" value={filters.maxCost} onChange={handleInputChange} />
            </div>
          </div>

          <div className="flex justify-end lg:col-start-4 xl:col-start-5">
             <Button variant="outline" onClick={resetFilters} className="w-full sm:w-auto">
                <RotateCcw className="mr-2 h-4 w-4" /> Reset
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterControls;