import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const ScheduleFilterControls = ({ debts, selectedDebtId, setSelectedDebtId }) => {
  return (
    <div>
        <label htmlFor="debt-select" className="text-sm font-medium text-slate-300 block mb-2">Pilih Hutang</label>
        <Select
            id="debt-select"
            value={selectedDebtId}
            onValueChange={setSelectedDebtId}
            disabled={debts.length === 0}
        >
            <SelectTrigger className="w-full md:w-[300px]">
                <SelectValue placeholder="Pilih hutang untuk ditampilkan..." />
            </SelectTrigger>
            <SelectContent>
                {debts.length > 0 ? (
                    debts.map(debt => (
                        <SelectItem key={debt.id} value={debt.id.toString()}>
                            {debt.creditor}
                        </SelectItem>
                    ))
                ) : (
                    <SelectItem value="none" disabled>Tidak ada hutang aktif berbunga</SelectItem>
                )}
            </SelectContent>
        </Select>
    </div>
  );
};

export default ScheduleFilterControls;