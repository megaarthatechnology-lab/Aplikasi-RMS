import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';
import { formatCurrency } from '@/lib/debt-utils';

const AmortizationTable = ({ schedule, debt, onMarkAsPaid }) => {
    
    if (!debt) return null;

  return (
    <div className="overflow-x-auto scrollbar-thin">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[80px]">Ke-</TableHead>
            <TableHead>Tgl. Pembayaran</TableHead>
            <TableHead className="text-right">Total Bayar</TableHead>
            <TableHead className="text-right">Pokok</TableHead>
            <TableHead className="text-right">Bunga</TableHead>
            <TableHead className="text-right">Sisa Pokok</TableHead>
            <TableHead className="text-center">Status</TableHead>
            <TableHead className="text-right">Aksi</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {schedule.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-12 text-muted-foreground">
                Jadwal untuk hutang ini tidak dapat dibuat. Pastikan hutang aktif dan memiliki bunga.
              </TableCell>
            </TableRow>
          ) : (
            schedule.map((p) => {
              const isPaid = p.status === 'paid';
              return (
                <TableRow key={p.paymentNumber} className={isPaid ? 'bg-green-900/20' : ''}>
                  <TableCell className="font-medium">{p.paymentNumber}</TableCell>
                  <TableCell>{format(new Date(p.paymentDate), 'dd MMM yyyy', { locale: id })}</TableCell>
                  <TableCell className="text-right font-semibold">{formatCurrency(p.paymentAmount)}</TableCell>
                  <TableCell className="text-right">{formatCurrency(p.principal)}</TableCell>
                  <TableCell className="text-right text-amber-400">{formatCurrency(p.interest)}</TableCell>
                  <TableCell className="text-right">{formatCurrency(p.remainingBalance)}</TableCell>
                  <TableCell className="text-center">
                    {isPaid ? (
                      <Badge variant="success" className="bg-green-600/80">Lunas</Badge>
                    ) : (
                      <Badge variant="secondary" className="bg-yellow-500/80 text-black">Tertunda</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onMarkAsPaid(debt.id, p.paymentNumber)}
                      disabled={isPaid}
                      className="disabled:opacity-40 disabled:cursor-not-allowed hover:bg-green-800"
                    >
                      <CheckCircle2 className="mr-2 h-4 w-4" />
                      Bayar
                    </Button>
                  </TableCell>
                </TableRow>
              )
            })
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default AmortizationTable;