import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, RotateCcw } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { rawMaterialStatusOptions } from '@/lib/raw-materials-utils.jsx';

const FilterControls = ({ filters, setFilters, suppliers }) => {
  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFilters(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value === 'all' ? '' : value }));
  };

  const resetFilters = () => {
    setFilters({
      searchTerm: '',
      supplier: '',
      status: 'all',
      minQuantity: '',
      maxQuantity: '',
    });
  };

  return (
    <Card className="glass-effect">
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4 items-end">
          <div className="lg:col-span-2">
            <Label htmlFor="searchTerm">Cari Nama Bahan</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="searchTerm"
                placeholder="Pasir, Semen, Besi..."
                value={filters.searchTerm}
                onChange={handleInputChange}
                className="pl-10"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="supplier">Supplier</Label>
            <Select value={filters.supplier} onValueChange={(value) => handleSelectChange('supplier', value)}>
              <SelectTrigger><SelectValue placeholder="Semua Supplier"/></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Supplier</SelectItem>
                {suppliers.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="status">Status Stok</Label>
            <Select value={filters.status} onValueChange={(value) => handleSelectChange('status', value)}>
              <SelectTrigger><SelectValue placeholder="Semua Status"/></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                {rawMaterialStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex justify-end">
             <Button variant="outline" onClick={resetFilters} className="w-full sm:w-auto">
                <RotateCcw className="mr-2 h-4 w-4" /> Reset
            </Button>
          </div>
          <div className="lg:col-span-2 xl:col-span-full">
            <Label>Filter Kuantitas Stok</Label>
            <div className="flex gap-2">
                <Input id="minQuantity" type="number" placeholder="Min" value={filters.minQuantity} onChange={handleInputChange} />
                <Input id="maxQuantity" type="number" placeholder="Max" value={filters.maxQuantity} onChange={handleInputChange} />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterControls;