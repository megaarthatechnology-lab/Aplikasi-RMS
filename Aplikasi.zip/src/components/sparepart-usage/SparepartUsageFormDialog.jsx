import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { sparepartStatusOptions, sparepartUnitOptions } from '@/lib/sparepart-usage-utils.jsx';
import { format } from 'date-fns';

const SparepartUsageFormDialog = ({ isOpen, onClose, onSave, usage, references, suppliers }) => {
  const getInitialFormData = () => ({
    partName: '',
    quantity: '',
    unit: '',
    date: format(new Date(), 'yyyy-MM-dd'),
    reference: '',
    cost: '',
    supplierName: '',
    description: '',
    status: 'used',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (usage) {
        setFormData({
          ...usage,
          quantity: usage.quantity.toString(),
          cost: usage.cost.toString(),
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [usage, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredFields = ['partName', 'quantity', 'unit', 'date', 'reference', 'cost', 'supplierName', 'status'];
    for (const field of requiredFields) {
        const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
        if (!formData[field]) {
            toast({ title: '⚠️ Data Tidak Lengkap', description: `Mohon lengkapi field "${fieldName}" yang wajib diisi.`, variant: 'destructive' });
            return;
        }
    }
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{usage ? 'Edit Pemakaian' : 'Catat Pemakaian Baru'}</DialogTitle>
          <DialogDescription>{usage ? 'Perbarui informasi pemakaian spare part.' : 'Buat catatan pemakaian spare part baru.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="partName">Nama Spare Part *</Label>
            <Input id="partName" value={formData.partName} onChange={handleInputChange} placeholder="Filter Oli, Kampas Rem..." required />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label htmlFor="quantity">Jumlah Terpakai *</Label>
                <Input id="quantity" type="number" value={formData.quantity} onChange={handleInputChange} placeholder="2" required min="0" step="any"/>
            </div>
            <div className="space-y-2">
                <Label htmlFor="unit">Satuan *</Label>
                <Select value={formData.unit} onValueChange={(value) => handleSelectChange('unit', value)}>
                    <SelectTrigger><SelectValue placeholder="Pilih Satuan" /></SelectTrigger>
                    <SelectContent>{sparepartUnitOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}</SelectContent>
                </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label htmlFor="date">Tanggal Pemakaian *</Label>
                <Input id="date" type="date" value={formData.date} onChange={handleInputChange} required />
            </div>
            <div className="space-y-2">
                <Label htmlFor="cost">Total Biaya (IDR) *</Label>
                <Input id="cost" type="number" value={formData.cost} onChange={handleInputChange} placeholder="300000" required min="0" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="reference">Kendaraan / Alat *</Label>
              <Input id="reference" value={formData.reference} onChange={handleInputChange} placeholder="Excavator EX-01..." required />
            </div>
             <div className="space-y-2">
              <Label htmlFor="supplierName">Nama Supplier *</Label>
              <Input id="supplierName" value={formData.supplierName} onChange={handleInputChange} placeholder="PT. Suku Cadang Sejati" required />
            </div>
          </div>
           <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{sparepartStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          <div className="space-y-2">
            <Label htmlFor="description">Deskripsi</Label>
            <Textarea id="description" value={formData.description} onChange={handleInputChange} placeholder="Tambahkan deskripsi atau catatan tambahan..." />
          </div>
          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{usage ? 'Perbarui Catatan' : 'Simpan Catatan'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default SparepartUsageFormDialog;