import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, RotateCcw } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { transferStatusOptions, popularBanks } from '@/lib/bank-transfers-utils.jsx';

const FilterControls = ({ filters, setFilters }) => {
  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFilters(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const resetFilters = () => {
    setFilters({
      searchTerm: '',
      senderBank: 'all',
      recipientBank: 'all',
      status: 'all',
      startDate: '',
      endDate: '',
    });
  };

  return (
    <Card className="glass-effect">
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-4 items-end">
          <div className="lg:col-span-2 xl:col-span-2">
            <Label htmlFor="searchTerm">Cari Nama / No. Referensi</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="searchTerm"
                placeholder="Nama pengirim/penerima atau No. Ref..."
                value={filters.searchTerm}
                onChange={handleInputChange}
                className="pl-10"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="senderBank">Bank Pengirim</Label>
            <Select value={filters.senderBank} onValueChange={(value) => handleSelectChange('senderBank', value)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Bank</SelectItem>
                {popularBanks.map(bank => <SelectItem key={bank} value={bank}>{bank}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="recipientBank">Bank Penerima</Label>
            <Select value={filters.recipientBank} onValueChange={(value) => handleSelectChange('recipientBank', value)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Bank</SelectItem>
                {popularBanks.map(bank => <SelectItem key={bank} value={bank}>{bank}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="status">Status</Label>
            <Select value={filters.status} onValueChange={(value) => handleSelectChange('status', value)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                {transferStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex justify-end">
             <Button variant="outline" onClick={resetFilters} className="w-full sm:w-auto">
                <RotateCcw className="mr-2 h-4 w-4" /> Reset
            </Button>
          </div>
          <div className="lg:col-span-2 xl:col-span-3">
            <Label>Filter Tanggal Transfer</Label>
            <div className="flex gap-2">
                <Input id="startDate" type="date" value={filters.startDate} onChange={handleInputChange} />
                <Input id="endDate" type="date" value={filters.endDate} onChange={handleInputChange} />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterControls;