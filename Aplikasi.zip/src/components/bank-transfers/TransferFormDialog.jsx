import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { transferStatusOptions, popularBanks } from '@/lib/bank-transfers-utils.jsx';
import { format } from 'date-fns';

const TransferFormDialog = ({ isOpen, onClose, onSave, transfer }) => {
  const getInitialFormData = () => ({
    senderBank: '',
    senderAccount: '',
    senderHolder: '',
    recipientBank: '',
    recipientAccount: '',
    recipientHolder: '',
    amount: '',
    transferDate: format(new Date(), 'yyyy-MM-dd'),
    referenceNumber: '',
    status: 'pending',
    description: '',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (transfer) {
        setFormData({
          ...transfer,
          amount: transfer.amount.toString(),
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [transfer, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredFields = ['senderBank', 'senderAccount', 'senderHolder', 'recipientBank', 'recipientAccount', 'recipientHolder', 'amount', 'transferDate', 'status'];
    for (const field of requiredFields) {
      if (!formData[field]) {
        toast({ title: '⚠️ Data Tidak Lengkap', description: `Mohon lengkapi field "${field}" yang wajib diisi.`, variant: 'destructive' });
        return;
      }
    }
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{transfer ? 'Edit Transfer' : 'Tambah Transfer Baru'}</DialogTitle>
          <DialogDescription>{transfer ? 'Perbarui informasi transfer.' : 'Buat catatan transfer bank baru.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4 p-4 border border-slate-700 rounded-lg">
              <h4 className="font-semibold text-slate-200">Rekening Pengirim</h4>
              <div className="space-y-2">
                <Label htmlFor="senderBank">Bank Pengirim *</Label>
                <Select value={formData.senderBank} onValueChange={(value) => handleSelectChange('senderBank', value)}>
                    <SelectTrigger><SelectValue placeholder="Pilih Bank" /></SelectTrigger>
                    <SelectContent>{popularBanks.map(bank => <SelectItem key={bank} value={bank}>{bank}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="senderAccount">No. Rekening Pengirim *</Label>
                <Input id="senderAccount" value={formData.senderAccount} onChange={handleInputChange} placeholder="0123456789" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="senderHolder">Nama Pemilik Rekening *</Label>
                <Input id="senderHolder" value={formData.senderHolder} onChange={handleInputChange} placeholder="PT. Konstruksi Jaya" required />
              </div>
            </div>
            <div className="space-y-4 p-4 border border-slate-700 rounded-lg">
              <h4 className="font-semibold text-slate-200">Rekening Penerima</h4>
              <div className="space-y-2">
                <Label htmlFor="recipientBank">Bank Penerima *</Label>
                <Select value={formData.recipientBank} onValueChange={(value) => handleSelectChange('recipientBank', value)}>
                    <SelectTrigger><SelectValue placeholder="Pilih Bank" /></SelectTrigger>
                    <SelectContent>{popularBanks.map(bank => <SelectItem key={bank} value={bank}>{bank}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="recipientAccount">No. Rekening Penerima *</Label>
                <Input id="recipientAccount" value={formData.recipientAccount} onChange={handleInputChange} placeholder="9876543210" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="recipientHolder">Nama Pemilik Rekening *</Label>
                <Input id="recipientHolder" value={formData.recipientHolder} onChange={handleInputChange} placeholder="PT. Supplier Besi" required />
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Jumlah (IDR) *</Label>
              <Input id="amount" type="number" value={formData.amount} onChange={handleInputChange} placeholder="75000000" required min="0" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="transferDate">Tanggal Transfer *</Label>
              <Input id="transferDate" type="date" value={formData.transferDate} onChange={handleInputChange} required />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="referenceNumber">No. Referensi</Label>
              <Input id="referenceNumber" value={formData.referenceNumber} onChange={handleInputChange} placeholder="TRF-SUP-001" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{transferStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Deskripsi</Label>
            <Textarea id="description" value={formData.description} onChange={handleInputChange} placeholder="Tambahkan deskripsi atau catatan tambahan..." />
          </div>
          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{transfer ? 'Perbarui Transfer' : 'Simpan Transfer'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TransferFormDialog;