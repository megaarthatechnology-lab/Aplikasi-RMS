import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency } from '@/lib/utils';
import { getConditionStatusBadge, getAssetStatusBadge } from '@/lib/asset-list-utils.jsx';
import { Badge } from '@/components/ui/badge';

const AssetListTable = ({ assets, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Inventaris Aset</CardTitle>
        <CardDescription>Menampilkan {assets.length} aset yang sesuai dengan filter.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nama & Kode Aset</TableHead>
                <TableHead>Kategori</TableHead>
                <TableHead>Nilai & Pembelian</TableHead>
                <TableHead>Kondisi</TableHead>
                <TableHead>Lokasi</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assets.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada data aset</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan aset baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                assets.map((asset) => (
                  <TableRow key={asset.id}>
                    <TableCell>
                      <div className="font-bold">{asset.assetName}</div>
                      <Badge variant="outline" className="mt-1">{asset.assetCode}</Badge>
                      {asset.description && <div className="text-xs text-slate-400 mt-1 max-w-xs truncate" title={asset.description}>{asset.description}</div>}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{asset.category}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="font-semibold text-green-400">{formatCurrency(asset.currentValue)}</div>
                      <div className="text-xs text-slate-400">Beli: {formatCurrency(asset.purchasePrice)}</div>
                      <div className="text-xs text-slate-400">{format(new Date(asset.purchaseDate), 'dd MMM yyyy')}</div>
                    </TableCell>
                    <TableCell>{getConditionStatusBadge(asset.conditionStatus)}</TableCell>
                    <TableCell>
                      <div className="text-sm">{asset.location}</div>
                    </TableCell>
                    <TableCell>{getAssetStatusBadge(asset.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(asset)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(asset.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default AssetListTable;