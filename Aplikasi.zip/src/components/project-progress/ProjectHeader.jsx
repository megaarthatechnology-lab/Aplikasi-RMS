import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const ProjectHeader = ({ handleAction }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
    className="flex flex-col md:flex-row md:items-center md:justify-between"
  >
    <div>
      <h1 className="text-3xl font-bold gradient-text mb-2">Laporan Progres Proyek</h1>
      <p className="text-slate-400">Monitor detail progres dan milestone setiap proyek</p>
    </div>
    <div className="flex space-x-2 mt-4 md:mt-0">
      <Button 
        variant="outline"
        onClick={() => handleAction('Export Laporan')}
        className="border-slate-600 text-slate-300 hover:bg-slate-700"
      >
        Export
      </Button>
      <Button 
        onClick={() => handleAction('Update Progress')}
        className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
      >
        Update Progress
      </Button>
    </div>
  </motion.div>
);

export default ProjectHeader;