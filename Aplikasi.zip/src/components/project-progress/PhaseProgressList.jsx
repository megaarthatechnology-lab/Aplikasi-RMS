import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency, getStatusColor, getProgressColor } from '@/lib/project-utils';

const PhaseProgressList = ({ phases }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: 0.3 }}
    className="glass-effect rounded-xl overflow-hidden"
  >
    <div className="p-6 border-b border-slate-700/50">
      <h2 className="text-xl font-semibold text-white">Progress per Fase</h2>
    </div>
    <div className="p-6 space-y-6">
      {phases.map((phase, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
          className="bg-slate-800/30 rounded-lg p-4"
        >
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-white mb-1">{phase.name}</h3>
              <div className="flex items-center space-x-4 text-sm text-slate-400">
                <span>{phase.startDate} - {phase.endDate}</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(phase.status)}`}>
                  {phase.status}
                </span>
              </div>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-white">{phase.progress}%</p>
              <p className="text-slate-400 text-sm">Progress</p>
            </div>
          </div>

          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-slate-400 text-sm">Progress</span>
              <span className="text-white font-semibold">{phase.progress}%</span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-2">
              <div 
                className={`h-2 rounded-full ${getProgressColor(phase.progress)}`}
                style={{ width: `${phase.progress}%` }}
              ></div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-slate-400 text-sm">Budget Fase</p>
              <p className="text-white font-semibold">{formatCurrency(phase.budget)}</p>
            </div>
            <div>
              <p className="text-slate-400 text-sm">Terpakai</p>
              <p className="text-yellow-400 font-semibold">{formatCurrency(phase.spent)}</p>
            </div>
            <div>
              <p className="text-slate-400 text-sm">Sisa Budget</p>
              <p className="text-green-400 font-semibold">{formatCurrency(phase.budget - phase.spent)}</p>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  </motion.div>
);

export default PhaseProgressList;