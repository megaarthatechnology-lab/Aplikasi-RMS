import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '@/lib/utils';

const SalaryDistributionChart = ({ data }) => {
  const maxCount = Math.max(...data.map(d => d.count), 0);
  const barColors = [
    'from-emerald-500 to-green-500',
    'from-teal-500 to-cyan-500',
    'from-sky-500 to-blue-500',
    'from-indigo-500 to-purple-500',
    'from-fuchsia-500 to-pink-500',
  ];

  return (
    <div className="glass-effect p-6 rounded-xl">
      <h3 className="text-xl font-semibold text-white mb-6">Distribusi Gaji</h3>
      <div className="flex justify-between items-end h-64 space-x-2">
        {data.map((item, index) => (
          <div key={item.range} className="flex-1 flex flex-col items-center justify-end h-full">
            <motion.div
              className={`w-full bg-gradient-to-b ${barColors[index % barColors.length]} rounded-t-lg relative`}
              initial={{ height: 0 }}
              animate={{ height: `${(item.count / (maxCount || 1)) * 100}%` }}
              transition={{ duration: 0.5, delay: 0.2 + index * 0.1, ease: 'easeOut' }}
            >
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-white font-bold">{item.count}</div>
            </motion.div>
            <div className="text-center text-xs text-slate-400 mt-2 w-full">{item.range}</div>
          </div>
        ))}
      </div>
      {data.every(item => item.count === 0) && (
        <p className="text-center text-slate-400 pt-16 pb-20">Tidak ada data gaji untuk ditampilkan.</p>
      )}
    </div>
  );
};

export default SalaryDistributionChart;