import React from 'react';
import { motion } from 'framer-motion';

const DonutSegment = ({ percentage, color, radius, offset }) => {
  const circumference = 2 * Math.PI * radius;
  const strokeDasharray = `${circumference} ${circumference}`;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <circle
      cx="50"
      cy="50"
      r={radius}
      stroke={color}
      strokeWidth="10"
      fill="transparent"
      strokeDasharray={strokeDasharray}
      strokeDashoffset={strokeDashoffset}
      transform={`rotate(${offset} 50 50)`}
      strokeLinecap="round"
    />
  );
};

const StatusDonutChart = ({ data }) => {
  const colors = {
    'Aktif': '#22c55e', // green-500
    'Cuti': '#facc15', // yellow-400
    'Diberhentikan': '#ef4444' // red-500
  };
  const total = data.reduce((sum, item) => sum + item.count, 0);
  let accumulatedPercentage = -90;

  return (
    <div className="glass-effect p-6 rounded-xl flex flex-col md:flex-row items-center gap-8">
      <div className="relative w-48 h-48">
        <svg className="w-full h-full" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="40" fill="transparent" stroke="#334155" strokeWidth="10" />
           {total > 0 && data.map(item => {
            const percentage = (item.count / total) * 100;
            const segment = (
              <motion.g key={item.name}>
                <DonutSegment
                  percentage={percentage}
                  color={colors[item.name]}
                  radius="40"
                  offset={accumulatedPercentage}
                />
              </motion.g>
            );
            accumulatedPercentage += percentage * 3.6;
            return segment;
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-bold text-white">{total}</span>
            <span className="text-sm text-slate-400">Karyawan</span>
        </div>
      </div>
      <div className="flex-1 space-y-3">
        <h3 className="text-xl font-semibold text-white mb-4">Status Karyawan</h3>
        {data.map(item => (
          <div key={item.name} className="flex items-center justify-between">
            <div className="flex items-center">
              <span className="w-3 h-3 rounded-full mr-3" style={{ backgroundColor: colors[item.name] }}></span>
              <span className="text-slate-300">{item.name}</span>
            </div>
            <span className="font-semibold text-white">{item.count}</span>
          </div>
        ))}
        {total === 0 && (
          <p className="text-center text-slate-400 py-8">Tidak ada data status untuk ditampilkan.</p>
        )}
      </div>
    </div>
  );
};

export default StatusDonutChart;