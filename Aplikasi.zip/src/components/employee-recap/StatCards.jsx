import React from 'react';
import { motion } from 'framer-motion';
import { Users, Briefcase, DollarSign, Building } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

const StatCard = ({ icon, title, value, color, delay }) => {
  const colors = {
    blue: 'from-blue-500/20 to-cyan-500/20 text-blue-400',
    purple: 'from-purple-500/20 to-fuchsia-500/20 text-purple-400',
    green: 'from-green-500/20 to-emerald-500/20 text-green-400',
    yellow: 'from-yellow-500/20 to-amber-500/20 text-yellow-400',
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: delay }}
      className={`bg-gradient-to-br p-6 rounded-xl flex items-center space-x-4 ${colors[color]}`}
    >
      <div className="p-3 bg-slate-800/50 rounded-lg">
        {icon}
      </div>
      <div>
        <p className="text-sm text-slate-300">{title}</p>
        <p className="text-2xl font-bold text-white">{value}</p>
      </div>
    </motion.div>
  );
};


const StatCards = ({ stats }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    <StatCard 
      icon={<Users className="w-6 h-6" />}
      title="Total Karyawan"
      value={stats.totalEmployees}
      color="blue"
      delay={0.1}
    />
    <StatCard 
      icon={<DollarSign className="w-6 h-6" />}
      title="Rata-rata Gaji"
      value={formatCurrency(stats.averageSalary)}
      color="green"
      delay={0.2}
    />
    <StatCard 
      icon={<Building className="w-6 h-6" />}
      title="Total Departemen"
      value={stats.totalDepartments}
      color="purple"
      delay={0.3}
    />
    <StatCard 
      icon={<Briefcase className="w-6 h-6" />}
      title="Posisi Populer"
      value={stats.mostCommonPosition}
      color="yellow"
      delay={0.4}
    />
  </div>
);

export default StatCards;