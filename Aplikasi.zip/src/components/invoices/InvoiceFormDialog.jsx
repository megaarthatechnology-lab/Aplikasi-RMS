import React, { useState, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { invoiceStatusOptions, formatCurrency } from '@/lib/invoice-utils.jsx';
import { format } from 'date-fns';
import InvoiceItems from '@/components/invoices/InvoiceItems';

const paymentMethods = ["Transfer Bank", "Cek", "Tunai", "Kartu Kredit"];

const InvoiceFormDialog = ({ isOpen, onClose, onSave, invoice }) => {
  const getInitialFormData = () => ({
    invoiceNumber: '',
    customerName: '',
    issueDate: format(new Date(), 'yyyy-MM-dd'),
    dueDate: format(new Date(), 'yyyy-MM-dd'),
    status: 'draft',
    description: '',
    items: [{ id: Date.now(), name: '', quantity: 1, price: 0 }],
    paymentDate: null,
    paymentMethod: null,
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (invoice) {
        setFormData({
            ...getInitialFormData(),
            ...invoice,
            items: invoice.items && invoice.items.length > 0 ? invoice.items : [{ id: Date.now(), name: '', quantity: 1, price: 0 }]
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [invoice, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleSelectChange = (field, value) => {
    const newFormData = { ...formData, [field]: value };
    // If status is changed to 'paid', set payment date to today if it's not already set
    if (field === 'status' && value === 'paid' && !newFormData.paymentDate) {
      newFormData.paymentDate = format(new Date(), 'yyyy-MM-dd');
      if(!newFormData.paymentMethod){
          newFormData.paymentMethod = paymentMethods[0];
      }
    }
    setFormData(newFormData);
  };

  const handleItemsChange = (items) => {
    setFormData(prev => ({ ...prev, items }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.customerName || !formData.invoiceNumber || formData.items.some(item => !item.name || item.quantity <= 0 || item.price < 0)) {
      toast({ title: '⚠️ Data Tidak Lengkap', description: 'Mohon isi nama pelanggan, no. invoice, dan detail semua item dengan benar (harga tidak boleh minus).', variant: 'destructive' });
      return;
    }
    onSave(formData);
  };

  const totalAmount = useMemo(() => {
    return formData.items.reduce((sum, item) => sum + (item.quantity || 0) * (item.price || 0), 0);
  }, [formData.items]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>{invoice ? 'Edit Invoice' : 'Buat Invoice Baru'}</DialogTitle>
          <DialogDescription>
            {invoice ? 'Perbarui detail invoice.' : 'Isi detail di bawah untuk membuat invoice baru.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex-grow overflow-y-auto space-y-4 pr-6 pl-2 -mr-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="customerName">Nama Pelanggan *</Label>
              <Input id="customerName" value={formData.customerName} onChange={handleInputChange} placeholder="Contoh: PT. Maju Mundur" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="invoiceNumber">No. Invoice *</Label>
              <Input id="invoiceNumber" value={formData.invoiceNumber} onChange={handleInputChange} placeholder="INV/2025/..." required />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="issueDate">Tanggal Terbit *</Label>
              <Input id="issueDate" type="date" value={formData.issueDate} onChange={handleInputChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate">Jatuh Tempo *</Label>
              <Input id="dueDate" type="date" value={formData.dueDate} onChange={handleInputChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{invoiceStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>

          {formData.status === 'paid' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-800/50 rounded-lg">
              <div className="space-y-2">
                <Label htmlFor="paymentDate">Tanggal Pembayaran</Label>
                <Input id="paymentDate" type="date" value={formData.paymentDate || ''} onChange={handleInputChange} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="paymentMethod">Metode Pembayaran</Label>
                <Select value={formData.paymentMethod || ''} onValueChange={(value) => handleSelectChange('paymentMethod', value)}>
                  <SelectTrigger><SelectValue placeholder="Pilih metode..." /></SelectTrigger>
                  <SelectContent>{paymentMethods.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
          )}
          
          <div className="space-y-2 pt-4">
              <Label>Item Invoice</Label>
              <InvoiceItems items={formData.items} onItemsChange={handleItemsChange} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Deskripsi / Catatan</Label>
            <Textarea id="description" value={formData.description} onChange={handleInputChange} placeholder="Tambahkan deskripsi atau catatan tambahan..." />
          </div>

        </form>
        <DialogFooter className="pt-4 flex-col sm:flex-row sm:justify-between items-center bg-slate-900 -mx-6 -mb-6 px-6 py-4 mt-6 border-t border-slate-700">
            <div className="text-xl font-bold">
                Total: {formatCurrency(totalAmount)}
            </div>
            <div className='flex gap-2'>
              <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
              <Button type="submit" onClick={handleSubmit} className="bg-blue-600 hover:bg-blue-700">{invoice ? 'Perbarui Invoice' : 'Simpan Invoice'}</Button>
            </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default InvoiceFormDialog;