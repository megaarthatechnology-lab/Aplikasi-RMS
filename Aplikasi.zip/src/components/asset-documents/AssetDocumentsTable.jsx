import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical, Download } from 'lucide-react';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';

const AssetDocumentsTable = ({ documents, onEdit, onDelete }) => {
  const { toast } = useToast();

  const handleDownload = (fileRef) => {
    toast({
      title: "🚧 Fitur Dalam Pengembangan",
      description: "Fitur unduh dokumen belum diimplementasikan.",
    });
  };

  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Daftar Dokumen Aset</CardTitle>
        <CardDescription>Menampilkan {documents.length} dokumen yang sesuai.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Aset</TableHead>
                <TableHead>Dokumen</TableHead>
                <TableHead>Tanggal</TableHead>
                <TableHead>Penanggung Jawab</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {documents.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada dokumen</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan dokumen baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                documents.map((doc) => (
                  <TableRow key={doc.id}>
                    <TableCell>
                      <div className="font-bold">{doc.assetName}</div>
                      <Badge variant="outline" className="mt-1">{doc.assetCode}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{doc.documentName}</div>
                      <div className="text-sm text-slate-400">{doc.documentType}</div>
                      {doc.documentDescription && <div className="text-xs text-slate-400 mt-1 max-w-xs truncate" title={doc.documentDescription}>{doc.documentDescription}</div>}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">Upload: <span className="font-semibold">{format(new Date(doc.uploadDate), 'dd MMM yyyy')}</span></div>
                      {doc.expiryDate && <div className="text-xs text-slate-400">Kadaluarsa: {format(new Date(doc.expiryDate), 'dd MMM yyyy')}</div>}
                    </TableCell>
                    <TableCell>
                        <div className="font-medium">{doc.responsiblePerson}</div>
                    </TableCell>
                    <TableCell>{doc.dynamicStatus.badge}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleDownload(doc.fileReference)}>
                            <Download className="mr-2 h-4 w-4" /> Unduh
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onEdit(doc)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(doc.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default AssetDocumentsTable;