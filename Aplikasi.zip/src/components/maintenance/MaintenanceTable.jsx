import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const MaintenanceTable = ({ schedules, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Daftar Jadwal Perawatan</CardTitle>
        <CardDescription>Menampilkan {schedules.length} jadwal perawatan yang sesuai.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Aset</TableHead>
                <TableHead>Tipe Perawatan</TableHead>
                <TableHead>Jadwal</TableHead>
                <TableHead>Teknisi & Biaya</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {schedules.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada jadwal perawatan</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan jadwal baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                schedules.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell>
                      <div className="font-bold">{s.assetName}</div>
                      <Badge variant="outline" className="mt-1">{s.assetCode}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{s.maintenanceType}</Badge>
                      {s.description && <div className="text-xs text-slate-400 mt-1 max-w-xs truncate" title={s.description}>{s.description}</div>}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">Berikutnya: <span className="font-semibold">{format(new Date(s.nextMaintenanceDate), 'dd MMM yyyy')}</span></div>
                      <div className="text-xs text-slate-400">Terakhir: {format(new Date(s.lastMaintenanceDate), 'dd MMM yyyy')}</div>
                      <div className="text-xs text-slate-400">Interval: {s.maintenanceInterval}</div>
                    </TableCell>
                    <TableCell>
                        <div className="font-medium">{s.responsibleTechnician}</div>
                        <div className="text-sm text-slate-400">{formatCurrency(s.estimatedCost)}</div>
                    </TableCell>
                    <TableCell>{s.dynamicStatus.badge}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(s)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(s.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default MaintenanceTable;