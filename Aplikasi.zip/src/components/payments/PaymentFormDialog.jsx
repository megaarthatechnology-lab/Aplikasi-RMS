import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { paymentMethodOptions, paymentStatusOptions } from '@/lib/payments-utils.jsx';
import { format } from 'date-fns';

const PaymentFormDialog = ({ isOpen, onClose, onSave, payment }) => {
  const getInitialFormData = () => ({
    payerName: '',
    payeeName: '',
    amount: '',
    date: format(new Date(), 'yyyy-MM-dd'),
    paymentMethod: '',
    referenceNumber: '',
    status: 'pending',
    description: '',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (payment) {
        setFormData({
          ...payment,
          amount: payment.amount.toString(),
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [payment, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredFields = ['payerName', 'payeeName', 'amount', 'date', 'status', 'paymentMethod'];
    for (const field of requiredFields) {
      if (!formData[field]) {
        toast({ title: '⚠️ Data Tidak Lengkap', description: `Mohon lengkapi field "${field.replace(/([A-Z])/g, ' $1')}" yang wajib diisi.`, variant: 'destructive' });
        return;
      }
    }
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{payment ? 'Edit Pembayaran' : 'Tambah Pembayaran Baru'}</DialogTitle>
          <DialogDescription>{payment ? 'Perbarui informasi pembayaran.' : 'Buat catatan pembayaran baru.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="payerName">Nama Pembayar *</Label>
              <Input id="payerName" value={formData.payerName} onChange={handleInputChange} placeholder="PT. Konstruksi Jaya" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="payeeName">Nama Penerima *</Label>
              <Input id="payeeName" value={formData.payeeName} onChange={handleInputChange} placeholder="PT. Supplier Baja" required />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Jumlah (IDR) *</Label>
              <Input id="amount" type="number" value={formData.amount} onChange={handleInputChange} placeholder="15000000" required min="0" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="date">Tanggal Pembayaran *</Label>
              <Input id="date" type="date" value={formData.date} onChange={handleInputChange} required />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="paymentMethod">Metode Pembayaran *</Label>
              <Select value={formData.paymentMethod} onValueChange={(value) => handleSelectChange('paymentMethod', value)}>
                <SelectTrigger><SelectValue placeholder="Pilih Metode" /></SelectTrigger>
                <SelectContent>{paymentMethodOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
             <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{paymentStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
           <div className="space-y-2">
              <Label htmlFor="referenceNumber">No. Referensi</Label>
              <Input id="referenceNumber" value={formData.referenceNumber} onChange={handleInputChange} placeholder="PMT-001-INV-123" />
            </div>
          <div className="space-y-2">
            <Label htmlFor="description">Deskripsi</Label>
            <Textarea id="description" value={formData.description} onChange={handleInputChange} placeholder="Tambahkan deskripsi atau catatan tambahan..." />
          </div>
          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{payment ? 'Perbarui Pembayaran' : 'Simpan Pembayaran'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default PaymentFormDialog;