import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency } from '@/lib/utils';
import { getPaymentStatusBadge } from '@/lib/payments-utils.jsx';
import { Badge } from '@/components/ui/badge';

const PaymentsTable = ({ payments, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Daftar Pembayaran</CardTitle>
        <CardDescription>Menampilkan {payments.length} data pembayaran yang sesuai.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Detail Pembayaran</TableHead>
                <TableHead>Jumlah</TableHead>
                <TableHead>Tanggal & Metode</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payments.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada data pembayaran</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan data pembayaran baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                payments.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="font-bold">{p.payerName}</div>
                          <div className="text-xs text-slate-500">Pembayar</div>
                        </div>
                        <ArrowRight className="h-5 w-5 text-slate-500 shrink-0" />
                        <div>
                          <div className="font-bold">{p.payeeName}</div>
                          <div className="text-xs text-slate-500">Penerima</div>
                        </div>
                      </div>
                      {p.description && <div className="text-xs text-slate-400 mt-2 pl-1 max-w-md truncate">Ket: {p.description}</div>}
                    </TableCell>
                    <TableCell className="font-semibold">{formatCurrency(p.amount)}</TableCell>
                    <TableCell>
                        <div>{format(new Date(p.date), 'dd MMM yyyy')}</div>
                        <div className="text-xs text-slate-500 font-mono">{p.referenceNumber}</div>
                        <Badge variant="secondary" className="mt-1">{p.paymentMethod}</Badge>
                    </TableCell>
                    <TableCell>{getPaymentStatusBadge(p.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(p)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(p.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default PaymentsTable;