import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { debtStatusOptions } from '@/lib/debt-utils.jsx';
import { format } from 'date-fns';

const DebtFormDialog = ({ isOpen, onClose, onSave, debt }) => {
  const getInitialFormData = () => ({
    creditor: '',
    amount: '',
    interestRate: '',
    startDate: format(new Date(), 'yyyy-MM-dd'),
    dueDate: format(new Date(), 'yyyy-MM-dd'),
    status: 'active',
    description: '',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (debt) {
        setFormData({
          creditor: debt.creditor,
          amount: debt.amount.toString(),
          interestRate: debt.interestRate.toString(),
          startDate: debt.startDate,
          dueDate: debt.dueDate,
          status: debt.status,
          description: debt.description || '',
        });
      } else {
        setFormData(getInitialFormData());
      }
    }
  }, [debt, isOpen]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.creditor || !formData.amount || !formData.interestRate || !formData.startDate || !formData.dueDate) {
      toast({ title: '⚠️ Data Tidak Lengkap', description: 'Mohon lengkapi semua field yang wajib diisi.', variant: 'destructive' });
      return;
    }
    if (new Date(formData.dueDate) < new Date(formData.startDate)) {
      toast({ title: '⚠️ Tanggal Tidak Valid', description: 'Tanggal jatuh tempo tidak boleh sebelum tanggal mulai.', variant: 'destructive' });
      return;
    }
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{debt ? 'Edit Hutang' : 'Tambah Hutang Baru'}</DialogTitle>
          <DialogDescription>{debt ? 'Perbarui informasi hutang.' : 'Buat catatan hutang baru.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="creditor">Nama Kreditor *</Label>
            <Input id="creditor" value={formData.creditor} onChange={handleInputChange} placeholder="Contoh: Bank Mandiri" required />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Jumlah (IDR) *</Label>
              <Input id="amount" type="number" value={formData.amount} onChange={handleInputChange} placeholder="500000000" required min="0" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="interestRate">Suku Bunga (% per tahun) *</Label>
              <Input id="interestRate" type="number" value={formData.interestRate} onChange={handleInputChange} placeholder="8.5" required min="0" step="0.01" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">Tanggal Mulai *</Label>
              <Input id="startDate" type="date" value={formData.startDate} onChange={handleInputChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate">Tanggal Jatuh Tempo *</Label>
              <Input id="dueDate" type="date" value={formData.dueDate} onChange={handleInputChange} required />
            </div>
          </div>
           <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{debtStatusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          <div className="space-y-2">
            <Label htmlFor="description">Deskripsi</Label>
            <Textarea id="description" value={formData.description} onChange={handleInputChange} placeholder="Tambahkan deskripsi atau catatan tambahan..." />
          </div>
          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{debt ? 'Perbarui Data' : 'Tambah Hutang'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default DebtFormDialog;