import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency, getDebtStatusBadge } from '@/lib/debt-utils.jsx';

const DebtTable = ({ debts, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Daftar Hutang</CardTitle>
        <CardDescription>Menampilkan {debts.length} data hutang yang sesuai.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Kreditor</TableHead>
                <TableHead>Jumlah</TableHead>
                <TableHead>Bunga (%)</TableHead>
                <TableHead>Tgl. Mulai</TableHead>
                <TableHead>Jatuh Tempo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {debts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada data hutang</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan data hutang baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                debts.map((debt) => (
                  <TableRow key={debt.id}>
                    <TableCell className="font-medium">
                      <div>{debt.creditor}</div>
                       {debt.description && <div className="text-xs text-slate-400 mt-1 truncate max-w-xs">{debt.description}</div>}
                    </TableCell>
                    <TableCell>{formatCurrency(debt.amount)}</TableCell>
                    <TableCell>{debt.interestRate}%</TableCell>
                    <TableCell>{format(new Date(debt.startDate), 'dd MMM yyyy')}</TableCell>
                    <TableCell>{format(new Date(debt.dueDate), 'dd MMM yyyy')}</TableCell>
                    <TableCell>{getDebtStatusBadge(debt.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(debt)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(debt.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default DebtTable;