
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const BuyerContractTable = ({ contracts, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Daftar Kontrak Pembeli</CardTitle>
        <CardDescription>Menampilkan {contracts.length} kontrak yang sesuai.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Pembeli & Kontrak</TableHead>
                <TableHead>Periode</TableHead>
                <TableHead>Nilai Kontrak</TableHead>
                <TableHead>Syarat</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {contracts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada kontrak ditemukan</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan kontrak baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                contracts.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell>
                      <div className="font-bold">{c.buyerName}</div>
                      <div className="text-sm text-slate-400">{c.contractName}</div>
                      <Badge variant="outline" className="mt-1">{c.contractNumber}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">Mulai: {format(new Date(c.startDate), 'dd MMM yyyy')}</div>
                      <div className="text-sm">Selesai: {format(new Date(c.endDate), 'dd MMM yyyy')}</div>
                    </TableCell>
                    <TableCell>
                      <div className="font-bold text-green-400">{formatCurrency(c.contractValue)}</div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">Pembayaran: <span className="font-semibold">{c.paymentTerms}</span></div>
                      <div className="text-sm">Pengiriman: <span className="font-semibold">{c.deliveryTerms}</span></div>
                    </TableCell>
                    <TableCell>{c.dynamicStatus.badge}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(c)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(c.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default BuyerContractTable;
