import React, { useMemo, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  KBarProvider,
  KBarPortal,
  KBarPositioner,
  KBarAnimator,
  KBarSearch,
  KBarResults,
  useMatches,
  Action,
} from 'kbar';
import { FileText, LayoutDashboard, FolderOpen, Users, Building, Shield, Settings, LogOut, Search as SearchIcon, Truck, FileSignature } from 'lucide-react';

const searchStyle = {
  padding: '12px 16px',
  fontSize: '16px',
  width: '100%',
  boxSizing: 'border-box',
  outline: 'none',
  border: 'none',
  background: 'hsl(var(--background))',
  color: 'hsl(var(--foreground))',
};

const animatorStyle = {
  maxWidth: '600px',
  width: '100%',
  background: 'hsl(var(--background))',
  color: 'hsl(var(--foreground))',
  borderRadius: '8px',
  overflow: 'hidden',
  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
  border: '1px solid hsl(var(--border))',
};

const positionerStyle = {
  position: 'fixed',
  display: 'flex',
  alignItems: 'flex-start',
  justifyContent: 'center',
  width: '100%',
  inset: '0px',
  padding: '14vh 16px 16px',
  background: 'rgba(0 0 0 / .8)',
  backdropFilter: 'blur(4px)',
  boxSizing: 'border-box',
  zIndex: 100,
};


const GlobalSearchProvider = ({ children }) => {
  const navigate = useNavigate();
  const [dynamicActions, setDynamicActions] = useState([]);

  useEffect(() => {
    const actions = [];

    // Employees
    const employees = JSON.parse(localStorage.getItem('employeeList') || '[]');
    actions.push(...employees.map(emp => ({
      id: `emp-${emp.id}`,
      name: emp.name,
      keywords: `${emp.position} ${emp.department}`,
      section: 'Karyawan',
      perform: () => navigate('/employee-list'),
      icon: <Users className="h-4 w-4" />,
    })));

    // Projects
    const projects = JSON.parse(localStorage.getItem('projectList') || '[]');
    actions.push(...projects.map(proj => ({
      id: `proj-${proj.id}`,
      name: proj.name,
      keywords: proj.description,
      section: 'Proyek',
      perform: () => navigate('/project-list'),
      icon: <FolderOpen className="h-4 w-4" />,
    })));

    // Financial Notes
    const financialNotes = JSON.parse(localStorage.getItem('financialNotes') || '[]');
     actions.push(...financialNotes.map(note => ({
      id: `note-${note.id}`,
      name: note.title,
      keywords: note.content,
      section: 'Catatan Keuangan',
      perform: () => navigate('/financial-notes'),
      icon: <FileSignature className="h-4 w-4" />,
    })));

    // Equipment Mutations
    const mutations = JSON.parse(localStorage.getItem('equipmentMutations') || '[]');
    actions.push(...mutations.map(mut => ({
      id: `mut-${mut.id}`,
      name: `${mut.equipmentName} - ${mut.type}`,
      keywords: `${mut.fromLocation} ${mut.toLocation}`,
      section: 'Mutasi Alat',
      perform: () => navigate('/equipment-mutation'),
      icon: <Truck className="h-4 w-4" />,
    })));

    setDynamicActions(actions);
  }, []);

  const staticActions = useMemo(() => [
    { id: 'dashboard', name: 'Dashboard', keywords: 'home', section: 'Navigasi', perform: () => navigate('/'), icon: <LayoutDashboard className="h-4 w-4" /> },
    { id: 'income-statement', name: 'Laporan Laba Rugi', keywords: 'income statement report', section: 'Laporan', perform: () => navigate('/income-statement'), icon: <FileText className="h-4 w-4" /> },
    { id: 'balance-sheet', name: 'Neraca', keywords: 'balance sheet report', section: 'Laporan', perform: () => navigate('/balance-sheet'), icon: <FileText className="h-4 w-4" /> },
    { id: 'admin-panel', name: 'Panel Admin', keywords: 'admin users settings', section: 'Administrasi', perform: () => navigate('/admin-panel'), icon: <Shield className="h-4 w-4" /> },
    { id: 'settings', name: 'Pengaturan', keywords: 'settings profile security', section: 'Administrasi', perform: () => navigate('/settings'), icon: <Settings className="h-4 w-4" /> },
    { id: 'logout', name: 'Keluar', keywords: 'logout sign out', section: 'Administrasi', perform: () => alert('Logout!'), icon: <LogOut className="h-4 w-4" /> },
  ], [navigate]);

  return (
    <KBarProvider actions={[...staticActions, ...dynamicActions]}>
      <KBarPortal>
        <KBarPositioner style={positionerStyle}>
          <KBarAnimator style={animatorStyle}>
            <div className="flex items-center p-2 border-b border-slate-700">
               <SearchIcon className="h-5 w-5 text-slate-400 mx-2" />
               <KBarSearch style={searchStyle} defaultPlaceholder="Ketik perintah atau cari..."/>
            </div>
            <RenderResults />
          </KBarAnimator>
        </KBarPositioner>
      </KBarPortal>
      {children}
    </KBarProvider>
  );
};

function RenderResults() {
  const { results } = useMatches();

  return (
    <KBarResults
      items={results}
      onRender={({ item, active }) =>
        typeof item === 'string' ? (
          <div className="px-4 pt-4 pb-2 text-xs font-medium text-slate-400 uppercase">{item}</div>
        ) : (
          <div
            className={`flex items-center justify-between px-4 py-3 cursor-pointer transition-colors ${
              active ? 'bg-slate-700/50' : 'bg-transparent'
            }`}
          >
            <div className="flex items-center gap-3 overflow-hidden">
              {item.icon && <div className="text-slate-400 flex-shrink-0">{item.icon}</div>}
              <div className="flex flex-col overflow-hidden">
                <span className="text-sm text-slate-100 truncate">{item.name}</span>
                {item.keywords && <span className="text-xs text-slate-500 truncate">{item.keywords}</span>}
              </div>
            </div>
            {item.shortcut?.length ? (
              <div aria-hidden className="grid grid-flow-col gap-1">
                {item.shortcut.map((sc) => (
                  <kbd key={sc} className="pointer-events-none h-6 select-none items-center gap-1 rounded border border-slate-500 bg-slate-600 px-2 font-mono text-sm font-medium text-slate-300">
                    {sc}
                  </kbd>
                ))}
              </div>
            ) : null}
          </div>
        )
      }
    />
  );
}


export default GlobalSearchProvider;