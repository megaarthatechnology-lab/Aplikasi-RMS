import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical, MapPin } from 'lucide-react';
import { format } from 'date-fns';
import { getAssetLocationStatusBadge } from '@/lib/asset-location-utils.jsx';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

const AssetLocationTable = ({ locations, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Data Lokasi Aset</CardTitle>
        <CardDescription>Menampilkan {locations.length} data lokasi aset yang sesuai.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Aset</TableHead>
                <TableHead>Lokasi Terkini</TableHead>
                <TableHead>Penanggung Jawab</TableHead>
                <TableHead>Update Terakhir</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {locations.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada data lokasi</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan data baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                locations.map((loc) => (
                  <TableRow key={loc.id}>
                    <TableCell>
                      <div className="font-bold">{loc.assetName}</div>
                      <Badge variant="outline" className="mt-1">{loc.assetCode}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{loc.currentLocation}</div>
                      <div className="text-sm text-slate-400">{loc.buildingFloor}, {loc.roomArea}</div>
                      {loc.coordinates && (
                         <TooltipProvider>
                            <Tooltip>
                                <TooltipTrigger asChild>
                                    <a href={`https://www.openstreetmap.org/?mlat=${loc.coordinates.split(',')[0]}&mlon=${loc.coordinates.split(',')[1]}`} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 mt-1">
                                        <MapPin className="h-3 w-3" />
                                        Lihat Peta
                                    </a>
                                </TooltipTrigger>
                                <TooltipContent>
                                    <p>{loc.coordinates}</p>
                                </TooltipContent>
                            </Tooltip>
                        </TooltipProvider>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">{loc.responsiblePerson}</div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">{format(new Date(loc.lastUpdate), 'dd MMM yyyy, HH:mm')}</div>
                    </TableCell>
                    <TableCell>{getAssetLocationStatusBadge(loc.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(loc)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(loc.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default AssetLocationTable;