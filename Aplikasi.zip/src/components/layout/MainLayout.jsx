import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';
import { AnimatePresence, motion } from 'framer-motion';

const pageTitles = {
  '/': 'Dashboard',
  '/jurnal-buku-besar': 'Jurnal & Buku Besar',
  '/laporan-laba-rugi': 'Laporan Laba/Rugi',
  '/laporan-perubahan-ekuitas': 'Laporan Perubahan Ekuitas',
  '/neraca': 'Neraca',
  '/laporan-arus-kas': 'Laporan Arus Kas',
  '/catatan-laporan-keuangan': 'Catatan Atas Laporan Keuangan',
  '/laporan-progres-proyek': 'Laporan Progres Proyek',
  '/rekap-karyawan': 'Rekap Karyawan',
  '/mutasi-alat': 'Mutasi Alat',
  '/pemakaian-bahan-baku': 'Pemakaian Bahan Baku',
  '/pemakaian-oli-bbm': 'Pemakaian Oli & BBM',
  '/pemakaian-sparepart': 'Pemakaian Sparepart',
  '/transaksi-berulang': 'Transaksi Berulang',
  '/info-dokumen-hutang': 'Informasi Dokumen Hutang',
  '/jadwal-pembayaran-hutang': 'Jadwal Pembayaran Hutang',
  '/daftar-invoice-keluar': 'Daftar Invoice Dikeluarkan',
  '/daftar-invoice-bayar': 'Daftar Invoice Dibayar',
  '/pajak-bayar-dimuka': 'Pajak Bayar Dimuka',
  '/pembayaran-transfer-bank': 'Pembayaran & Transfer Bank',
  '/daftar-aset': 'Daftar Aset',
  '/lokasi-aset': 'Lokasi Aset',
  '/jadwal-perawatan-aset': 'Jadwal Perawatan Aset',
  '/monitoring-dokumen-aset': 'Monitoring Dokumen Aset',
  '/kontrak-by-supplier': 'Kontrak Berdasarkan Pemasok',
  '/kontrak-by-jenis-barang': 'Kontrak Berdasarkan Jenis Barang',
  '/kontrak-by-buyer': 'Kontrak Berdasarkan Pembeli',
};

const MainLayout = () => {
  const location = useLocation();
  const pageTitle = pageTitles[location.pathname] || 'Akuntansi';

  return (
    <div className="flex h-screen bg-gray-900">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header pageTitle={pageTitle} />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-900 p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
};

export default MainLayout;