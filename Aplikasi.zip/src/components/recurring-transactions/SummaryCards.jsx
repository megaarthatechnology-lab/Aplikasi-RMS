import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RefreshCw, DollarSign, Calendar } from 'lucide-react';
import { formatCurrency } from '@/lib/recurring-transactions-utils';

const SummaryCards = ({ transactions }) => {
  const activeTransactions = transactions.filter(t => t.status === 'active');
  
  const totalMonthlyValue = activeTransactions.reduce((sum, t) => {
    let monthlyAmount = 0;
    switch (t.frequency) {
      case 'daily': monthlyAmount = t.amount * 30; break;
      case 'weekly': monthlyAmount = t.amount * 4; break;
      case 'monthly': monthlyAmount = t.amount; break;
      case 'yearly': monthlyAmount = t.amount / 12; break;
      default: monthlyAmount = 0;
    }
    return sum + monthlyAmount;
  }, 0);

  const upcomingExecutions = activeTransactions.filter(t => t.nextExecution !== '-').length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card className="glass-effect">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Transaksi Aktif</CardTitle>
          <RefreshCw className="h-4 w-4 text-blue-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{activeTransactions.length}</div>
          <p className="text-xs text-muted-foreground mt-1">Transaksi berjalan</p>
        </CardContent>
      </Card>

      <Card className="glass-effect">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Estimasi Nilai Bulanan</CardTitle>
          <DollarSign className="h-4 w-4 text-green-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{formatCurrency(totalMonthlyValue)}</div>
          <p className="text-xs text-muted-foreground mt-1">Dari transaksi aktif</p>
        </CardContent>
      </Card>

      <Card className="glass-effect">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Eksekusi Berikutnya</CardTitle>
          <Calendar className="h-4 w-4 text-purple-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{upcomingExecutions}</div>
          <p className="text-xs text-muted-foreground mt-1">Transaksi terjadwal</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default SummaryCards;