import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableRow } from '@/components/ui/table';
import { format, differenceInDays } from 'date-fns';
import { id } from 'date-fns/locale';
import { formatCurrency } from '@/lib/recurring-transactions-utils.jsx';

const UpcomingTransactions = ({ transactions }) => {
  const upcoming = transactions
    .filter(t => t.status === 'active' && t.nextExecutionDate)
    .sort((a, b) => new Date(a.nextExecutionDate) - new Date(b.nextExecutionDate))
    .slice(0, 5);

  const getUrgencyColor = (date) => {
    const days = differenceInDays(new Date(date), new Date());
    if (days <= 3) return 'text-red-400';
    if (days <= 7) return 'text-yellow-400';
    return 'text-green-400';
  };

  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Transaksi Akan Datang</CardTitle>
        <CardDescription>5 transaksi terjadwal berikutnya.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
        <Table>
          <TableBody>
            {upcoming.length > 0 ? (
              upcoming.map(t => (
                <TableRow key={t.id}>
                  <TableCell>
                    <div className="font-medium">{t.name}</div>
                    <div className="text-sm text-muted-foreground">{t.category}</div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="font-bold">{formatCurrency(t.amount)}</div>
                    <div className={`text-sm ${getUrgencyColor(t.nextExecutionDate)}`}>
                      {format(new Date(t.nextExecutionDate), 'dd MMM yyyy', { locale: id })}
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell className="text-center text-muted-foreground py-8" colSpan={2}>
                  Tidak ada transaksi yang akan datang.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default UpcomingTransactions;