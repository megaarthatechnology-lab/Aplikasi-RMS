import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, History, MoreVertical, Play, Pause, PowerOff, Power } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency, getFrequencyLabel, getStatusBadge } from '@/lib/recurring-transactions-utils.jsx';

const RecurringTransactionsTable = ({ transactions, onEdit, onDelete, onViewHistory, onToggleStatus, onExecute }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Daftar Transaksi</CardTitle>
        <CardDescription>Menampilkan {transactions.length} transaksi yang cocok.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[300px]">Nama Transaksi</TableHead>
                <TableHead>Jumlah</TableHead>
                <TableHead>Frekuensi</TableHead>
                <TableHead>Eksekusi Berikutnya</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada transaksi ditemukan</p>
                    <p className="text-sm">Coba sesuaikan filter pencarian Anda atau tambahkan transaksi baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                transactions.map((t) => (
                  <TableRow key={t.id}>
                    <TableCell className="font-medium">
                      <div>{t.name}</div>
                      <div className="text-xs text-muted-foreground">{t.category}</div>
                      {t.description && <div className="text-xs text-slate-400 mt-1 truncate max-w-xs">{t.description}</div>}
                    </TableCell>
                    <TableCell>{formatCurrency(t.amount)}</TableCell>
                    <TableCell>{getFrequencyLabel(t.frequency)}</TableCell>
                    <TableCell>{t.nextExecution !== '-' ? format(new Date(t.nextExecution), 'dd MMM yyyy') : 'N/A'}</TableCell>
                    <TableCell>{getStatusBadge(t.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                           <DropdownMenuItem onClick={() => onExecute(t.id)} disabled={t.status !== 'active'}>
                            <Play className="mr-2 h-4 w-4" /> Eksekusi Manual
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onEdit(t)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onViewHistory(t)}>
                            <History className="mr-2 h-4 w-4" /> Lihat Riwayat
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          {t.status === 'active' && (
                            <DropdownMenuItem onClick={() => onToggleStatus(t.id, 'paused')}>
                              <Pause className="mr-2 h-4 w-4" /> Jeda
                            </DropdownMenuItem>
                          )}
                          {t.status === 'paused' && (
                            <DropdownMenuItem onClick={() => onToggleStatus(t.id, 'active')}>
                              <Play className="mr-2 h-4 w-4" /> Lanjutkan
                            </DropdownMenuItem>
                          )}
                           {t.status !== 'inactive' && t.status !== 'active' && (
                            <DropdownMenuItem onClick={() => onToggleStatus(t.id, 'active')}>
                              <Power className="mr-2 h-4 w-4" /> Aktifkan Kembali
                            </DropdownMenuItem>
                          )}
                          {t.status !== 'inactive' && (
                            <DropdownMenuItem onClick={() => onToggleStatus(t.id, 'inactive')}>
                              <PowerOff className="mr-2 h-4 w-4" /> Nonaktifkan
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(t.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default RecurringTransactionsTable;