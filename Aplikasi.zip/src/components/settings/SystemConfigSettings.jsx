import React, { useState, useEffect } from 'react';
import { Save, RefreshCw, Upload, Download, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { format } from 'date-fns';

const initialConfig = {
  maintenanceMode: false,
  sessionTimeout: 30, // in minutes
  ipWhitelist: '192.168.1.1\n::1',
};

const SystemConfigSettings = () => {
  const [config, setConfig] = useState(initialConfig);
  const { toast } = useToast();

  useEffect(() => {
    const savedConfig = JSON.parse(localStorage.getItem('systemConfig')) || initialConfig;
    setConfig(savedConfig);
  }, []);

  const handleInputChange = (e) => {
    const { id, value, type, checked } = e.target;
    setConfig(prev => ({
      ...prev,
      [id]: type === 'checkbox' ? checked : value,
    }));
  };
  
  const handleSwitchChange = (id, checked) => {
    setConfig(prev => ({ ...prev, [id]: checked }));
  };

  const handleSave = () => {
    localStorage.setItem('systemConfig', JSON.stringify(config));
    toast({
      title: '✅ Konfigurasi Disimpan',
      description: 'Pengaturan sistem telah berhasil diperbarui.',
    });
  };
  
  const handleBackup = () => {
     toast({
      title: '💾 Pencadangan Data Dimulai',
      description: 'Data aplikasi Anda sedang dicadangkan. Ini mungkin memerlukan beberapa saat.',
    });
    // Simulate backup
    setTimeout(() => {
        toast({
            title: '✅ Pencadangan Berhasil',
            description: `Data berhasil dicadangkan pada ${format(new Date(), 'Pp')}.`,
        });
    }, 2000);
  };
  
  const handleRestore = () => {
      toast({
      title: 'Restorasi Data',
      description: '🚧 Fitur ini belum diimplementasikan. Harap berhati-hati saat menggunakan di produksi.',
    });
  };

  const systemInfo = {
    appVersion: '2.1.0',
    reactVersion: '18.2.0',
    viteVersion: '4.4.5',
    lastChecked: new Date().toISOString(),
  };

  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle className="text-2xl">Konfigurasi Sistem</CardTitle>
        <CardDescription>Kelola pengaturan aplikasi, keamanan, dan data sistem.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-8">
        
        {/* Application Settings */}
        <div>
            <h3 className="text-lg font-semibold mb-4 border-b border-border pb-2">Pengaturan Aplikasi</h3>
            <div className="space-y-6">
                <div className="flex items-center justify-between p-4 rounded-lg bg-card-foreground/5 dark:bg-card-foreground/5">
                    <div>
                        <Label htmlFor="maintenanceMode" className="font-semibold text-base">Mode Pemeliharaan</Label>
                        <p className="text-sm text-muted-foreground">Alihkan aplikasi ke mode pemeliharaan untuk umum.</p>
                    </div>
                    <Switch id="maintenanceMode" checked={config.maintenanceMode} onCheckedChange={(checked) => handleSwitchChange('maintenanceMode', checked)} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                    <Label htmlFor="sessionTimeout">Batas Waktu Sesi (menit)</Label>
                    <Input id="sessionTimeout" type="number" value={config.sessionTimeout} onChange={handleInputChange} className="md:w-1/2" />
                </div>
            </div>
        </div>

        {/* Security Options */}
        <div>
            <h3 className="text-lg font-semibold mb-4 border-b border-border pb-2">Opsi Keamanan</h3>
            <div className="space-y-4">
                 <Label htmlFor="ipWhitelist">Daftar Putih Alamat IP</Label>
                 <p className="text-sm text-muted-foreground">Batasi akses ke alamat IP tertentu. Satu alamat per baris.</p>
                 <Textarea id="ipWhitelist" value={config.ipWhitelist} onChange={handleInputChange} rows={4} placeholder="Contoh:&#10;203.0.113.5&#10;198.51.100.12" />
            </div>
        </div>
        
        {/* Backup and Restore */}
         <div>
            <h3 className="text-lg font-semibold mb-4 border-b border-border pb-2">Cadangkan & Pulihkan Data</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button variant="outline" onClick={handleBackup}><Download className="mr-2 h-4 w-4" /> Cadangkan Data</Button>
                <Button variant="outline" onClick={handleRestore}><Upload className="mr-2 h-4 w-4" /> Pulihkan Data</Button>
            </div>
        </div>

        {/* System Information */}
        <div>
            <h3 className="text-lg font-semibold mb-4 border-b border-border pb-2">Informasi Sistem</h3>
            <div className="p-4 rounded-lg bg-card-foreground/5 dark:bg-card-foreground/5 space-y-3 text-sm">
                <div className="flex justify-between"><span>Versi Aplikasi:</span> <span className="font-mono text-muted-foreground">{systemInfo.appVersion}</span></div>
                <div className="flex justify-between"><span>Versi React:</span> <span className="font-mono text-muted-foreground">{systemInfo.reactVersion}</span></div>
                <div className="flex justify-between"><span>Versi Vite:</span> <span className="font-mono text-muted-foreground">{systemInfo.viteVersion}</span></div>
                <div className="flex justify-between"><span>Pemeriksaan Terakhir:</span> <span className="font-mono text-muted-foreground">{format(new Date(systemInfo.lastChecked), 'Pp')}</span></div>
            </div>
        </div>

        <div className="flex justify-end pt-4">
            <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700 text-white"><Save className="mr-2 h-4 w-4" /> Simpan Konfigurasi</Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default SystemConfigSettings;