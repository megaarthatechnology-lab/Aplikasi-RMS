import React, { useState, useEffect } from 'react';
import { Save, X, Edit, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const initialProfile = {
  name: 'Admin Akuntansi',
  email: 'admin@perusahaan.com',
  phone: '0812-3456-7890',
  department: 'Keuangan',
  position: 'Staf Akuntansi Senior',
  avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=256&h=256&fit=crop',
};

const ProfileSettings = () => {
  const [profile, setProfile] = useState({});
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({});
  const { toast } = useToast();

  useEffect(() => {
    const savedProfile = JSON.parse(localStorage.getItem('userProfile')) || initialProfile;
    setProfile(savedProfile);
    setFormData(savedProfile);
  }, []);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleSave = () => {
    localStorage.setItem('userProfile', JSON.stringify(formData));
    setProfile(formData);
    setIsEditing(false);
    toast({
      title: '✅ Profil Diperbarui',
      description: 'Informasi profil Anda telah berhasil disimpan.',
    });
  };

  const handleCancel = () => {
    setFormData(profile);
    setIsEditing(false);
  };
  
  const handleAvatarChange = () => {
     toast({
      title: "🚧 Fitur Dalam Pengembangan",
      description: "Fitur unggah gambar profil akan segera tersedia! 🚀",
    });
  }

  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle className="text-2xl">Profil Pengguna</CardTitle>
        <CardDescription>Lihat dan perbarui informasi detail profil Anda.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="relative group flex-shrink-0">
              <img class="w-32 h-32 rounded-full border-4 border-slate-600 group-hover:opacity-75 transition-opacity" alt="User profile picture" src="https://images.unsplash.com/photo-1544212408-c711b7c19b92" />
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute inset-0 m-auto h-16 w-16 bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={handleAvatarChange}
              >
                  <Camera className="h-6 w-6 text-white"/>
              </Button>
            </div>
            <div className="text-center md:text-left">
              <h3 className="text-2xl font-bold">{profile.name}</h3>
              <p className="text-blue-400 font-medium">{profile.position}</p>
              <p className="text-muted-foreground">{profile.department}</p>
            </div>
             <div className="flex-grow flex justify-center md:justify-end">
               {isEditing ? (
                <div className="flex gap-2">
                  <Button variant="outline" onClick={handleCancel}><X className="mr-2 h-4 w-4" /> Batal</Button>
                  <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700 text-white"><Save className="mr-2 h-4 w-4" /> Simpan</Button>
                </div>
              ) : (
                <Button onClick={() => setIsEditing(true)}><Edit className="mr-2 h-4 w-4" /> Edit Profil</Button>
              )}
             </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
          <div>
            <Label htmlFor="name">Nama Lengkap</Label>
            <Input id="name" value={formData.name} onChange={handleInputChange} disabled={!isEditing} />
          </div>
          <div>
            <Label htmlFor="email">Alamat Email</Label>
            <Input id="email" type="email" value={formData.email} onChange={handleInputChange} disabled={!isEditing} />
          </div>
          <div>
            <Label htmlFor="phone">Nomor Telepon</Label>
            <Input id="phone" type="tel" value={formData.phone} onChange={handleInputChange} disabled={!isEditing} />
          </div>
           <div>
            <Label htmlFor="position">Jabatan</Label>
            <Input id="position" value={formData.position} onChange={handleInputChange} disabled={!isEditing} />
          </div>
          <div className="md:col-span-2">
            <Label htmlFor="department">Departemen</Label>
            <Input id="department" value={formData.department} onChange={handleInputChange} disabled={!isEditing} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProfileSettings;