import React, { createContext, useContext, useState, useEffect } from 'react';

const AppearanceContext = createContext();

export const useAppearance = () => useContext(AppearanceContext);

const defaultAppearance = {
  theme: 'dark',
  fontSize: 16,
  sidebarLayout: 'spacious',
};

export const AppearanceProvider = ({ children }) => {
  const [appearance, setAppearance] = useState(defaultAppearance);

  useEffect(() => {
    try {
      const savedAppearance = JSON.parse(localStorage.getItem('appearanceSettings'));
      if (savedAppearance) {
        setAppearance(savedAppearance);
      } else {
        localStorage.setItem('appearanceSettings', JSON.stringify(defaultAppearance));
      }
    } catch (error) {
      console.error("Failed to load appearance settings from localStorage", error);
      setAppearance(defaultAppearance);
    }
  }, []);
  
  useEffect(() => {
    // Apply theme
    document.body.classList.remove('light', 'dark');
    document.body.classList.add(appearance.theme);
    
    // Apply font size
    document.body.style.setProperty('--font-size', `${appearance.fontSize}px`);

    // Persist to localStorage
    try {
      localStorage.setItem('appearanceSettings', JSON.stringify(appearance));
    } catch (error) {
      console.error("Failed to save appearance settings to localStorage", error);
    }
  }, [appearance]);

  const updateAppearance = (newSettings) => {
    setAppearance(prev => ({ ...prev, ...newSettings }));
  };

  const value = {
    ...appearance,
    setTheme: (theme) => updateAppearance({ theme }),
    setFontSize: (fontSize) => updateAppearance({ fontSize }),
    setSidebarLayout: (sidebarLayout) => updateAppearance({ sidebarLayout }),
  };

  return (
    <AppearanceContext.Provider value={value}>
      {children}
    </AppearanceContext.Provider>
  );
};