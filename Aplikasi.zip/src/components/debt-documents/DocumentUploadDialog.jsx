import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { UploadCloud } from 'lucide-react';
import { formatFileSize, getFileIcon } from '@/lib/debt-documents-utils.jsx';

const DocumentUploadDialog = ({ isOpen, onClose, onSave, document, debts }) => {
  const getInitialFormData = () => ({
    name: '',
    type: '',
    size: 0,
    debtId: '',
    description: '',
  });
  
  const [formData, setFormData] = useState(getInitialFormData());
  const [file, setFile] = useState(null);
  const fileInputRef = useRef(null);
  const { toast } = useToast();
  
  const isEditing = !!document;

  useEffect(() => {
    if (isOpen) {
      if (isEditing) {
        setFormData({
          name: document.name,
          type: document.type,
          size: document.size,
          debtId: document.debtId,
          description: document.description || '',
        });
        setFile(null); // No file change when editing
      } else {
        setFormData(getInitialFormData());
        setFile(null);
        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }
      }
    }
  }, [document, isOpen, isEditing]);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setFormData(prev => ({
        ...prev,
        name: selectedFile.name,
        type: selectedFile.type,
        size: selectedFile.size,
      }));
    }
  };
  
  const handleSelectChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleDescriptionChange = (e) => {
      setFormData(prev => ({ ...prev, description: e.target.value }));
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    if(isEditing) {
        if (!formData.debtId) {
            toast({ title: '⚠️ Referensi Dibutuhkan', description: 'Mohon pilih referensi hutang untuk dokumen ini.', variant: 'destructive' });
            return;
        }
    } else {
        if (!file) {
            toast({ title: '⚠️ File Dibutuhkan', description: 'Mohon pilih file yang akan diunggah.', variant: 'destructive' });
            return;
        }
        if (!formData.debtId) {
            toast({ title: '⚠️ Referensi Dibutuhkan', description: 'Mohon pilih referensi hutang untuk dokumen ini.', variant: 'destructive' });
            return;
        }
    }
    
    // NOTE: In a real app, you would upload the `file` object here.
    // For this simulation, we only save the metadata from `formData`.
    toast({
        title: "ℹ️ Simulasi Unggah",
        description: "Dalam aplikasi nyata, file akan diunggah ke server. Di sini, kita hanya menyimpan metadatanya.",
    });

    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'Edit Detail Dokumen' : 'Unggah Dokumen Baru'}</DialogTitle>
          <DialogDescription>{isEditing ? 'Perbarui deskripsi atau referensi hutang.' : 'Unggah dokumen baru dan hubungkan ke data hutang.'}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          {!isEditing && (
             <div
              className="border-2 border-dashed border-slate-600 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                id="file-upload"
              />
              {file ? (
                <div className="flex flex-col items-center gap-2 text-slate-300">
                    {getFileIcon(file.type)}
                    <span className="font-semibold">{file.name}</span>
                    <span className="text-sm text-slate-400">{formatFileSize(file.size)}</span>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2 text-slate-400">
                  <UploadCloud className="h-12 w-12" />
                  <span className="font-semibold text-slate-300">Klik untuk memilih file</span>
                  <span className="text-sm">PDF, PNG, JPG, DOCX, dll.</span>
                </div>
              )}
            </div>
          )}

          { (isEditing || file) && (
            <>
              <div className="space-y-2">
                <Label htmlFor="debtId">Referensi Hutang *</Label>
                <Select value={formData.debtId} onValueChange={(value) => handleSelectChange('debtId', value)}>
                  <SelectTrigger><SelectValue placeholder="Pilih hutang terkait..." /></SelectTrigger>
                  <SelectContent>
                    {debts.map(d => <SelectItem key={d.id} value={d.id.toString()}>{d.creditor}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Deskripsi</Label>
                <Textarea id="description" value={formData.description} onChange={handleDescriptionChange} placeholder="Tambahkan deskripsi atau catatan untuk dokumen ini..." />
              </div>
            </>
          )}

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">{isEditing ? 'Perbarui Data' : 'Simpan & Unggah'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default DocumentUploadDialog;