import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, RotateCcw } from 'lucide-react';
import { fileTypeOptions } from '@/lib/debt-documents-utils.jsx';

const DocumentFilterControls = ({ filters, setFilters, debts }) => {
  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFilters(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const resetFilters = () => {
    setFilters({ searchTerm: '', fileType: 'all', debtRef: 'all' });
  };

  return (
    <Card className="glass-effect">
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <div className="lg:col-span-2">
            <label htmlFor="searchTerm" className="text-sm font-medium text-slate-300 block mb-2">Cari Dokumen</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="searchTerm"
                placeholder="Nama file atau kreditor..."
                value={filters.searchTerm}
                onChange={handleInputChange}
                className="pl-10"
              />
            </div>
          </div>
          <div>
            <label htmlFor="fileType" className="text-sm font-medium text-slate-300 block mb-2">Filter Tipe File</label>
            <Select id="fileType" value={filters.fileType} onValueChange={(value) => handleSelectChange('fileType', value)}>
              <SelectTrigger><SelectValue placeholder="Pilih Tipe File" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Tipe</SelectItem>
                {fileTypeOptions.map(opt => (
                  <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
           <div>
            <label htmlFor="debtRef" className="text-sm font-medium text-slate-300 block mb-2">Filter Referensi Hutang</label>
            <Select id="debtRef" value={filters.debtRef} onValueChange={(value) => handleSelectChange('debtRef', value)}>
              <SelectTrigger><SelectValue placeholder="Pilih Referensi" /></SelectTrigger>
              <SelectContent>
                 <SelectItem value="all">Semua Referensi</SelectItem>
                 {debts.map(debt => (
                     <SelectItem key={debt.id} value={debt.id.toString()}>{debt.creditor}</SelectItem>
                 ))}
              </SelectContent>
            </Select>
          </div>

        </div>
        <div className="mt-4 flex justify-end">
             <Button variant="outline" onClick={resetFilters} className="w-full sm:w-auto">
                <RotateCcw className="mr-2 h-4 w-4" /> Reset Filter
            </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default DocumentFilterControls;