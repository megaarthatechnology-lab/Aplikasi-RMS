import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Edit, Trash2, MoreVertical } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency } from '@/lib/utils';
import { getPaymentStatusBadge, getFilingStatusBadge, getTaxStatusBadge } from '@/lib/taxation-utils.jsx';
import { Badge } from '@/components/ui/badge';

const TaxationTable = ({ records, onEdit, onDelete }) => {
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle>Data Perpajakan</CardTitle>
        <CardDescription>Menampilkan {records.length} catatan pajak yang sesuai dengan filter.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Jenis & Periode Pajak</TableHead>
                <TableHead>Dasar Pengenaan & Tarif</TableHead>
                <TableHead>Jumlah Pajak</TableHead>
                <TableHead>Pembayaran</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {records.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    <p className="font-semibold">Tidak ada data pajak</p>
                    <p className="text-sm">Coba sesuaikan filter atau tambahkan data baru.</p>
                  </TableCell>
                </TableRow>
              ) : (
                records.map((record) => (
                  <TableRow key={record.id}>
                    <TableCell>
                      <div className="font-bold">{record.taxType}</div>
                      <div className="text-sm text-slate-400">Masa: {format(new Date(record.taxPeriod + '-01'), 'MMMM yyyy')}</div>
                      <Badge variant="outline" className="mt-1 text-xs">{record.taxIdentificationNumber}</Badge>
                      {record.notes && <div className="text-xs text-slate-400 mt-1 max-w-xs truncate" title={record.notes}>{record.notes}</div>}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">DPP: <span className="font-semibold">{formatCurrency(record.taxBaseAmount)}</span></div>
                      <div className="text-sm text-slate-400">Tarif: {record.taxRate}%</div>
                    </TableCell>
                    <TableCell>
                      <div className="font-bold text-green-400">{formatCurrency(record.taxAmountPayable)}</div>
                    </TableCell>
                    <TableCell>
                      {record.paymentDate ? (
                        <>
                          <div className="text-sm font-medium">{format(new Date(record.paymentDate), 'dd MMM yyyy')}</div>
                          <div className="text-xs text-slate-400">{record.paymentMethod}</div>
                        </>
                      ) : (
                        <div className="text-sm text-slate-400">Belum dibayar</div>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        {getPaymentStatusBadge(record.paymentStatus)}
                        {getFilingStatusBadge(record.filingStatus)}
                        {getTaxStatusBadge(record.status)}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(record)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onDelete(record.id)} className="text-red-500 focus:text-red-500">
                            <Trash2 className="mr-2 h-4 w-4" /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default TaxationTable;