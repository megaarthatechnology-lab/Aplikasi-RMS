import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const LaporanArusKas = () => {
  return <PlaceholderPage title="Laporan Arus Kas" description="Halaman untuk melihat laporan arus kas." />;
};

export default LaporanArusKas;