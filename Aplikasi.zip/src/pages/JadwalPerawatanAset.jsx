import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const JadwalPerawatanAset = () => {
  return <PlaceholderPage title="Jadwal Perawatan Aset" description="Halaman untuk jadwal perawatan aset." />;
};

export default JadwalPerawatanAset;