import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Edit, Trash2, Calendar, Flag, BarChart, MoreVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const PROJECT_STATUS = {
  Planning: { label: 'Perencanaan', color: 'bg-yellow-500/20 text-yellow-400', progressColor: 'bg-yellow-500' },
  InProgress: { label: 'Berlangsung', color: 'bg-blue-500/20 text-blue-400', progressColor: 'bg-blue-500' },
  Completed: { label: 'Selesai', color: 'bg-green-500/20 text-green-400', progressColor: 'bg-green-500' },
  OnHold: { label: 'Ditunda', color: 'bg-slate-500/20 text-slate-400', progressColor: 'bg-slate-500' },
  Cancelled: { label: 'Dibatalkan', color: 'bg-red-500/20 text-red-400', progressColor: 'bg-red-500' },
};

const defaultProjects = [
  {
    id: 'PRJ-001',
    name: 'Pembangunan Gedung Perkantoran ABC',
    description: 'Proyek pembangunan gedung 10 lantai di pusat kota dengan fasilitas modern.',
    status: 'InProgress',
    startDate: '2024-01-01',
    endDate: '2025-12-31',
    progress: 65,
  },
  {
    id: 'PRJ-002',
    name: 'Renovasi Pabrik XYZ',
    description: 'Renovasi dan modernisasi lini produksi pabrik untuk meningkatkan efisiensi.',
    status: 'Planning',
    startDate: '2025-02-01',
    endDate: '2025-08-31',
    progress: 10,
  },
  {
    id: 'PRJ-003',
    name: 'Pembangunan Jembatan Layang',
    description: 'Proyek infrastruktur untuk mengurangi kemacetan di jalan protokol.',
    status: 'OnHold',
    startDate: '2023-06-01',
    endDate: '2024-12-31',
    progress: 40,
  },
    {
    id: 'PRJ-004',
    name: 'Konstruksi Rumah Sakit',
    description: 'Pembangunan rumah sakit tipe B dengan kapasitas 200 tempat tidur.',
    status: 'Completed',
    startDate: '2022-01-15',
    endDate: '2024-05-20',
    progress: 100,
  },
];

const ProjectList = () => {
  const { toast } = useToast();
  const [projects, setProjects] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentProject, setCurrentProject] = useState(null);
  const [projectData, setProjectData] = useState({ name: '', description: '', status: '', startDate: '', endDate: '', progress: 0 });

  useEffect(() => {
    try {
      const savedProjects = localStorage.getItem('projectList');
      if (savedProjects) {
        setProjects(JSON.parse(savedProjects));
      } else {
        setProjects(defaultProjects);
        localStorage.setItem('projectList', JSON.stringify(defaultProjects));
      }
    } catch (error) {
      console.error("Gagal memuat proyek dari localStorage:", error);
      setProjects(defaultProjects);
    }
  }, []);

  const saveProjectsToLocalStorage = (updatedProjects) => {
    try {
      localStorage.setItem('projectList', JSON.stringify(updatedProjects));
    } catch (error) {
      console.error("Gagal menyimpan proyek ke localStorage:", error);
      toast({
        variant: "destructive",
        title: "Gagal Menyimpan Proyek",
        description: "Tidak dapat menyimpan perubahan ke penyimpanan lokal.",
      });
    }
  };

  const handleOpenDialog = (project = null) => {
    setCurrentProject(project);
    if (project) {
      setProjectData({ ...project, progress: project.progress || 0 });
    } else {
      setProjectData({ name: '', description: '', status: 'Planning', startDate: '', endDate: '', progress: 0 });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setCurrentProject(null);
    setProjectData({ name: '', description: '', status: '', startDate: '', endDate: '', progress: 0 });
  };

  const handleSaveProject = () => {
    if (!projectData.name || !projectData.status || !projectData.startDate || !projectData.endDate) {
      toast({
        variant: "destructive",
        title: "Gagal Menyimpan",
        description: "Nama, status, tanggal mulai, dan tanggal selesai tidak boleh kosong.",
      });
      return;
    }

    let updatedProjects;
    if (currentProject) {
      updatedProjects = projects.map((p) =>
        p.id === currentProject.id ? { ...projectData, id: currentProject.id } : p
      );
      toast({ title: "Proyek Diperbarui", description: `Proyek "${projectData.name}" berhasil diperbarui.` });
    } else {
      const newProject = {
        ...projectData,
        id: `PRJ-${String(Date.now()).slice(-4)}`,
      };
      updatedProjects = [...projects, newProject];
      toast({ title: "Proyek Ditambahkan", description: `Proyek baru "${projectData.name}" berhasil ditambahkan.` });
    }
    setProjects(updatedProjects);
    saveProjectsToLocalStorage(updatedProjects);
    handleCloseDialog();
  };
  
  const handleDeleteProject = (projectId) => {
    const updatedProjects = projects.filter((p) => p.id !== projectId);
    setProjects(updatedProjects);
    saveProjectsToLocalStorage(updatedProjects);
    toast({ title: "Proyek Dihapus", description: "Proyek telah berhasil dihapus." });
  };
  
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <>
      <Helmet>
        <title>Daftar Proyek - Sistem Akuntansi</title>
        <meta name="description" content="Kelola dan lihat semua proyek konstruksi dalam satu halaman." />
      </Helmet>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Daftar Proyek</h1>
            <p className="text-slate-400">Lihat dan kelola semua proyek Anda di sini.</p>
          </div>
          <Button onClick={() => handleOpenDialog()} className="mt-4 md:mt-0 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
            <Plus className="h-4 w-4 mr-2" />
            Tambah Proyek Baru
          </Button>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {projects.map((project) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="glass-effect rounded-xl flex flex-col justify-between h-full"
              >
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-white mb-1">{project.name}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${PROJECT_STATUS[project.status]?.color}`}>
                        {PROJECT_STATUS[project.status]?.label}
                      </span>
                    </div>
                     <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-slate-400 hover:bg-slate-700/50 -mr-2 -mt-2">
                           <MoreVertical className="h-5 w-5" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="bg-slate-800 border-slate-700 text-white">
                        <DropdownMenuItem onSelect={() => handleOpenDialog(project)} className="flex items-center">
                          <Edit className="h-4 w-4 mr-2"/> Edit
                        </DropdownMenuItem>
                         <AlertDialog>
                          <AlertDialogTrigger asChild>
                             <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="flex items-center text-red-400 focus:bg-red-500/10 focus:text-red-400">
                               <Trash2 className="h-4 w-4 mr-2"/> Hapus
                            </DropdownMenuItem>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Anda yakin ingin menghapus?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Tindakan ini akan menghapus proyek "{project.name}" secara permanen.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Batal</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteProject(project.id)} className="bg-red-600 hover:bg-red-700">
                                Hapus
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  <p className="text-slate-400 text-sm leading-relaxed mb-4 h-16 overflow-hidden">{project.description}</p>
                  
                  <div className="text-sm space-y-3">
                     <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-3 text-slate-400" />
                        <span className="text-slate-300">{formatDate(project.startDate)} - {formatDate(project.endDate)}</span>
                     </div>
                  </div>
                </div>

                <div className="px-6 pb-6">
                  <div className="flex justify-between items-center mb-1 text-sm">
                    <span className="text-slate-300">Progress</span>
                    <span className="font-semibold text-white">{project.progress}%</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full ${PROJECT_STATUS[project.status]?.progressColor}`}
                      style={{ width: `${project.progress}%`, transition: 'width 0.5s ease-in-out' }}
                    ></div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>{currentProject ? 'Edit Proyek' : 'Tambah Proyek Baru'}</DialogTitle>
              <DialogDescription>
                {currentProject ? 'Perbarui detail proyek di bawah ini.' : 'Isi detail untuk proyek baru.'}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nama Proyek</Label>
                <Input id="name" value={projectData.name} onChange={(e) => setProjectData({ ...projectData, name: e.target.value })} />
              </div>
               <div className="space-y-2">
                <Label htmlFor="description">Deskripsi</Label>
                <Textarea id="description" value={projectData.description} onChange={(e) => setProjectData({ ...projectData, description: e.target.value })} rows={3} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select value={projectData.status} onValueChange={(value) => setProjectData({ ...projectData, status: value })}>
                    <SelectTrigger><SelectValue placeholder="Pilih Status" /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(PROJECT_STATUS).map(([key, { label }]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="progress">Progress (%)</Label>
                    <Input id="progress" type="number" min="0" max="100" value={projectData.progress} onChange={(e) => setProjectData({ ...projectData, progress: parseInt(e.target.value) || 0 })} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <div className="space-y-2">
                  <Label htmlFor="startDate">Tanggal Mulai</Label>
                  <Input id="startDate" type="date" value={projectData.startDate} onChange={(e) => setProjectData({ ...projectData, startDate: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="endDate">Tanggal Selesai</Label>
                  <Input id="endDate" type="date" value={projectData.endDate} onChange={(e) => setProjectData({ ...projectData, endDate: e.target.value })} />
                </div>
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">Batal</Button>
              </DialogClose>
              <Button onClick={handleSaveProject} className="bg-blue-600 hover:bg-blue-700">Simpan</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default ProjectList;