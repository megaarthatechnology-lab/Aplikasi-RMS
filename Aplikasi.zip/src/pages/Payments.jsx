import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getPayments, savePayments } from '@/lib/payments-api';

import FilterControls from '@/components/payments/FilterControls';
import PaymentsTable from '@/components/payments/PaymentsTable';
import PaymentFormDialog from '@/components/payments/PaymentFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const Payments = () => {
  const [payments, setPayments] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    paymentMethod: 'all',
    status: 'all',
    startDate: '',
    endDate: '',
    minAmount: '',
    maxAmount: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [paymentToDelete, setPaymentToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getPayments();
    setPayments(data);
  };

  const filteredPayments = useMemo(() => {
    return payments.filter(p => {
      const searchTermMatch = p.payerName.toLowerCase().includes(filters.searchTerm.toLowerCase()) || p.payeeName.toLowerCase().includes(filters.searchTerm.toLowerCase()) || p.referenceNumber.toLowerCase().includes(filters.searchTerm.toLowerCase());
      const methodMatch = filters.paymentMethod === 'all' || p.paymentMethod === filters.paymentMethod;
      const statusMatch = filters.status === 'all' || p.status === filters.status;

      const paymentDate = new Date(p.date);
      const startDate = filters.startDate ? new Date(filters.startDate) : null;
      const endDate = filters.endDate ? new Date(filters.endDate) : null;
      if (startDate) startDate.setHours(0, 0, 0, 0);
      if (endDate) endDate.setHours(23, 59, 59, 999);
      const dateRangeMatch = (!startDate || paymentDate >= startDate) && (!endDate || paymentDate <= endDate);
      
      const minAmount = filters.minAmount ? parseFloat(filters.minAmount) : null;
      const maxAmount = filters.maxAmount ? parseFloat(filters.maxAmount) : null;
      const amountMatch = (minAmount === null || p.amount >= minAmount) && (maxAmount === null || p.amount <= maxAmount);

      return searchTermMatch && methodMatch && statusMatch && dateRangeMatch && amountMatch;
    });
  }, [payments, filters]);

  const handleOpenForm = (payment = null) => {
    setSelectedPayment(payment);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedPayment(null);
  };

  const handleSavePayment = (formData) => {
    let updatedPayments;
    const parsedData = {
      ...formData,
      amount: parseFloat(formData.amount),
    };

    if (selectedPayment) {
      updatedPayments = payments.map(p => (p.id === selectedPayment.id ? { ...selectedPayment, ...parsedData } : p));
      toast({ title: "✅ Sukses", description: "Data pembayaran berhasil diperbarui." });
    } else {
      const newPayment = { ...parsedData, id: Date.now() };
      updatedPayments = [...payments, newPayment];
      toast({ title: "✅ Sukses", description: "Pembayaran baru berhasil ditambahkan." });
    }
    savePayments(updatedPayments);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setPaymentToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedPayments = payments.filter(p => p.id !== paymentToDelete);
    savePayments(updatedPayments);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setPaymentToDelete(null);
    toast({
      title: "🗑️ Pembayaran Dihapus",
      description: "Data pembayaran telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Pembayaran - Sistem Akuntansi</title>
        <meta name="description" content="Kelola, tambah, edit, dan lacak semua transaksi pembayaran." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Manajemen Pembayaran</h1>
            <p className="text-muted-foreground">Lacak semua transaksi pembayaran yang masuk dan keluar.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Tambah Pembayaran
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <PaymentsTable
          payments={filteredPayments}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <PaymentFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSavePayment}
        payment={selectedPayment}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data pembayaran secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default Payments;