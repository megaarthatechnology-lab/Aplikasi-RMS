import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const TransaksiBerulang = () => {
  return <PlaceholderPage title="Transaksi Berulang" description="Halaman untuk mengelola transaksi berulang seperti gaji dan cicilan." />;
};

export default TransaksiBerulang;