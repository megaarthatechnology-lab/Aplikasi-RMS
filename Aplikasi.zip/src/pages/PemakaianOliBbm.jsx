import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const PemakaianOliBbm = () => {
  return <PlaceholderPage title="Pemakaian Oli & BBM" description="Halaman untuk mencatat pemakaian oli dan BBM." />;
};

export default PemakaianOliBbm;