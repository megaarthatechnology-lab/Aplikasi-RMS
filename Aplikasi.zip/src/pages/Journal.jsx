import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Filter, Edit, Trash2, Eye, Calendar, X, PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const Journal = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);

  const initialEntries = [
    { id: 'JE-2025-001', date: '2025-11-15', description: 'Penerimaan kas dari penjualan jasa', reference: 'INV-001', amount: 50000000, status: 'Posted' },
    { id: 'JE-2025-002', date: '2025-11-16', description: 'Pembayaran gaji karyawan', reference: 'PAY-001', amount: 25000000, status: 'Posted' },
    { id: 'JE-2025-003', date: '2025-11-17', description: 'Pembelian peralatan kantor', reference: 'PO-001', amount: 15000000, status: 'Draft' },
  ];

  const [journalEntries, setJournalEntries] = useState(initialEntries);
  
  const initialNewEntry = {
    date: new Date().toISOString().slice(0, 10),
    description: '',
    lines: [
      { account: '', debit: '', credit: '' },
      { account: '', debit: '', credit: '' },
    ],
  };
  const [newEntry, setNewEntry] = useState(initialNewEntry);

  const accounts = [
    { code: '1000', name: 'Kas' },
    { code: '1100', name: 'Bank BCA' },
    { code: '1200', name: 'Piutang Usaha' },
    { code: '1300', name: 'Persediaan' },
    { code: '1400', name: 'Peralatan' },
    { code: '2000', name: 'Hutang Usaha' },
    { code: '3000', name: 'Modal Saham' },
    { code: '4000', name: 'Pendapatan Jasa' },
    { code: '5000', name: 'Beban Gaji' },
  ];

  const handleLineChange = (index, field, value) => {
    const updatedLines = [...newEntry.lines];
    updatedLines[index][field] = value;
    // Clear the opposite field
    if (field === 'debit' && value !== '') {
      updatedLines[index]['credit'] = '';
    }
    if (field === 'credit' && value !== '') {
      updatedLines[index]['debit'] = '';
    }
    setNewEntry({ ...newEntry, lines: updatedLines });
  };

  const addLine = () => {
    setNewEntry({
      ...newEntry,
      lines: [...newEntry.lines, { account: '', debit: '', credit: '' }],
    });
  };

  const removeLine = (index) => {
    const updatedLines = newEntry.lines.filter((_, i) => i !== index);
    setNewEntry({ ...newEntry, lines: updatedLines });
  };
  
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount);
  };

  const { totalDebit, totalCredit } = newEntry.lines.reduce(
    (acc, line) => {
      acc.totalDebit += Number(line.debit) || 0;
      acc.totalCredit += Number(line.credit) || 0;
      return acc;
    },
    { totalDebit: 0, totalCredit: 0 }
  );

  const handleSaveJournal = (e) => {
    e.preventDefault();

    if (!newEntry.date || !newEntry.description) {
        toast({ title: "⚠️ Data Tidak Lengkap", description: "Tanggal dan deskripsi harus diisi.", variant: "destructive" });
        return;
    }
    
    if (newEntry.lines.some(line => !line.account || (line.debit === '' && line.credit === ''))) {
        toast({ title: "⚠️ Entri Tidak Lengkap", description: "Setiap baris harus memiliki akun dan nilai debit/kredit.", variant: "destructive" });
        return;
    }
    
    if (totalDebit !== totalCredit || totalDebit === 0) {
        toast({ title: "⚠️ Jurnal Tidak Seimbang", description: "Total debit dan kredit harus sama dan tidak boleh nol.", variant: "destructive" });
        return;
    }

    const nextId = `JE-2025-${String(journalEntries.length + 1).padStart(3, '0')}`;
    const newJournal = {
        id: nextId,
        date: newEntry.date,
        description: newEntry.description,
        reference: `SYS-${nextId}`,
        amount: totalDebit,
        status: 'Draft',
    };

    setJournalEntries([newJournal, ...journalEntries]);
    toast({ title: "✅ Jurnal Berhasil Dibuat", description: `Jurnal ${nextId} telah disimpan sebagai draf.` });
    
    setShowCreateModal(false);
    setNewEntry(initialNewEntry);
  };


  const handleAction = (action, entry = null) => {
    toast({
      title: `📝 ${action}`,
      description: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };
  
  const filteredEntries = journalEntries.filter(entry =>
    entry.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    entry.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    entry.reference.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <Helmet>
        <title>Jurnal - Sistem Akuntansi Profesional</title>
        <meta name="description" content="Kelola jurnal umum perusahaan. Buat, edit, dan lihat semua entri jurnal akuntansi." />
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Jurnal Umum</h1>
            <p className="text-slate-400">Kelola semua entri jurnal akuntansi perusahaan</p>
          </div>
          <Button 
            onClick={() => setShowCreateModal(true)}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 mt-4 md:mt-0"
          >
            <Plus className="h-4 w-4 mr-2" />
            Buat Jurnal
          </Button>
        </motion.div>

        {/* Search and Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass-effect rounded-xl p-6"
        >
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Cari berdasarkan ID, deskripsi, atau referensi..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
            <Button 
              variant="outline" 
              onClick={() => handleAction('Filter Jurnal')}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            <Button 
              variant="outline" 
              onClick={() => handleAction('Filter Tanggal')}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Tanggal
            </Button>
          </div>
        </motion.div>

        {/* Journal Entries Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="glass-effect rounded-xl overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-800/50">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">ID Jurnal</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Tanggal</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Deskripsi</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Referensi</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Jumlah</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Status</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-300">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {filteredEntries.map((entry, index) => (
                  <motion.tr
                    key={entry.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    className="hover:bg-slate-800/30 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <span className="font-mono text-blue-400 font-semibold">{entry.id}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-slate-300">{new Date(entry.date).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-white">{entry.description}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-slate-300 font-mono">{entry.reference}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-white font-semibold">{formatCurrency(entry.amount)}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        entry.status === 'Posted' 
                          ? 'bg-green-500/20 text-green-400' 
                          : 'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {entry.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-center space-x-2">
                        <Button variant="ghost" size="sm" onClick={() => handleAction('Lihat Detail', entry)} className="text-slate-400 hover:text-blue-400 hover:bg-blue-500/10"><Eye className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="sm" onClick={() => handleAction('Edit Jurnal', entry)} className="text-slate-400 hover:text-yellow-400 hover:bg-yellow-500/10"><Edit className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="sm" onClick={() => handleAction('Hapus Jurnal', entry)} className="text-slate-400 hover:text-red-400 hover:bg-red-500/10"><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>

      {/* Create Journal Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowCreateModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 50, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 50, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-slate-800 rounded-2xl p-6 w-full max-w-4xl border border-slate-700 shadow-2xl flex flex-col max-h-[90vh]"
            >
              <div className="flex items-center justify-between mb-6 flex-shrink-0">
                <h2 className="text-2xl font-bold text-white">Buat Jurnal Baru</h2>
                <Button variant="ghost" size="sm" onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white"><X className="h-5 w-5" /></Button>
              </div>

              <form onSubmit={handleSaveJournal} className="flex-1 overflow-y-auto pr-2 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Tanggal</label>
                    <input type="date" value={newEntry.date} onChange={(e) => setNewEntry({ ...newEntry, date: e.target.value })} className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-green-500" required />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-300 mb-2">Deskripsi</label>
                    <input type="text" value={newEntry.description} onChange={(e) => setNewEntry({ ...newEntry, description: e.target.value })} placeholder="Contoh: Pembelian inventaris kantor" className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-green-500" required />
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="grid grid-cols-12 gap-x-4 px-2 py-2 text-sm font-semibold text-slate-400">
                    <div className="col-span-5">Akun</div>
                    <div className="col-span-3 text-right">Debit</div>
                    <div className="col-span-3 text-right">Kredit</div>
                    <div className="col-span-1"></div>
                  </div>
                  {newEntry.lines.map((line, index) => (
                    <div key={index} className="grid grid-cols-12 gap-x-4 items-center">
                      <div className="col-span-5">
                        <select value={line.account} onChange={(e) => handleLineChange(index, 'account', e.target.value)} className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-1 focus:ring-green-500">
                          <option value="">Pilih Akun...</option>
                          {accounts.map(acc => <option key={acc.code} value={acc.code}>{acc.code} - {acc.name}</option>)}
                        </select>
                      </div>
                      <div className="col-span-3">
                        <input type="number" placeholder="0" value={line.debit} onChange={(e) => handleLineChange(index, 'debit', e.target.value)} className="w-full text-right px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-green-500" />
                      </div>
                      <div className="col-span-3">
                        <input type="number" placeholder="0" value={line.credit} onChange={(e) => handleLineChange(index, 'credit', e.target.value)} className="w-full text-right px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-green-500" />
                      </div>
                      <div className="col-span-1 flex justify-center">
                        {newEntry.lines.length > 2 && (
                          <Button type="button" variant="ghost" size="sm" onClick={() => removeLine(index)} className="text-slate-500 hover:text-red-400"><Trash2 className="h-4 w-4" /></Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                
                <Button type="button" variant="outline" size="sm" onClick={addLine} className="border-slate-600 text-slate-300 hover:bg-slate-700"><PlusCircle className="h-4 w-4 mr-2" />Tambah Baris</Button>

              </form>
              
              <div className="mt-6 pt-4 border-t border-slate-700 flex-shrink-0">
                  <div className="flex justify-between items-center mb-4">
                      <div className="font-semibold text-white text-lg">Total</div>
                      <div className={`font-mono text-lg ${totalDebit !== totalCredit ? 'text-red-400' : 'text-green-400'}`}>
                          <div className="grid grid-cols-2 gap-x-6 text-right">
                            <span>{formatCurrency(totalDebit)}</span>
                            <span>{formatCurrency(totalCredit)}</span>
                          </div>
                      </div>
                  </div>
                  <div className="flex space-x-3">
                      <Button type="button" variant="outline" onClick={() => setShowCreateModal(false)} className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700">Batal</Button>
                      <Button type="submit" onClick={handleSaveJournal} className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700">Simpan Jurnal</Button>
                  </div>
              </div>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Journal;