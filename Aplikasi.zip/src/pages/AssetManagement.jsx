import React from 'react';
import PlaceholderPage from '@/components/shared/PlaceholderPage';

const AssetManagement = () => {
  return <PlaceholderPage title="Manajemen Aset" />;
};

export default AssetManagement;