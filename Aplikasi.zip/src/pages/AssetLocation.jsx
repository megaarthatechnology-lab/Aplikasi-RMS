import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getAssetLocations, saveAssetLocations } from '@/lib/asset-location-api';

import FilterControls from '@/components/asset-location/FilterControls';
import AssetLocationTable from '@/components/asset-location/AssetLocationTable';
import AssetLocationFormDialog from '@/components/asset-location/AssetLocationFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const AssetLocation = () => {
  const [locations, setLocations] = useState([]);
  const [filters, setFilters] = useState({
    assetName: '',
    assetCode: '',
    currentLocation: '',
    building: '',
    responsiblePerson: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [locationToDelete, setLocationToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getAssetLocations();
    setLocations(data);
  };
  
  const uniqueFilterData = useMemo(() => {
      const allLocations = getAssetLocations();
      const currentLocations = [...new Set(allLocations.map(l => l.currentLocation))];
      const buildings = [...new Set(allLocations.map(l => l.buildingFloor))];
      const responsiblePersons = [...new Set(allLocations.map(l => l.responsiblePerson))];
      return { currentLocations, buildings, responsiblePersons };
  }, []);

  const filteredLocations = useMemo(() => {
    return locations.filter(loc => {
      const nameMatch = !filters.assetName || loc.assetName.toLowerCase().includes(filters.assetName.toLowerCase());
      const codeMatch = !filters.assetCode || loc.assetCode.toLowerCase().includes(filters.assetCode.toLowerCase());
      const locationMatch = !filters.currentLocation || loc.currentLocation === filters.currentLocation;
      const buildingMatch = !filters.building || loc.buildingFloor === filters.building;
      const personMatch = !filters.responsiblePerson || loc.responsiblePerson === filters.responsiblePerson;
      return nameMatch && codeMatch && locationMatch && buildingMatch && personMatch;
    });
  }, [locations, filters]);

  const handleOpenForm = (location = null) => {
    setSelectedLocation(location);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedLocation(null);
  };

  const handleSaveLocation = (formData) => {
    let updatedLocations;
    if (selectedLocation) {
      updatedLocations = locations.map(loc => (loc.id === selectedLocation.id ? { ...selectedLocation, ...formData } : loc));
      toast({ title: "✅ Sukses", description: "Data lokasi aset berhasil diperbarui." });
    } else {
      const newLocation = { ...formData, id: Date.now() };
      updatedLocations = [...locations, newLocation];
      toast({ title: "✅ Sukses", description: "Lokasi aset baru berhasil ditambahkan." });
    }
    saveAssetLocations(updatedLocations);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setLocationToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedLocations = locations.filter(loc => loc.id !== locationToDelete);
    saveAssetLocations(updatedLocations);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setLocationToDelete(null);
    toast({
      title: "🗑️ Lokasi Dihapus",
      description: "Data lokasi aset telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Lokasi Aset - Sistem Akuntansi</title>
        <meta name="description" content="Lacak dan kelola lokasi semua aset perusahaan secara real-time." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Manajemen Lokasi Aset</h1>
            <p className="text-muted-foreground">Pantau lokasi terkini semua aset perusahaan Anda.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Catat Lokasi Baru
          </Button>
        </div>

        <FilterControls 
            filters={filters} 
            setFilters={setFilters} 
            uniqueFilterData={uniqueFilterData}
        />

        <AssetLocationTable
          locations={filteredLocations}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <AssetLocationFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveLocation}
        location={selectedLocation}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data lokasi aset secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default AssetLocation;