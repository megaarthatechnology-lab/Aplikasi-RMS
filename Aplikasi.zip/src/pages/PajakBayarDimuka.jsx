import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const PajakBayarDimuka = () => {
  return <PlaceholderPage title="Pajak Bayar Dimuka" description="Halaman untuk mengelola pajak bayar dimuka." />;
};

export default PajakBayarDimuka;