import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Edit, Trash2, MoreHorizontal, Search, User, Briefcase, Building2, DollarSign, Activity, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatCurrency } from '@/lib/utils';

const EMPLOYMENT_STATUS = {
  Active: { label: 'Aktif', color: 'bg-green-500/20 text-green-400' },
  OnLeave: { label: 'Cuti', color: 'bg-yellow-500/20 text-yellow-400' },
  Terminated: { label: 'Diberhentikan', color: 'bg-red-500/20 text-red-400' },
};

const defaultEmployees = [
  {
    id: 'EMP-001',
    name: 'Budi Santoso',
    position: 'Manajer Proyek',
    department: 'Teknik Sipil',
    salary: 15000000,
    status: 'Active',
  },
  {
    id: 'EMP-002',
    name: 'Citra Lestari',
    position: 'Arsitek',
    department: 'Desain',
    salary: 12000000,
    status: 'Active',
  },
  {
    id: 'EMP-003',
    name: 'Agus Wijaya',
    position: 'Mandor Lapangan',
    department: 'Konstruksi',
    salary: 8000000,
    status: 'OnLeave',
  },
  {
    id: 'EMP-004',
    name: 'Dewi Anggraini',
    position: 'Admin Proyek',
    department: 'Administrasi',
    salary: 6000000,
    status: 'Active',
  },
   {
    id: 'EMP-005',
    name: 'Eko Prasetyo',
    position: 'Pekerja Konstruksi',
    department: 'Konstruksi',
    salary: 4500000,
    status: 'Terminated',
  },
];

const EmployeeList = () => {
  const { toast } = useToast();
  const [employees, setEmployees] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState(null);
  const [employeeData, setEmployeeData] = useState({ id: '', name: '', position: '', department: '', salary: '', status: 'Active' });
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  useEffect(() => {
    try {
      const savedEmployees = localStorage.getItem('employeeList');
      if (savedEmployees) {
        setEmployees(JSON.parse(savedEmployees));
      } else {
        setEmployees(defaultEmployees);
        localStorage.setItem('employeeList', JSON.stringify(defaultEmployees));
      }
    } catch (error) {
      console.error("Gagal memuat data karyawan dari localStorage:", error);
      setEmployees(defaultEmployees);
    }
  }, []);
  
  const saveEmployeesToLocalStorage = (updatedEmployees) => {
    try {
      localStorage.setItem('employeeList', JSON.stringify(updatedEmployees));
    } catch (error) {
      console.error("Gagal menyimpan data karyawan ke localStorage:", error);
      toast({
        variant: "destructive",
        title: "Gagal Menyimpan Data",
        description: "Tidak dapat menyimpan perubahan ke penyimpanan lokal.",
      });
    }
  };

  const handleOpenDialog = (employee = null) => {
    setCurrentEmployee(employee);
    if (employee) {
      setEmployeeData(employee);
    } else {
      const newId = `EMP-${String(Date.now()).slice(-4)}`;
      setEmployeeData({ id: newId, name: '', position: '', department: '', salary: '', status: 'Active' });
    }
    setIsDialogOpen(true);
  };
  
  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setCurrentEmployee(null);
  };

  const handleSaveEmployee = () => {
    if (!employeeData.name || !employeeData.position || !employeeData.department || !employeeData.salary) {
      toast({
        variant: "destructive",
        title: "Gagal Menyimpan",
        description: "Semua field harus diisi.",
      });
      return;
    }

    let updatedEmployees;
    if (currentEmployee) {
      updatedEmployees = employees.map((e) =>
        e.id === currentEmployee.id ? { ...employeeData } : e
      );
      toast({ title: "Data Diperbarui", description: `Data karyawan "${employeeData.name}" berhasil diperbarui.` });
    } else {
      updatedEmployees = [...employees, employeeData];
      toast({ title: "Karyawan Ditambahkan", description: `Karyawan baru "${employeeData.name}" berhasil ditambahkan.` });
    }
    setEmployees(updatedEmployees);
    saveEmployeesToLocalStorage(updatedEmployees);
    handleCloseDialog();
  };

  const handleDeleteEmployee = (employeeId) => {
    const updatedEmployees = employees.filter((e) => e.id !== employeeId);
    setEmployees(updatedEmployees);
    saveEmployeesToLocalStorage(updatedEmployees);
    toast({ title: "Karyawan Dihapus", description: "Data karyawan telah berhasil dihapus." });
  };

  const filteredEmployees = useMemo(() => {
    return employees.filter(employee => {
      const matchesSearch = employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            employee.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            employee.position.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = statusFilter === 'All' || employee.status === statusFilter;
      return matchesSearch && matchesFilter;
    });
  }, [employees, searchTerm, statusFilter]);

  return (
    <>
      <Helmet>
        <title>Daftar Pegawai - Sistem Akuntansi</title>
        <meta name="description" content="Kelola data pegawai proyek Anda, termasuk informasi personal, posisi, dan gaji." />
      </Helmet>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Daftar Pegawai</h1>
            <p className="text-slate-400">Kelola semua data pegawai proyek Anda di sini.</p>
          </div>
          <Button onClick={() => handleOpenDialog()} className="mt-4 md:mt-0 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
            <Plus className="h-4 w-4 mr-2" />
            Tambah Karyawan
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass-effect p-4 rounded-xl flex flex-col md:flex-row gap-4"
        >
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 h-5 w-5" />
            <Input 
              placeholder="Cari berdasarkan nama, ID, atau posisi..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-slate-400" />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Filter Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">Semua Status</SelectItem>
                {Object.entries(EMPLOYMENT_STATUS).map(([key, { label }]) => (
                  <SelectItem key={key} value={key}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="glass-effect rounded-xl overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="border-b-slate-700 hover:bg-slate-800/60">
                  <TableHead><User className="inline-block h-4 w-4 mr-1" /> Nama</TableHead>
                  <TableHead>ID Karyawan</TableHead>
                  <TableHead><Briefcase className="inline-block h-4 w-4 mr-1" /> Posisi</TableHead>
                  <TableHead><DollarSign className="inline-block h-4 w-4 mr-1" /> Gaji</TableHead>
                  <TableHead><Activity className="inline-block h-4 w-4 mr-1" /> Status</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <AnimatePresence>
                  {filteredEmployees.length > 0 ? filteredEmployees.map((employee) => (
                    <motion.tr
                      key={employee.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="border-b-slate-800"
                    >
                      <TableCell className="font-medium">{employee.name}</TableCell>
                      <TableCell className="text-slate-400">{employee.id}</TableCell>
                      <TableCell>{employee.position}</TableCell>
                      <TableCell className="text-green-400">{formatCurrency(employee.salary)}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${EMPLOYMENT_STATUS[employee.status]?.color}`}>
                          {EMPLOYMENT_STATUS[employee.status]?.label}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:bg-slate-700/50">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700 text-white">
                            <DropdownMenuItem onSelect={() => handleOpenDialog(employee)} className="flex items-center">
                              <Edit className="h-4 w-4 mr-2" /> Edit
                            </DropdownMenuItem>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="flex items-center text-red-400 focus:bg-red-500/10 focus:text-red-400">
                                  <Trash2 className="h-4 w-4 mr-2" /> Hapus
                                </DropdownMenuItem>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Anda yakin ingin menghapus?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tindakan ini akan menghapus data karyawan "{employee.name}" secara permanen.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Batal</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDeleteEmployee(employee.id)} className="bg-red-600 hover:bg-red-700">
                                    Hapus
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </motion.tr>
                  )) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center h-24 text-slate-400">
                        Tidak ada data karyawan yang cocok dengan kriteria Anda.
                      </TableCell>
                    </TableRow>
                  )}
                </AnimatePresence>
              </TableBody>
            </Table>
          </div>
        </motion.div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>{currentEmployee ? 'Edit Data Karyawan' : 'Tambah Karyawan Baru'}</DialogTitle>
              <DialogDescription>
                {currentEmployee ? 'Perbarui detail karyawan di bawah ini.' : 'Isi detail untuk karyawan baru.'}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="id">ID Karyawan</Label>
                <Input id="id" value={employeeData.id} readOnly disabled />
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">Nama Lengkap</Label>
                <Input id="name" value={employeeData.name} onChange={(e) => setEmployeeData({ ...employeeData, name: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="position">Posisi</Label>
                  <Input id="position" value={employeeData.position} onChange={(e) => setEmployeeData({ ...employeeData, position: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="department">Departemen</Label>
                  <Input id="department" value={employeeData.department} onChange={(e) => setEmployeeData({ ...employeeData, department: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="salary">Gaji (IDR)</Label>
                  <Input id="salary" type="number" value={employeeData.salary} onChange={(e) => setEmployeeData({ ...employeeData, salary: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Status Kepegawaian</Label>
                  <Select value={employeeData.status} onValueChange={(value) => setEmployeeData({ ...employeeData, status: value })}>
                    <SelectTrigger><SelectValue placeholder="Pilih Status" /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(EMPLOYMENT_STATUS).map(([key, { label }]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild><Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">Batal</Button></DialogClose>
              <Button onClick={handleSaveEmployee} className="bg-blue-600 hover:bg-blue-700">Simpan</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default EmployeeList;