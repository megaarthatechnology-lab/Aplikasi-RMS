import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getAssets, saveAssets } from '@/lib/asset-list-api';

import FilterControls from '@/components/asset-list/FilterControls';
import AssetListTable from '@/components/asset-list/AssetListTable';
import AssetFormDialog from '@/components/asset-list/AssetFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const AssetList = () => {
  const [assets, setAssets] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    assetCode: '',
    category: '',
    conditionStatus: '',
    startDate: '',
    endDate: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState(null);
  const [assetToDelete, setAssetToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getAssets();
    setAssets(data);
  };

  const filteredAssets = useMemo(() => {
    return assets.filter(asset => {
      const searchTermMatch = asset.assetName.toLowerCase().includes(filters.searchTerm.toLowerCase());
      const assetCodeMatch = !filters.assetCode || asset.assetCode.toLowerCase().includes(filters.assetCode.toLowerCase());
      const categoryMatch = !filters.category || asset.category === filters.category;
      const conditionMatch = !filters.conditionStatus || asset.conditionStatus === filters.conditionStatus;

      const purchaseDate = new Date(asset.purchaseDate);
      const startDate = filters.startDate ? new Date(filters.startDate) : null;
      const endDate = filters.endDate ? new Date(filters.endDate) : null;
      if (startDate) startDate.setHours(0, 0, 0, 0);
      if (endDate) endDate.setHours(23, 59, 59, 999);
      const dateRangeMatch = (!startDate || purchaseDate >= startDate) && (!endDate || purchaseDate <= endDate);

      return searchTermMatch && assetCodeMatch && categoryMatch && conditionMatch && dateRangeMatch;
    });
  }, [assets, filters]);

  const handleOpenForm = (asset = null) => {
    setSelectedAsset(asset);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedAsset(null);
  };

  const handleSaveAsset = (formData) => {
    let updatedAssets;
    const parsedData = {
      ...formData,
      purchasePrice: parseFloat(formData.purchasePrice),
      currentValue: parseFloat(formData.currentValue),
    };

    if (selectedAsset) {
      updatedAssets = assets.map(a => (a.id === selectedAsset.id ? { ...selectedAsset, ...parsedData } : a));
      toast({ title: "✅ Sukses", description: "Data aset berhasil diperbarui." });
    } else {
      const newAsset = { ...parsedData, id: Date.now() };
      updatedAssets = [...assets, newAsset];
      toast({ title: "✅ Sukses", description: "Aset baru berhasil ditambahkan." });
    }
    saveAssets(updatedAssets);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setAssetToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedAssets = assets.filter(a => a.id !== assetToDelete);
    saveAssets(updatedAssets);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setAssetToDelete(null);
    toast({
      title: "🗑️ Aset Dihapus",
      description: "Data aset telah berhasil dihapus dari sistem.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Daftar Aset - Sistem Akuntansi</title>
        <meta name="description" content="Kelola dan lacak semua aset perusahaan dengan detail lengkap termasuk nilai, kondisi, dan lokasi." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Daftar Aset Perusahaan</h1>
            <p className="text-muted-foreground">Kelola dan pantau semua aset perusahaan secara terpusat.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Tambah Aset
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <AssetListTable
          assets={filteredAssets}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <AssetFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveAsset}
        asset={selectedAsset}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data aset secara permanen dari sistem. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default AssetList;