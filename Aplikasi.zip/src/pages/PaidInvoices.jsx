import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Printer } from 'lucide-react';
import { useReactToPrint } from 'react-to-print';
import { getInvoices } from '@/lib/invoice-api';

import FilterControls from '@/components/paid-invoices/FilterControls';
import PaidInvoicesTable from '@/components/paid-invoices/PaidInvoicesTable';
import { formatCurrency } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

const PaidInvoices = () => {
  const [paidInvoices, setPaidInvoices] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    startDate: '',
    endDate: '',
  });

  const componentToPrintRef = useRef();

  useEffect(() => {
    // Fetch all invoices and filter for paid ones
    const allInvoices = getInvoices();
    const paid = allInvoices
      .filter(i => i.status === 'paid')
      .map(i => ({ // Ensure payment details exist
        ...i,
        paymentDate: i.paymentDate || i.dueDate, // Fallback to due date if no payment date
        paymentMethod: i.paymentMethod || 'N/A'
      }));
    setPaidInvoices(paid);
  }, []);

  const filteredInvoices = useMemo(() => {
    return paidInvoices.filter(invoice => {
      const searchTermMatch = invoice.customerName.toLowerCase().includes(filters.searchTerm.toLowerCase()) || invoice.invoiceNumber.toLowerCase().includes(filters.searchTerm.toLowerCase());
      
      const paymentDate = new Date(invoice.paymentDate);
      const startDate = filters.startDate ? new Date(filters.startDate) : null;
      const endDate = filters.endDate ? new Date(filters.endDate) : null;
      
      if(startDate) startDate.setHours(0, 0, 0, 0);
      if(endDate) endDate.setHours(23, 59, 59, 999);

      const dateRangeMatch = (!startDate || paymentDate >= startDate) && (!endDate || paymentDate <= endDate);

      return searchTermMatch && dateRangeMatch;
    });
  }, [paidInvoices, filters]);

  const totalPaidAmount = useMemo(() => {
    return filteredInvoices.reduce((sum, invoice) => sum + invoice.amount, 0);
  }, [filteredInvoices]);

  const handlePrint = useReactToPrint({
    content: () => componentToPrintRef.current,
    documentTitle: "Laporan-Invoice-Lunas",
    bodyClass: "bg-white text-black"
  });

  return (
    <>
      <Helmet>
        <title>Invoice Lunas - Sistem Akuntansi</title>
        <meta name="description" content="Lihat, filter, dan buat laporan untuk semua invoice yang sudah lunas." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Daftar Invoice Lunas</h1>
            <p className="text-muted-foreground">Tinjau semua invoice yang telah dibayar oleh pelanggan.</p>
          </div>
          <Button onClick={handlePrint} className="bg-blue-600 hover:bg-blue-700">
            <Printer className="mr-2 h-4 w-4" /> Cetak Laporan
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <Card className="glass-effect print-hidden">
            <CardHeader>
                <CardTitle>Total Pemasukan dari Invoice Lunas</CardTitle>
                <CardDescription>Total dari {filteredInvoices.length} invoice yang cocok dengan filter.</CardDescription>
            </CardHeader>
            <CardContent>
                <p className="text-3xl font-bold text-green-400">{formatCurrency(totalPaidAmount)}</p>
            </CardContent>
        </Card>

        <div ref={componentToPrintRef} className="print-container">
            <div className="print-header hidden print:block text-black p-4 mb-4 border-b-2 border-black">
                <h2 className="text-2xl font-bold">Laporan Invoice Lunas</h2>
                <p>Periode: {filters.startDate ? new Date(filters.startDate).toLocaleDateString('id-ID') : 'Semua'} - {filters.endDate ? new Date(filters.endDate).toLocaleDateString('id-ID') : 'Semua'}</p>
                <p>Total Pemasukan: <span className="font-bold">{formatCurrency(totalPaidAmount)}</span></p>
                <p>Total Invoice: <span className="font-bold">{filteredInvoices.length}</span></p>
                <p>Dicetak pada: {new Date().toLocaleDateString('id-ID', { dateStyle: 'full' })}</p>
            </div>
            <PaidInvoicesTable invoices={filteredInvoices} />
        </div>

      </motion.div>
    </>
  );
};

export default PaidInvoices;