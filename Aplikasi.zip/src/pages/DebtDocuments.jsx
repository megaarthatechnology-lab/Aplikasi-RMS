import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getDocuments, saveDocuments } from '@/lib/debt-documents-api';
import { getDebts } from '@/lib/debt-api';

import DocumentFilterControls from '@/components/debt-documents/DocumentFilterControls';
import DocumentTable from '@/components/debt-documents/DocumentTable';
import DocumentUploadDialog from '@/components/debt-documents/DocumentUploadDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const DebtDocuments = () => {
  const [documents, setDocuments] = useState([]);
  const [debts, setDebts] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    fileType: 'all',
    debtRef: 'all',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [documentToDelete, setDocumentToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
    setDebts(getDebts());
  }, []);

  const reloadData = () => {
    const data = getDocuments();
    setDocuments(data);
  };

  const filteredDocuments = useMemo(() => {
    return documents
      .map(doc => {
        const debt = debts.find(d => d.id.toString() === doc.debtId);
        return {
          ...doc,
          debtCreditor: debt ? debt.creditor : 'Tidak Terhubung',
        };
      })
      .filter(doc => {
        const searchTermMatch = doc.name.toLowerCase().includes(filters.searchTerm.toLowerCase()) || 
                                doc.debtCreditor.toLowerCase().includes(filters.searchTerm.toLowerCase());
        const fileTypeMatch = filters.fileType === 'all' || doc.type.startsWith(filters.fileType);
        const debtRefMatch = filters.debtRef === 'all' || doc.debtId === filters.debtRef;

        return searchTermMatch && fileTypeMatch && debtRefMatch;
      });
  }, [documents, debts, filters]);

  const handleOpenForm = (doc = null) => {
    setSelectedDocument(doc);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedDocument(null);
  };

  const handleSaveDocument = (formData) => {
    let updatedDocuments;
    if (selectedDocument) {
      // Editing description of an existing document
      updatedDocuments = documents.map(d =>
        d.id === selectedDocument.id ? { ...d, description: formData.description, debtId: formData.debtId } : d
      );
      toast({ title: "✅ Sukses", description: "Deskripsi dokumen berhasil diperbarui." });
    } else {
      // Adding a new document
      const newDocument = {
        ...formData,
        id: Date.now(),
        uploadDate: new Date().toISOString(),
      };
      updatedDocuments = [...documents, newDocument];
      toast({ title: "✅ Sukses", description: `Dokumen "${formData.name}" berhasil diunggah.` });
    }
    saveDocuments(updatedDocuments);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setDocumentToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedDocuments = documents.filter(d => d.id !== documentToDelete);
    saveDocuments(updatedDocuments);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setDocumentToDelete(null);
    toast({
      title: "🗑️ Dokumen Dihapus",
      description: "Dokumen telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Dokumen Hutang - Sistem Akuntansi</title>
        <meta name="description" content="Unggah, kelola, dan lacak semua dokumen terkait hutang perusahaan." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Dokumen Hutang</h1>
            <p className="text-muted-foreground">Kelola semua file dan dokumen yang terkait dengan hutang Anda.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Unggah Dokumen
          </Button>
        </div>

        <DocumentFilterControls filters={filters} setFilters={setFilters} debts={debts} />

        <DocumentTable
          documents={filteredDocuments}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <DocumentUploadDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveDocument}
        document={selectedDocument}
        debts={debts}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data dokumen secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default DebtDocuments;