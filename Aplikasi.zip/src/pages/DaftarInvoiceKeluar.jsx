import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const DaftarInvoiceKeluar = () => {
  return <PlaceholderPage title="Daftar Invoice Dikeluarkan" description="Halaman untuk daftar invoice yang telah dikeluarkan." />;
};

export default DaftarInvoiceKeluar;