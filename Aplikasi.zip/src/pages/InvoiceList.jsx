import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getInvoices, saveInvoices } from '@/lib/invoice-api';

import FilterControls from '@/components/invoices/FilterControls';
import InvoiceTable from '@/components/invoices/InvoiceTable';
import InvoiceFormDialog from '@/components/invoices/InvoiceFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const InvoiceList = () => {
  const [invoices, setInvoices] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    status: 'all',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [invoiceToDelete, setInvoiceToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getInvoices();
    setInvoices(data);
  };

  const filteredInvoices = useMemo(() => {
    return invoices.filter(invoice => {
      const searchTermMatch = invoice.customerName.toLowerCase().includes(filters.searchTerm.toLowerCase()) || invoice.invoiceNumber.toLowerCase().includes(filters.searchTerm.toLowerCase());
      const statusMatch = filters.status === 'all' || invoice.status === filters.status;
      return searchTermMatch && statusMatch;
    });
  }, [invoices, filters]);

  const handleOpenForm = (invoice = null) => {
    setSelectedInvoice(invoice);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedInvoice(null);
  };

  const handleSaveInvoice = (formData) => {
    let updatedInvoices;
    const totalAmount = formData.items.reduce((sum, item) => sum + item.quantity * item.price, 0);
    const finalData = { ...formData, amount: totalAmount };

    if (selectedInvoice) {
      updatedInvoices = invoices.map(i => (i.id === selectedInvoice.id ? { ...selectedInvoice, ...finalData } : i));
      toast({ title: "✅ Sukses", description: "Invoice berhasil diperbarui." });
    } else {
      const newInvoice = { ...finalData, id: Date.now() };
      updatedInvoices = [...invoices, newInvoice];
      toast({ title: "✅ Sukses", description: "Invoice baru berhasil dibuat." });
    }
    saveInvoices(updatedInvoices);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setInvoiceToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedInvoices = invoices.filter(i => i.id !== invoiceToDelete);
    saveInvoices(updatedInvoices);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setInvoiceToDelete(null);
    toast({
      title: "🗑️ Invoice Dihapus",
      description: "Invoice telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Daftar Invoice - Sistem Akuntansi</title>
        <meta name="description" content="Kelola, buat, edit, dan lacak semua invoice pelanggan." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Daftar Invoice</h1>
            <p className="text-muted-foreground">Buat dan kelola semua invoice untuk pelanggan Anda.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Buat Invoice Baru
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <InvoiceTable
          invoices={filteredInvoices}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <InvoiceFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveInvoice}
        invoice={selectedInvoice}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus invoice secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default InvoiceList;