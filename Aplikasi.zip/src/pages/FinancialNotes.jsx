import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Edit, Trash2, FileText, Book, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const NOTE_CATEGORIES = {
  accountingPolicies: {
    label: 'Kebijakan Akuntansi',
    icon: <Book className="h-5 w-5" />,
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/10',
  },
  significantEstimates: {
    label: 'Estimasi Akuntansi Signifikan',
    icon: <AlertTriangle className="h-5 w-5" />,
    color: 'text-yellow-400',
    bgColor: 'bg-yellow-500/10',
  },
  otherDisclosures: {
    label: 'Pengungkapan Lainnya',
    icon: <FileText className="h-5 w-5" />,
    color: 'text-purple-400',
    bgColor: 'bg-purple-500/10',
  },
};

const defaultNotes = [
  {
    id: '1',
    title: 'Dasar Penyusunan Laporan Keuangan',
    category: 'accountingPolicies',
    content:
      'Laporan keuangan disusun berdasarkan Standar Akuntansi Keuangan (SAK) di Indonesia. Laporan keuangan telah disusun berdasarkan basis akrual, kecuali untuk laporan arus kas.',
  },
  {
    id: '2',
    title: 'Penyusutan Aset Tetap',
    category: 'accountingPolicies',
    content:
      'Aset tetap disusutkan menggunakan metode garis lurus selama umur manfaat ekonomisnya. Estimasi umur manfaat ditinjau secara berkala.',
  },
  {
    id: '3',
    title: 'Estimasi Piutang Tak Tertagih',
    category: 'significantEstimates',
    content:
      'Perusahaan mengestimasi cadangan kerugian piutang berdasarkan analisis umur piutang dan kondisi ekonomi saat ini. Estimasi ini melibatkan judgement signifikan dari manajemen.',
  },
];

const FinancialNotes = () => {
  const { toast } = useToast();
  const [notes, setNotes] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentNote, setCurrentNote] = useState(null);
  const [noteData, setNoteData] = useState({ title: '', content: '', category: '' });

  useEffect(() => {
    try {
      const savedNotes = localStorage.getItem('financialNotes');
      if (savedNotes) {
        setNotes(JSON.parse(savedNotes));
      } else {
        setNotes(defaultNotes);
        localStorage.setItem('financialNotes', JSON.stringify(defaultNotes));
      }
    } catch (error) {
      console.error("Failed to load notes from localStorage:", error);
      setNotes(defaultNotes);
    }
  }, []);

  const saveNotesToLocalStorage = (updatedNotes) => {
    try {
      localStorage.setItem('financialNotes', JSON.stringify(updatedNotes));
    } catch (error) {
      console.error("Failed to save notes to localStorage:", error);
      toast({
        variant: "destructive",
        title: "Gagal Menyimpan Catatan",
        description: "Tidak dapat menyimpan perubahan ke penyimpanan lokal.",
      });
    }
  };

  const handleOpenDialog = (note = null) => {
    setCurrentNote(note);
    if (note) {
      setNoteData({ title: note.title, content: note.content, category: note.category });
    } else {
      setNoteData({ title: '', content: '', category: Object.keys(NOTE_CATEGORIES)[0] });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setCurrentNote(null);
    setNoteData({ title: '', content: '', category: '' });
  };

  const handleSaveNote = () => {
    if (!noteData.title || !noteData.content || !noteData.category) {
      toast({
        variant: "destructive",
        title: "Gagal Menyimpan",
        description: "Judul, isi, dan kategori tidak boleh kosong.",
      });
      return;
    }

    let updatedNotes;
    if (currentNote) {
      // Edit existing note
      updatedNotes = notes.map((note) =>
        note.id === currentNote.id ? { ...note, ...noteData } : note
      );
      toast({
        title: "Catatan Diperbarui",
        description: `Catatan "${noteData.title}" berhasil diperbarui.`,
      });
    } else {
      // Add new note
      const newNote = {
        id: Date.now().toString(),
        ...noteData,
      };
      updatedNotes = [...notes, newNote];
      toast({
        title: "Catatan Ditambahkan",
        description: `Catatan baru "${noteData.title}" berhasil ditambahkan.`,
      });
    }
    setNotes(updatedNotes);
    saveNotesToLocalStorage(updatedNotes);
    handleCloseDialog();
  };
  
  const handleDeleteNote = (noteId) => {
    const updatedNotes = notes.filter((note) => note.id !== noteId);
    setNotes(updatedNotes);
    saveNotesToLocalStorage(updatedNotes);
    toast({
      title: "Catatan Dihapus",
      description: "Catatan telah berhasil dihapus.",
    });
  };

  const groupedNotes = notes.reduce((acc, note) => {
    (acc[note.category] = acc[note.category] || []).push(note);
    return acc;
  }, {});

  return (
    <>
      <Helmet>
        <title>Catatan Atas Laporan Keuangan - Sistem Akuntansi</title>
        <meta name="description" content="Kelola dan lihat catatan atas laporan keuangan perusahaan." />
      </Helmet>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Catatan Atas Laporan Keuangan</h1>
            <p className="text-slate-400">Penjelasan dan detail tambahan untuk laporan keuangan.</p>
          </div>
          <Button onClick={() => handleOpenDialog()} className="mt-4 md:mt-0 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
            <Plus className="h-4 w-4 mr-2" />
            Tambah Catatan Baru
          </Button>
        </motion.div>

        <AnimatePresence>
          {Object.keys(NOTE_CATEGORIES).map((categoryKey) => (
            groupedNotes[categoryKey] && groupedNotes[categoryKey].length > 0 && (
              <motion.div
                key={categoryKey}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="space-y-4"
              >
                <div className={`flex items-center p-3 rounded-lg ${NOTE_CATEGORIES[categoryKey].bgColor}`}>
                  <span className={NOTE_CATEGORIES[categoryKey].color}>{NOTE_CATEGORIES[categoryKey].icon}</span>
                  <h2 className={`text-xl font-semibold ml-3 ${NOTE_CATEGORIES[categoryKey].color}`}>
                    {NOTE_CATEGORIES[categoryKey].label}
                  </h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {groupedNotes[categoryKey].map((note) => (
                    <motion.div
                      key={note.id}
                      layout
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.3 }}
                      className="glass-effect rounded-xl p-6 flex flex-col justify-between h-full"
                    >
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-2">{note.title}</h3>
                        <p className="text-slate-400 text-sm leading-relaxed whitespace-pre-wrap">{note.content}</p>
                      </div>
                      <div className="flex justify-end space-x-2 mt-6">
                        <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(note)} className="text-slate-400 hover:text-blue-400 hover:bg-blue-500/10">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-slate-400 hover:text-red-400 hover:bg-red-500/10">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Anda yakin ingin menghapus?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Tindakan ini tidak dapat dibatalkan. Catatan "{note.title}" akan dihapus secara permanen.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Batal</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteNote(note.id)} className="bg-red-600 hover:bg-red-700">
                                Hapus
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )
          ))}
        </AnimatePresence>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>{currentNote ? 'Edit Catatan' : 'Tambah Catatan Baru'}</DialogTitle>
              <DialogDescription>
                {currentNote ? 'Perbarui detail catatan di bawah ini.' : 'Isi detail untuk catatan baru.'}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="title" className="text-right">Judul</Label>
                <Input id="title" value={noteData.title} onChange={(e) => setNoteData({ ...noteData, title: e.target.value })} className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="category" className="text-right">Kategori</Label>
                <Select value={noteData.category} onValueChange={(value) => setNoteData({ ...noteData, category: value })}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Pilih Kategori" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(NOTE_CATEGORIES).map(([key, { label }]) => (
                      <SelectItem key={key} value={key}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="content" className="text-right">Isi</Label>
                <Textarea id="content" value={noteData.content} onChange={(e) => setNoteData({ ...noteData, content: e.target.value })} className="col-span-3" rows={5} />
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">Batal</Button>
              </DialogClose>
              <Button onClick={handleSaveNote} className="bg-blue-600 hover:bg-blue-700">Simpan Perubahan</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default FinancialNotes;