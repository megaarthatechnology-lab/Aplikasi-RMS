import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const LaporanProgresProyek = () => {
  return <PlaceholderPage title="Laporan Progres Proyek" description="Halaman untuk melihat laporan progres proyek." />;
};

export default LaporanProgresProyek;