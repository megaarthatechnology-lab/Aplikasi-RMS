import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, Calendar, Download, Eye, TrendingUp, Printer, X, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const BalanceChart = ({ data }) => {
  if (!data || data.length === 0) return null;

  const parseBalance = (balanceStr) => parseFloat(balanceStr.replace(/[^0-9,-]+/g, "").replace(",", "."));
  
  const balances = data.map(entry => parseBalance(entry.balance)).reverse();
  if (balances.length < 2) return <div className="w-full h-64 flex items-center justify-center text-slate-400">Data tidak cukup untuk menampilkan tren.</div>;

  const maxBalance = Math.max(...balances);
  const minBalance = Math.min(...balances);

  const points = balances.map((balance, index) => {
    const x = (index / (balances.length - 1)) * 100;
    const y = 100 - ((balance - minBalance) / (maxBalance - minBalance)) * 100;
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className="w-full h-64">
      <svg viewBox="0 0 100 100" className="w-full h-full" preserveAspectRatio="none">
        <defs>
          <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="rgba(59, 130, 246, 0.4)" />
            <stop offset="100%" stopColor="rgba(59, 130, 246, 0)" />
          </linearGradient>
        </defs>
        <polyline
          fill="url(#chartGradient)"
          points={`0,100 ${points} 100,100`}
        />
        <polyline
          fill="none"
          stroke="rgba(59, 130, 246, 1)"
          strokeWidth="1"
          points={points}
        />
      </svg>
    </div>
  );
};

const GeneralLedger = () => {
  const { toast } = useToast();
  const [selectedAccount, setSelectedAccount] = useState('1000');
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const handleAction = (action, data = null) => {
    toast({
      title: `📊 ${action}`,
      description: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };
  
  const handleViewDetail = (entry) => {
    setSelectedTransaction(entry);
    setShowDetailModal(true);
  };

  const handlePrint = () => {
    window.print();
  };

  const accounts = [
    { code: '1000', name: 'Kas', balance: 'Rp 150.000.000' },
    { code: '1100', name: 'Bank BCA', balance: 'Rp 500.000.000' },
    { code: '1200', name: 'Piutang Usaha', balance: 'Rp 300.000.000' },
    { code: '2000', name: 'Hutang Usaha', balance: 'Rp 180.000.000' },
    { code: '4000', name: 'Pendapatan Jasa', balance: 'Rp 2.450.000.000' }
  ];

  const ledgerEntriesData = [
    {
      date: '2024-01-01',
      description: 'Saldo Awal',
      reference: 'SA-001',
      debit: 'Rp 100.000.000',
      credit: '',
      balance: 'Rp 100.000.000'
    },
    {
      date: '2024-01-15',
      description: 'Penerimaan dari penjualan',
      reference: 'JE-001',
      debit: 'Rp 50.000.000',
      credit: '',
      balance: 'Rp 150.000.000'
    },
    {
      date: '2024-01-20',
      description: 'Pembayaran supplier',
      reference: 'JE-002',
      debit: '',
      credit: 'Rp 25.000.000',
      balance: 'Rp 125.000.000'
    },
    {
      date: '2024-01-25',
      description: 'Penerimaan piutang',
      reference: 'JE-003',
      debit: 'Rp 30.000.000',
      credit: '',
      balance: 'Rp 155.000.000'
    },
    {
      date: '2024-01-30',
      description: 'Pembayaran operasional',
      reference: 'JE-004',
      debit: '',
      credit: 'Rp 5.000.000',
      balance: 'Rp 150.000.000'
    }
  ];

  const filteredLedgerEntries = ledgerEntriesData.filter(entry => {
    const lowerCaseSearchTerm = searchTerm.toLowerCase();
    return (
      entry.date.toLowerCase().includes(lowerCaseSearchTerm) ||
      entry.description.toLowerCase().includes(lowerCaseSearchTerm) ||
      entry.reference.toLowerCase().includes(lowerCaseSearchTerm) ||
      entry.debit.replace(/[^0-9]/g, '').includes(searchTerm.replace(/[^0-9]/g, '')) ||
      entry.credit.replace(/[^0-9]/g, '').includes(searchTerm.replace(/[^0-9]/g, ''))
    );
  });

  const selectedAccountData = accounts.find(acc => acc.code === selectedAccount);

  return (
    <>
      <Helmet>
        <title>Buku Besar - Sistem Akuntansi Profesional</title>
        <meta name="description" content="Lihat buku besar untuk setiap akun. Analisis pergerakan saldo dan transaksi detail." />
        <style type="text/css">{`
            @media print {
              body * {
                visibility: hidden;
              }
              .printable-area, .printable-area * {
                visibility: visible;
              }
              .printable-area {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
              }
              .no-print {
                display: none;
              }
            }
        `}</style>
      </Helmet>

      <div className="space-y-6 printable-area">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="flex flex-col md:flex-row md:items-center md:justify-between no-print">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Buku Besar</h1>
            <p className="text-slate-400">Lihat detail transaksi untuk setiap akun</p>
          </div>
          <div className="flex space-x-2 mt-4 md:mt-0">
             <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-800 border-slate-700 text-white">
                <DropdownMenuItem onSelect={() => handleAction('Export to PDF')}>Export ke PDF</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleAction('Export to Excel')}>Export ke Excel</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button onClick={handlePrint} className="bg-gradient-to-r from-purple-500 to-violet-600 hover:from-purple-600 hover:to-violet-700">
              <Printer className="h-4 w-4 mr-2" />
              Cetak
            </Button>
          </div>
        </motion.div>

        {/* Account Selection and Filters */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }} className="glass-effect rounded-xl p-6 no-print">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            <div className="lg:col-span-2">
              <label htmlFor="search-transaction" className="block text-sm font-medium text-slate-300 mb-2">Cari Transaksi</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
                <input
                  id="search-transaction"
                  type="text"
                  placeholder="Cari berdasarkan tgl, deskripsi, ref, jumlah..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-full bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Pilih Akun</label>
              <select value={selectedAccount} onChange={(e) => setSelectedAccount(e.target.value)} className="w-full bg-slate-700/50 border border-slate-600 rounded-lg text-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                {accounts.map(account => <option key={account.code} value={account.code}>{account.code} - {account.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Periode</label>
              <Button variant="outline" onClick={() => handleAction('Pilih Periode')} className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 justify-start">
                <Calendar className="h-4 w-4 mr-2" />
                Januari 2024
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Account Summary */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }} className="glass-effect rounded-xl p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-white mb-2">Akun</h3>
              <p className="text-2xl font-bold gradient-text">{selectedAccountData?.code} - {selectedAccountData?.name}</p>
            </div>
            <div className="text-center">
              <h3 className="text-lg font-semibold text-white mb-2">Saldo Akhir</h3>
              <p className="text-2xl font-bold text-green-400">{selectedAccountData?.balance}</p>
            </div>
            <div className="text-center">
              <h3 className="text-lg font-semibold text-white mb-2">Total Debit</h3>
              <p className="text-2xl font-bold text-blue-400">Rp 180.000.000</p>
            </div>
            <div className="text-center">
              <h3 className="text-lg font-semibold text-white mb-2">Total Kredit</h3>
              <p className="text-2xl font-bold text-red-400">Rp 30.000.000</p>
            </div>
          </div>
        </motion.div>

        {/* Balance Trend */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.4 }} className="glass-effect rounded-xl p-6 no-print">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Tren Saldo</h2>
            <div className="flex items-center space-x-2 text-green-400">
              <TrendingUp className="h-5 w-5" />
              <span className="text-sm font-medium">+50% dari bulan lalu</span>
            </div>
          </div>
          <BalanceChart data={filteredLedgerEntries} />
        </motion.div>

        {/* Ledger Entries Table */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="glass-effect rounded-xl overflow-hidden">
          <div className="p-6 border-b border-slate-700/50">
            <h2 className="text-xl font-semibold text-white">Detail Transaksi</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-800/50">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Tanggal</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Deskripsi</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Referensi</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">Debit</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">Kredit</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">Saldo</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-300 no-print">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                <AnimatePresence>
                {filteredLedgerEntries.length > 0 ? (
                  filteredLedgerEntries.map((entry, index) => (
                    <motion.tr key={index} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3, delay: index * 0.05 }} className="hover:bg-slate-800/30 transition-colors">
                      <td className="px-6 py-4"><span className="text-slate-300">{entry.date}</span></td>
                      <td className="px-6 py-4"><span className="text-white">{entry.description}</span></td>
                      <td className="px-6 py-4"><span className="text-slate-300 font-mono">{entry.reference}</span></td>
                      <td className="px-6 py-4 text-right"><span className="text-green-400 font-semibold">{entry.debit}</span></td>
                      <td className="px-6 py-4 text-right"><span className="text-red-400 font-semibold">{entry.credit}</span></td>
                      <td className="px-6 py-4 text-right"><span className="text-white font-semibold">{entry.balance}</span></td>
                      <td className="px-6 py-4 no-print">
                        <div className="flex items-center justify-center">
                          <Button variant="ghost" size="sm" onClick={() => handleViewDetail(entry)} className="text-slate-400 hover:text-blue-400 hover:bg-blue-500/10">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </motion.tr>
                  ))
                ) : (
                  <motion.tr initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    <td colSpan="7" className="text-center py-12 px-6">
                        <p className="text-slate-400">Tidak ada transaksi yang cocok dengan pencarian Anda.</p>
                    </td>
                  </motion.tr>
                )}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>

      {/* Transaction Detail Modal */}
      <AnimatePresence>
        {showDetailModal && selectedTransaction && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 no-print"
            onClick={() => setShowDetailModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 50, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 50, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-slate-800 rounded-2xl p-8 w-full max-w-lg border border-slate-700 shadow-2xl flex flex-col"
            >
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-white">Detail Transaksi</h2>
                  <p className="text-slate-400 font-mono">{selectedTransaction.reference}</p>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setShowDetailModal(false)} className="text-slate-400 hover:text-white -mr-2 -mt-2"><X className="h-5 w-5" /></Button>
              </div>

              <div className="space-y-4 text-sm">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Tanggal Transaksi</span>
                  <span className="text-white font-medium">{selectedTransaction.date}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Akun</span>
                  <span className="text-white font-medium">{selectedAccountData.code} - {selectedAccountData.name}</span>
                </div>
                 <div className="pt-4 border-t border-slate-700">
                  <p className="text-slate-300 mb-2">{selectedTransaction.description}</p>
                 </div>
                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-700">
                  <div className="text-center bg-slate-700/50 p-4 rounded-lg">
                    <p className="text-slate-400 mb-1">Debit</p>
                    <p className="text-lg font-semibold text-green-400">{selectedTransaction.debit || '-'}</p>
                  </div>
                   <div className="text-center bg-slate-700/50 p-4 rounded-lg">
                    <p className="text-slate-400 mb-1">Kredit</p>
                    <p className="text-lg font-semibold text-red-400">{selectedTransaction.credit || '-'}</p>
                  </div>
                </div>
                <div className="flex justify-between items-center pt-4 border-t border-slate-700">
                  <span className="text-slate-400 font-semibold">Saldo Setelah Transaksi</span>
                  <span className="text-white font-bold text-lg">{selectedTransaction.balance}</span>
                </div>
              </div>

              <div className="mt-8 flex justify-end">
                <Button 
                  variant="outline" 
                  className="border-slate-600 text-slate-300 hover:bg-slate-700" 
                  onClick={() => handleAction('Lihat Jurnal Asli')}>
                  <FileText className="h-4 w-4 mr-2" />
                  Lihat Jurnal Asli
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default GeneralLedger;