import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Calendar, Download, Printer, TrendingUp, TrendingDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
const BalanceSheet = () => {
  const {
    toast
  } = useToast();
  const handleAction = action => {
    toast({
      title: `📊 ${action}`,
      description: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir!Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };
  const handlePrint = () => {
    window.print();
  };
  const balanceSheetData = {
    assets: {
      current: {
        title: 'ASET LANCAR',
        items: [{
          name: 'Kas dan Setara Kas',
          amount: 150000000
        }, {
          name: 'Bank',
          amount: 500000000
        }, {
          name: 'Piutang Usaha',
          amount: 300000000
        }, {
          name: 'Piutang Lain-lain',
          amount: 50000000
        }, {
          name: 'Persediaan',
          amount: 200000000
        }, {
          name: 'Biaya Dibayar Dimuka',
          amount: 75000000
        }],
        total: 1275000000
      },
      nonCurrent: {
        title: 'ASET TIDAK LANCAR',
        items: [{
          name: 'Peralatan',
          amount: 800000000
        }, {
          name: 'Akumulasi Penyusutan Peralatan',
          amount: -200000000
        }, {
          name: 'Kendaraan',
          amount: 400000000
        }, {
          name: 'Akumulasi Penyusutan Kendaraan',
          amount: -100000000
        }, {
          name: 'Bangunan',
          amount: 1500000000
        }, {
          name: 'Akumulasi Penyusutan Bangunan',
          amount: -300000000
        }, {
          name: 'Tanah',
          amount: 800000000
        }],
        total: 2900000000
      }
    },
    liabilities: {
      current: {
        title: 'KEWAJIBAN LANCAR',
        items: [{
          name: 'Hutang Usaha',
          amount: 180000000
        }, {
          name: 'Hutang Gaji',
          amount: 50000000
        }, {
          name: 'Hutang Pajak',
          amount: 75000000
        }, {
          name: 'Biaya yang Masih Harus Dibayar',
          amount: 45000000
        }, {
          name: 'Hutang Jangka Pendek',
          amount: 100000000
        }],
        total: 450000000
      },
      nonCurrent: {
        title: 'KEWAJIBAN JANGKA PANJANG',
        items: [{
          name: 'Hutang Bank Jangka Panjang',
          amount: 400000000
        }, {
          name: 'Hutang Obligasi',
          amount: 300000000
        }, {
          name: 'Hutang Lain-lain',
          amount: 25000000
        }],
        total: 725000000
      }
    },
    equity: {
      title: 'EKUITAS',
      items: [{
        name: 'Modal Saham',
        amount: 1000000000
      }, {
        name: 'Laba Ditahan',
        amount: 1100000000
      }, {
        name: 'Cadangan Umum',
        amount: 200000000
      }, {
        name: 'Laba Rugi Tahun Berjalan',
        amount: 700000000
      }],
      total: 3000000000
    }
  };
  const totalAssets = balanceSheetData.assets.current.total + balanceSheetData.assets.nonCurrent.total;
  const totalLiabilities = balanceSheetData.liabilities.current.total + balanceSheetData.liabilities.nonCurrent.total;
  const totalEquity = balanceSheetData.equity.total;
  const totalLiabilitiesAndEquity = totalLiabilities + totalEquity;
  const formatCurrency = amount => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(Math.abs(amount));
  };
  return <>
      <Helmet>
        <title>Neraca - Sistem Akuntansi Profesional</title>
        <meta name="description" content="Laporan neraca yang menampilkan posisi keuangan perusahaan meliputi aset, kewajiban, dan ekuitas." />
        <style type="text/css">{`
            @media print {
              body * {
                visibility: hidden;
              }
              .printable-area, .printable-area * {
                visibility: visible;
              }
              .printable-area {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
              }
              .no-print {
                display: none;
              }
            }
        `}</style>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.5
      }} className="flex flex-col md:flex-row md:items-center md:justify-between no-print">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Neraca</h1>
            <p className="text-slate-400">Posisi keuangan perusahaan pada tanggal tertentu</p>
          </div>
          <div className="flex space-x-2 mt-4 md:mt-0">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-800 border-slate-700 text-white">
                <DropdownMenuItem onSelect={() => handleAction('Export to PDF')}>Export ke PDF</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleAction('Export to Excel')}>Export ke Excel</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button onClick={handlePrint} className="bg-gradient-to-r from-indigo-500 to-blue-600 hover:from-indigo-600 hover:to-blue-700">
              <Printer className="h-4 w-4 mr-2" />
              Cetak
            </Button>
          </div>
        </motion.div>

        {/* Period Selection */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.5,
        delay: 0.1
      }} className="glass-effect rounded-xl p-6 no-print">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Tanggal Neraca</label>
              <Button variant="outline" onClick={() => handleAction('Pilih Tanggal')} className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 justify-start">
                <Calendar className="h-4 w-4 mr-2" />
                31 Januari 2024
              </Button>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Format Laporan</label>
              <select className="w-full bg-slate-700/50 border border-slate-600 rounded-lg text-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option>Format Standar</option>
                <option>Format Komparatif</option>
                <option>Format Persentase</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Summary Cards */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.5,
        delay: 0.2
      }} className="grid grid-cols-1 md:grid-cols-4 gap-6 no-print">
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Total Aset</h3>
            <p className="text-2xl font-bold text-green-400">{formatCurrency(totalAssets)}</p>
            <div className="flex items-center justify-center mt-2 text-green-400">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm">+8.5%</span>
            </div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Total Kewajiban</h3>
            <p className="text-2xl font-bold text-red-400">{formatCurrency(totalLiabilities)}</p>
            <div className="flex items-center justify-center mt-2 text-red-400">
              <TrendingDown className="h-4 w-4 mr-1" />
              <span className="text-sm">-3.2%</span>
            </div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Total Ekuitas</h3>
            <p className="text-2xl font-bold text-blue-400">{formatCurrency(totalEquity)}</p>
            <div className="flex items-center justify-center mt-2 text-blue-400">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm">+15.7%</span>
            </div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Rasio Hutang</h3>
            <p className="text-2xl font-bold gradient-text">
              {(totalLiabilities / totalAssets * 100).toFixed(1)}%
            </p>
          </div>
        </motion.div>

        <div className="printable-area">
          {/* Balance Sheet */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.5,
          delay: 0.3
        }} className="glass-effect rounded-xl overflow-hidden">
            <div className="p-6 border-b border-slate-700/50">
              <h2 className="text-xl font-semibold text-white text-center">PT. Mega Artha Technology</h2>
              <p className="text-slate-400 text-center mt-1">NERACA</p>
              <p className="text-slate-400 text-center">Per 31 Januari 2024</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-slate-700/50">
              {/* Assets Side */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-green-400 mb-6 text-center">ASET</h3>
                
                {/* Current Assets */}
                <div className="mb-8">
                  <h4 className="text-lg font-semibold text-green-400 mb-4">{balanceSheetData.assets.current.title}</h4>
                  {balanceSheetData.assets.current.items.map((item, index) => <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30">
                      <span className="text-slate-300">{item.name}</span>
                      <span className="text-white font-semibold">{formatCurrency(item.amount)}</span>
                    </div>)}
                  <div className="flex justify-between items-center py-3 border-t-2 border-green-500/50 mt-2">
                    <span className="text-green-400 font-semibold">TOTAL ASET LANCAR</span>
                    <span className="text-green-400 font-bold">{formatCurrency(balanceSheetData.assets.current.total)}</span>
                  </div>
                </div>

                {/* Non-Current Assets */}
                <div className="mb-6">
                  <h4 className="text-lg font-semibold text-green-400 mb-4">{balanceSheetData.assets.nonCurrent.title}</h4>
                  {balanceSheetData.assets.nonCurrent.items.map((item, index) => <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30">
                      <span className={`${item.amount < 0 ? 'text-slate-400 pl-4' : 'text-slate-300'}`}>
                        {item.name}
                      </span>
                      <span className={`font-semibold ${item.amount < 0 ? 'text-red-400' : 'text-white'}`}>
                        {item.amount < 0 ? `(${formatCurrency(item.amount)})` : formatCurrency(item.amount)}
                      </span>
                    </div>)}
                  <div className="flex justify-between items-center py-3 border-t-2 border-green-500/50 mt-2">
                    <span className="text-green-400 font-semibold">TOTAL ASET TIDAK LANCAR</span>
                    <span className="text-green-400 font-bold">{formatCurrency(balanceSheetData.assets.nonCurrent.total)}</span>
                  </div>
                </div>

                {/* Total Assets */}
                <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-lg p-4 border border-green-500/30">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold text-lg">TOTAL ASET</span>
                    <span className="text-green-400 font-bold text-xl">{formatCurrency(totalAssets)}</span>
                  </div>
                </div>
              </div>

              {/* Liabilities and Equity Side */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-red-400 mb-6 text-center">KEWAJIBAN & EKUITAS</h3>
                
                {/* Current Liabilities */}
                <div className="mb-8">
                  <h4 className="text-lg font-semibold text-red-400 mb-4">{balanceSheetData.liabilities.current.title}</h4>
                  {balanceSheetData.liabilities.current.items.map((item, index) => <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30">
                      <span className="text-slate-300">{item.name}</span>
                      <span className="text-white font-semibold">{formatCurrency(item.amount)}</span>
                    </div>)}
                  <div className="flex justify-between items-center py-3 border-t-2 border-red-500/50 mt-2">
                    <span className="text-red-400 font-semibold">TOTAL KEWAJIBAN LANCAR</span>
                    <span className="text-red-400 font-bold">{formatCurrency(balanceSheetData.liabilities.current.total)}</span>
                  </div>
                </div>

                {/* Non-Current Liabilities */}
                <div className="mb-8">
                  <h4 className="text-lg font-semibold text-red-400 mb-4">{balanceSheetData.liabilities.nonCurrent.title}</h4>
                  {balanceSheetData.liabilities.nonCurrent.items.map((item, index) => <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30">
                      <span className="text-slate-300">{item.name}</span>
                      <span className="text-white font-semibold">{formatCurrency(item.amount)}</span>
                    </div>)}
                  <div className="flex justify-between items-center py-3 border-t-2 border-red-500/50 mt-2">
                    <span className="text-red-400 font-semibold">TOTAL KEWAJIBAN JANGKA PANJANG</span>
                    <span className="text-red-400 font-bold">{formatCurrency(balanceSheetData.liabilities.nonCurrent.total)}</span>
                  </div>
                </div>

                {/* Total Liabilities */}
                <div className="bg-red-500/20 rounded-lg p-3 border border-red-500/30 mb-6">
                  <div className="flex justify-between items-center">
                    <span className="text-red-400 font-semibold">TOTAL KEWAJIBAN</span>
                    <span className="text-red-400 font-bold">{formatCurrency(totalLiabilities)}</span>
                  </div>
                </div>

                {/* Equity */}
                <div className="mb-6">
                  <h4 className="text-lg font-semibold text-blue-400 mb-4">{balanceSheetData.equity.title}</h4>
                  {balanceSheetData.equity.items.map((item, index) => <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30">
                      <span className="text-slate-300">{item.name}</span>
                      <span className="text-white font-semibold">{formatCurrency(item.amount)}</span>
                    </div>)}
                  <div className="flex justify-between items-center py-3 border-t-2 border-blue-500/50 mt-2">
                    <span className="text-blue-400 font-semibold">TOTAL EKUITAS</span>
                    <span className="text-blue-400 font-bold">{formatCurrency(balanceSheetData.equity.total)}</span>
                  </div>
                </div>

                {/* Total Liabilities and Equity */}
                <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-lg p-4 border border-blue-500/30">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold text-lg">TOTAL KEWAJIBAN & EKUITAS</span>
                    <span className="text-blue-400 font-bold text-xl">{formatCurrency(totalLiabilitiesAndEquity)}</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Financial Ratios */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.5,
        delay: 0.4
      }} className="glass-effect rounded-xl p-6 no-print">
          <h3 className="text-xl font-semibold text-white mb-6">Rasio Keuangan</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <h4 className="text-sm font-medium text-slate-400 mb-2">Current Ratio</h4>
              <p className="text-2xl font-bold text-green-400">
                {(balanceSheetData.assets.current.total / balanceSheetData.liabilities.current.total).toFixed(2)}
              </p>
            </div>
            <div className="text-center">
              <h4 className="text-sm font-medium text-slate-400 mb-2">Debt to Equity</h4>
              <p className="text-2xl font-bold text-red-400">
                {(totalLiabilities / totalEquity).toFixed(2)}
              </p>
            </div>
            <div className="text-center">
              <h4 className="text-sm font-medium text-slate-400 mb-2">Debt Ratio</h4>
              <p className="text-2xl font-bold text-yellow-400">
                {(totalLiabilities / totalAssets * 100).toFixed(1)}%
              </p>
            </div>
            <div className="text-center">
              <h4 className="text-sm font-medium text-slate-400 mb-2">Equity Ratio</h4>
              <p className="text-2xl font-bold text-blue-400">
                {(totalEquity / totalAssets * 100).toFixed(1)}%
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </>;
};
export default BalanceSheet;