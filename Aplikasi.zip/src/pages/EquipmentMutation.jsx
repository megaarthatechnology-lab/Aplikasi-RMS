import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Edit, Trash2, MoreHorizontal, Search, Filter, Package, ArrowRightLeft, Calendar, MapPin, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const MUTATION_TYPES = {
  Transfer: { label: 'Transfer', icon: <ArrowRightLeft className="h-4 w-4 text-blue-400" /> },
  Disposal: { label: 'Pelepasan', icon: <Trash2 className="h-4 w-4 text-red-400" /> },
  Acquisition: { label: 'Akuisisi', icon: <Plus className="h-4 w-4 text-green-400" /> },
};

const MUTATION_STATUS = {
  Completed: { label: 'Selesai', color: 'bg-green-500/20 text-green-400', icon: <CheckCircle /> },
  Pending: { label: 'Tertunda', color: 'bg-yellow-500/20 text-yellow-400', icon: <Clock /> },
  Cancelled: { label: 'Dibatalkan', color: 'bg-red-500/20 text-red-400', icon: <XCircle /> },
};

const defaultMutations = [
  {
    id: 'MUT-001',
    assetName: 'Excavator CAT 320D',
    mutationType: 'Transfer',
    date: '2025-11-10',
    quantity: 1,
    fromLocation: 'Gudang Pusat',
    toLocation: 'Proyek A',
    status: 'Completed',
  },
  {
    id: 'MUT-002',
    assetName: 'Genset 500 kVA',
    mutationType: 'Disposal',
    date: '2025-11-05',
    quantity: 1,
    fromLocation: 'Proyek B',
    toLocation: 'N/A',
    status: 'Completed',
  },
  {
    id: 'MUT-003',
    assetName: 'Dump Truck Hino',
    mutationType: 'Acquisition',
    date: '2025-10-28',
    quantity: 2,
    fromLocation: 'N/A',
    toLocation: 'Gudang Pusat',
    status: 'Completed',
  },
  {
    id: 'MUT-004',
    assetName: 'Vibro Roller',
    mutationType: 'Transfer',
    date: '2025-11-15',
    quantity: 1,
    fromLocation: 'Gudang Pusat',
    toLocation: 'Proyek C',
    status: 'Pending',
  },
];

const EquipmentMutation = () => {
  const { toast } = useToast();
  const [mutations, setMutations] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentMutation, setCurrentMutation] = useState(null);
  const [mutationData, setMutationData] = useState({
    id: '', assetName: '', mutationType: 'Transfer', date: '', quantity: 1, fromLocation: '', toLocation: '', status: 'Pending'
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  useEffect(() => {
    try {
      const savedMutations = localStorage.getItem('equipmentMutations');
      if (savedMutations) {
        setMutations(JSON.parse(savedMutations));
      } else {
        setMutations(defaultMutations);
        localStorage.setItem('equipmentMutations', JSON.stringify(defaultMutations));
      }
    } catch (error) {
      console.error("Gagal memuat data mutasi dari localStorage:", error);
      setMutations(defaultMutations);
    }
  }, []);

  const saveMutationsToLocalStorage = (updatedMutations) => {
    try {
      localStorage.setItem('equipmentMutations', JSON.stringify(updatedMutations));
    } catch (error) {
      console.error("Gagal menyimpan data mutasi ke localStorage:", error);
      toast({
        variant: "destructive",
        title: "Gagal Menyimpan Data",
        description: "Tidak dapat menyimpan perubahan ke penyimpanan lokal.",
      });
    }
  };

  const handleOpenDialog = (mutation = null) => {
    setCurrentMutation(mutation);
    if (mutation) {
      setMutationData(mutation);
    } else {
      const newId = `MUT-${String(Date.now()).slice(-4)}`;
      setMutationData({
        id: newId, assetName: '', mutationType: 'Transfer', date: new Date().toISOString().split('T')[0], quantity: 1, fromLocation: '', toLocation: '', status: 'Pending'
      });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setCurrentMutation(null);
  };

  const handleSaveMutation = () => {
    if (!mutationData.assetName || !mutationData.date || !mutationData.quantity) {
      toast({
        variant: "destructive",
        title: "Gagal Menyimpan",
        description: "Nama Aset, Tanggal, dan Kuantitas harus diisi.",
      });
      return;
    }

    let updatedMutations;
    if (currentMutation) {
      updatedMutations = mutations.map((m) =>
        m.id === currentMutation.id ? { ...mutationData } : m
      );
      toast({ title: "Data Mutasi Diperbarui", description: `Mutasi untuk "${mutationData.assetName}" berhasil diperbarui.` });
    } else {
      updatedMutations = [...mutations, mutationData];
      toast({ title: "Mutasi Ditambahkan", description: `Mutasi baru untuk "${mutationData.assetName}" berhasil ditambahkan.` });
    }
    setMutations(updatedMutations);
    saveMutationsToLocalStorage(updatedMutations);
    handleCloseDialog();
  };

  const handleDeleteMutation = (mutationId) => {
    const updatedMutations = mutations.filter((m) => m.id !== mutationId);
    setMutations(updatedMutations);
    saveMutationsToLocalStorage(updatedMutations);
    toast({ title: "Mutasi Dihapus", description: "Data mutasi telah berhasil dihapus." });
  };

  const filteredMutations = useMemo(() => {
    return mutations.filter(mutation => {
      const matchesSearch = mutation.assetName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            mutation.id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = statusFilter === 'All' || mutation.status === statusFilter;
      return matchesSearch && matchesFilter;
    });
  }, [mutations, searchTerm, statusFilter]);

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  return (
    <>
      <Helmet>
        <title>Mutasi Alat - Sistem Akuntansi</title>
        <meta name="description" content="Kelola dan lacak semua mutasi alat dan aset, termasuk transfer, akuisisi, dan pelepasan." />
      </Helmet>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Mutasi Alat</h1>
            <p className="text-slate-400">Lacak semua pergerakan dan perubahan status aset Anda.</p>
          </div>
          <Button onClick={() => handleOpenDialog()} className="mt-4 md:mt-0 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
            <Plus className="h-4 w-4 mr-2" />
            Tambah Mutasi
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass-effect p-4 rounded-xl flex flex-col md:flex-row gap-4"
        >
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 h-5 w-5" />
            <Input 
              placeholder="Cari berdasarkan nama aset atau ID mutasi..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-slate-400" />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Filter Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">Semua Status</SelectItem>
                {Object.entries(MUTATION_STATUS).map(([key, { label }]) => (
                  <SelectItem key={key} value={key}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="glass-effect rounded-xl overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="border-b-slate-700 hover:bg-slate-800/60">
                  <TableHead>ID Mutasi</TableHead>
                  <TableHead><Package className="inline-block h-4 w-4 mr-1" /> Nama Aset</TableHead>
                  <TableHead><ArrowRightLeft className="inline-block h-4 w-4 mr-1" /> Tipe</TableHead>
                  <TableHead><Calendar className="inline-block h-4 w-4 mr-1" /> Tanggal</TableHead>
                  <TableHead><MapPin className="inline-block h-4 w-4 mr-1" /> Lokasi</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <AnimatePresence>
                  {filteredMutations.length > 0 ? filteredMutations.map((mutation) => (
                    <motion.tr
                      key={mutation.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="border-b-slate-800"
                    >
                      <TableCell className="font-mono text-xs text-slate-400">{mutation.id}</TableCell>
                      <TableCell className="font-medium">{mutation.assetName} (x{mutation.quantity})</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {MUTATION_TYPES[mutation.mutationType]?.icon}
                          <span>{MUTATION_TYPES[mutation.mutationType]?.label}</span>
                        </div>
                      </TableCell>
                      <TableCell>{formatDate(mutation.date)}</TableCell>
                      <TableCell className="text-sm">
                        <div className="flex items-center gap-2">
                          <span className="text-slate-400">{mutation.fromLocation || 'N/A'}</span>
                          <ArrowRightLeft className="h-3 w-3 text-slate-500" />
                          <span className="text-slate-200">{mutation.toLocation || 'N/A'}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1.5 ${MUTATION_STATUS[mutation.status]?.color}`}>
                          {React.cloneElement(MUTATION_STATUS[mutation.status]?.icon, { className: "h-3.5 w-3.5" })}
                          {MUTATION_STATUS[mutation.status]?.label}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:bg-slate-700/50">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700 text-white">
                            <DropdownMenuItem onSelect={() => handleOpenDialog(mutation)} className="flex items-center">
                              <Edit className="h-4 w-4 mr-2" /> Edit
                            </DropdownMenuItem>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="flex items-center text-red-400 focus:bg-red-500/10 focus:text-red-400">
                                  <Trash2 className="h-4 w-4 mr-2" /> Hapus
                                </DropdownMenuItem>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Anda yakin ingin menghapus?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tindakan ini akan menghapus mutasi ID {mutation.id} secara permanen.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Batal</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDeleteMutation(mutation.id)} className="bg-red-600 hover:bg-red-700">
                                    Hapus
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </motion.tr>
                  )) : (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center h-24 text-slate-400">
                        Tidak ada data mutasi yang cocok dengan kriteria Anda.
                      </TableCell>
                    </TableRow>
                  )}
                </AnimatePresence>
              </TableBody>
            </Table>
          </div>
        </motion.div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>{currentMutation ? 'Edit Mutasi Alat' : 'Tambah Mutasi Alat'}</DialogTitle>
              <DialogDescription>
                {currentMutation ? 'Perbarui detail mutasi di bawah ini.' : 'Isi detail untuk mutasi baru.'}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="assetName">Nama Aset/Alat</Label>
                <Input id="assetName" value={mutationData.assetName} onChange={(e) => setMutationData({ ...mutationData, assetName: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="mutationType">Tipe Mutasi</Label>
                  <Select value={mutationData.mutationType} onValueChange={(value) => setMutationData({ ...mutationData, mutationType: value })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(MUTATION_TYPES).map(([key, { label }]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date">Tanggal Mutasi</Label>
                  <Input id="date" type="date" value={mutationData.date} onChange={(e) => setMutationData({ ...mutationData, date: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Kuantitas</Label>
                  <Input id="quantity" type="number" min="1" value={mutationData.quantity} onChange={(e) => setMutationData({ ...mutationData, quantity: parseInt(e.target.value) || 1 })} />
                </div>
                 <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select value={mutationData.status} onValueChange={(value) => setMutationData({ ...mutationData, status: value })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(MUTATION_STATUS).map(([key, { label }]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fromLocation">Lokasi Asal</Label>
                  <Input id="fromLocation" value={mutationData.fromLocation} onChange={(e) => setMutationData({ ...mutationData, fromLocation: e.target.value })} placeholder="Contoh: Gudang Pusat"/>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="toLocation">Lokasi Tujuan</Label>
                  <Input id="toLocation" value={mutationData.toLocation} onChange={(e) => setMutationData({ ...mutationData, toLocation: e.target.value })} placeholder="Contoh: Proyek A"/>
                </div>
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild><Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">Batal</Button></DialogClose>
              <Button onClick={handleSaveMutation} className="bg-blue-600 hover:bg-blue-700">Simpan</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default EquipmentMutation;