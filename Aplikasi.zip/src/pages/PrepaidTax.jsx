import React from 'react';
import PlaceholderPage from '@/components/shared/PlaceholderPage';

const PrepaidTax = () => {
  return <PlaceholderPage title="Pajak Bayar Dimuka" />;
};

export default PrepaidTax;