import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const CatatanLaporanKeuangan = () => {
  return <PlaceholderPage title="Catatan Atas Laporan Keuangan" description="Halaman untuk catatan atas laporan keuangan." />;
};

export default CatatanLaporanKeuangan;