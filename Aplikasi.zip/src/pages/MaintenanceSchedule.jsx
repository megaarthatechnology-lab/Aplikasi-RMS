import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getMaintenanceSchedules, saveMaintenanceSchedules } from '@/lib/maintenance-api';
import { getDynamicStatus } from '@/lib/maintenance-utils';

import FilterControls from '@/components/maintenance/FilterControls';
import MaintenanceTable from '@/components/maintenance/MaintenanceTable';
import MaintenanceFormDialog from '@/components/maintenance/MaintenanceFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const MaintenanceSchedule = () => {
  const [schedules, setSchedules] = useState([]);
  const [filters, setFilters] = useState({
    assetName: '',
    assetCode: '',
    maintenanceType: '',
    status: '',
    startDate: '',
    endDate: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedSchedule, setSelectedSchedule] = useState(null);
  const [scheduleToDelete, setScheduleToDelete] = useState(null);

  const { toast } = useToast();
  const today = new Date(); // Use a consistent 'today' for all calculations in a render

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getMaintenanceSchedules();
    setSchedules(data);
  };

  const filteredSchedules = useMemo(() => {
    return schedules
      .map(s => ({ ...s, dynamicStatus: getDynamicStatus(s, today) }))
      .filter(s => {
        const nameMatch = !filters.assetName || s.assetName.toLowerCase().includes(filters.assetName.toLowerCase());
        const codeMatch = !filters.assetCode || s.assetCode.toLowerCase().includes(filters.assetCode.toLowerCase());
        const typeMatch = !filters.maintenanceType || s.maintenanceType === filters.maintenanceType;
        const statusMatch = !filters.status || s.dynamicStatus.staticStatus === filters.status;

        const nextDate = new Date(s.nextMaintenanceDate);
        const startDate = filters.startDate ? new Date(filters.startDate) : null;
        const endDate = filters.endDate ? new Date(filters.endDate) : null;
        if (startDate) startDate.setHours(0, 0, 0, 0);
        if (endDate) endDate.setHours(23, 59, 59, 999);
        const dateRangeMatch = (!startDate || nextDate >= startDate) && (!endDate || nextDate <= endDate);

        return nameMatch && codeMatch && typeMatch && statusMatch && dateRangeMatch;
      });
  }, [schedules, filters, today]);

  const handleOpenForm = (schedule = null) => {
    setSelectedSchedule(schedule);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedSchedule(null);
  };

  const handleSaveSchedule = (formData) => {
    let updatedSchedules;
    const parsedData = {
      ...formData,
      estimatedCost: parseFloat(formData.estimatedCost),
    };

    if (selectedSchedule) {
      updatedSchedules = schedules.map(s => (s.id === selectedSchedule.id ? { ...selectedSchedule, ...parsedData } : s));
      toast({ title: "✅ Sukses", description: "Jadwal perawatan berhasil diperbarui." });
    } else {
      const newSchedule = { ...parsedData, id: Date.now() };
      updatedSchedules = [...schedules, newSchedule];
      toast({ title: "✅ Sukses", description: "Jadwal perawatan baru berhasil ditambahkan." });
    }
    saveMaintenanceSchedules(updatedSchedules);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setScheduleToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedSchedules = schedules.filter(s => s.id !== scheduleToDelete);
    saveMaintenanceSchedules(updatedSchedules);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setScheduleToDelete(null);
    toast({
      title: "🗑️ Jadwal Dihapus",
      description: "Jadwal perawatan telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Jadwal Perawatan Aset - Sistem Akuntansi</title>
        <meta name="description" content="Kelola dan lacak semua jadwal perawatan aset untuk memastikan operasional yang lancar." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Jadwal Perawatan Aset</h1>
            <p className="text-muted-foreground">Rencanakan, lacak, dan kelola semua aktivitas perawatan aset.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Tambah Jadwal
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <MaintenanceTable
          schedules={filteredSchedules}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <MaintenanceFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveSchedule}
        schedule={selectedSchedule}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus jadwal perawatan secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default MaintenanceSchedule;