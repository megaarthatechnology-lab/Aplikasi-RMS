import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const PemakaianBahanBaku = () => {
  return <PlaceholderPage title="Pemakaian Bahan Baku" description="Halaman untuk mencatat pemakaian bahan baku." />;
};

export default PemakaianBahanBaku;