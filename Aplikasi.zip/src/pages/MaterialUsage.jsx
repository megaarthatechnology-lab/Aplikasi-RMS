import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getMaterialUsages, saveMaterialUsages } from '@/lib/material-usage-api';

import FilterControls from '@/components/material-usage/FilterControls';
import MaterialUsageTable from '@/components/material-usage/MaterialUsageTable';
import MaterialUsageFormDialog from '@/components/material-usage/MaterialUsageFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const MaterialUsage = () => {
  const [usages, setUsages] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    projectReference: '',
    startDate: '',
    endDate: '',
    minCost: '',
    maxCost: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedUsage, setSelectedUsage] = useState(null);
  const [usageToDelete, setUsageToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getMaterialUsages();
    setUsages(data);
  };

  const projectReferences = useMemo(() => {
      const allProjects = getMaterialUsages().map(u => u.projectReference);
      return [...new Set(allProjects)];
  }, []);

  const filteredUsages = useMemo(() => {
    return usages.filter(u => {
      const searchTermMatch = u.materialName.toLowerCase().includes(filters.searchTerm.toLowerCase());
      const projectMatch = !filters.projectReference || u.projectReference === filters.projectReference;

      const usageDate = new Date(u.date);
      const startDate = filters.startDate ? new Date(filters.startDate) : null;
      const endDate = filters.endDate ? new Date(filters.endDate) : null;
      if (startDate) startDate.setHours(0, 0, 0, 0);
      if (endDate) endDate.setHours(23, 59, 59, 999);
      const dateRangeMatch = (!startDate || usageDate >= startDate) && (!endDate || usageDate <= endDate);
      
      const minCost = filters.minCost ? parseFloat(filters.minCost) : null;
      const maxCost = filters.maxCost ? parseFloat(filters.maxCost) : null;
      const costMatch = (minCost === null || u.cost >= minCost) && (maxCost === null || u.cost <= maxCost);

      return searchTermMatch && projectMatch && dateRangeMatch && costMatch;
    });
  }, [usages, filters]);

  const handleOpenForm = (usage = null) => {
    setSelectedUsage(usage);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedUsage(null);
  };

  const handleSaveUsage = (formData) => {
    let updatedUsages;
    const parsedData = {
      ...formData,
      quantity: parseFloat(formData.quantity),
      cost: parseFloat(formData.cost),
    };

    if (selectedUsage) {
      updatedUsages = usages.map(p => (p.id === selectedUsage.id ? { ...selectedUsage, ...parsedData } : p));
      toast({ title: "✅ Sukses", description: "Data pemakaian material berhasil diperbarui." });
    } else {
      const newUsage = { ...parsedData, id: Date.now() };
      updatedUsages = [...usages, newUsage];
      toast({ title: "✅ Sukses", description: "Catatan pemakaian baru berhasil ditambahkan." });
    }
    saveMaterialUsages(updatedUsages);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setUsageToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedUsages = usages.filter(p => p.id !== usageToDelete);
    saveMaterialUsages(updatedUsages);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setUsageToDelete(null);
    toast({
      title: "🗑️ Catatan Dihapus",
      description: "Data pemakaian material telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Pemakaian Bahan - Sistem Akuntansi</title>
        <meta name="description" content="Kelola, tambah, edit, dan lacak semua pemakaian bahan untuk proyek." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Manajemen Pemakaian Bahan</h1>
            <p className="text-muted-foreground">Lacak semua penggunaan material dan bahan dalam proyek.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Catat Pemakaian
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} projectReferences={projectReferences}/>

        <MaterialUsageTable
          usages={filteredUsages}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <MaterialUsageFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveUsage}
        usage={selectedUsage}
        projectReferences={projectReferences}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data pemakaian material secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default MaterialUsage;