import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const InfoDokumenHutang = () => {
  return <PlaceholderPage title="Informasi Dokumen Hutang" description="Halaman untuk informasi dokumen terjadinya hutang." />;
};

export default InfoDokumenHutang;