import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getRawMaterials, saveRawMaterials } from '@/lib/raw-materials-api';

import FilterControls from '@/components/raw-materials/FilterControls';
import RawMaterialsTable from '@/components/raw-materials/RawMaterialsTable';
import RawMaterialFormDialog from '@/components/raw-materials/RawMaterialFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const RawMaterialUsage = () => {
  const [materials, setMaterials] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    supplier: '',
    status: 'all',
    minQuantity: '',
    maxQuantity: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedMaterial, setSelectedMaterial] = useState(null);
  const [materialToDelete, setMaterialToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getRawMaterials();
    setMaterials(data);
  };
  
  const suppliers = useMemo(() => {
      const allSuppliers = getRawMaterials().map(m => m.supplierName);
      return [...new Set(allSuppliers)];
  }, []);

  const filteredMaterials = useMemo(() => {
    return materials.filter(m => {
      const searchTermMatch = m.materialName.toLowerCase().includes(filters.searchTerm.toLowerCase());
      const supplierMatch = !filters.supplier || m.supplierName === filters.supplier;
      const statusMatch = filters.status === 'all' || m.status === filters.status;
      
      const minQty = filters.minQuantity ? parseFloat(filters.minQuantity) : null;
      const maxQty = filters.maxQuantity ? parseFloat(filters.maxQuantity) : null;
      const quantityMatch = (minQty === null || m.quantityInStock >= minQty) && (maxQty === null || m.quantityInStock <= maxQty);

      return searchTermMatch && supplierMatch && statusMatch && quantityMatch;
    });
  }, [materials, filters]);

  const handleOpenForm = (material = null) => {
    setSelectedMaterial(material);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedMaterial(null);
  };

  const handleSaveMaterial = (formData) => {
    let currentMaterials = getRawMaterials();
    let updatedMaterials;
    const parsedData = {
      ...formData,
      quantityInStock: parseFloat(formData.quantityInStock),
      costPerUnit: parseFloat(formData.costPerUnit),
      reorderLevel: parseFloat(formData.reorderLevel),
    };

    if (selectedMaterial) {
      updatedMaterials = currentMaterials.map(m => (m.id === selectedMaterial.id ? { ...selectedMaterial, ...parsedData } : m));
      toast({ title: "✅ Sukses", description: "Data bahan baku berhasil diperbarui." });
    } else {
      const newMaterial = { ...parsedData, id: Date.now() };
      updatedMaterials = [...currentMaterials, newMaterial];
      toast({ title: "✅ Sukses", description: "Bahan baku baru berhasil ditambahkan." });
    }
    saveRawMaterials(updatedMaterials);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setMaterialToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const currentMaterials = getRawMaterials();
    const updatedMaterials = currentMaterials.filter(m => m.id !== materialToDelete);
    saveRawMaterials(updatedMaterials);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setMaterialToDelete(null);
    toast({
      title: "🗑️ Bahan Baku Dihapus",
      description: "Data bahan baku telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Inventaris Bahan Baku - Sistem Akuntansi</title>
        <meta name="description" content="Kelola inventaris bahan baku, lacak stok, dan manajemen supplier." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Manajemen Bahan Baku</h1>
            <p className="text-muted-foreground">Lacak dan kelola inventaris bahan baku untuk produksi.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Tambah Bahan Baku
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} suppliers={suppliers} />

        <RawMaterialsTable
          materials={filteredMaterials}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <RawMaterialFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveMaterial}
        material={selectedMaterial}
        suppliers={suppliers}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data bahan baku secara permanen. Stok tidak dapat dikembalikan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default RawMaterialUsage;