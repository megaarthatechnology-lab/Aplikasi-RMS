import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getBankTransfers, saveBankTransfers } from '@/lib/bank-transfers-api';

import FilterControls from '@/components/bank-transfers/FilterControls';
import BankTransfersTable from '@/components/bank-transfers/BankTransfersTable';
import TransferFormDialog from '@/components/bank-transfers/TransferFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const BankTransfers = () => {
  const [transfers, setTransfers] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    senderBank: 'all',
    recipientBank: 'all',
    status: 'all',
    startDate: '',
    endDate: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedTransfer, setSelectedTransfer] = useState(null);
  const [transferToDelete, setTransferToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getBankTransfers();
    setTransfers(data);
  };

  const filteredTransfers = useMemo(() => {
    return transfers.filter(t => {
      const searchTermMatch = t.senderHolder.toLowerCase().includes(filters.searchTerm.toLowerCase()) || t.recipientHolder.toLowerCase().includes(filters.searchTerm.toLowerCase()) || t.referenceNumber.toLowerCase().includes(filters.searchTerm.toLowerCase());
      const senderBankMatch = filters.senderBank === 'all' || t.senderBank === filters.senderBank;
      const recipientBankMatch = filters.recipientBank === 'all' || t.recipientBank === filters.recipientBank;
      const statusMatch = filters.status === 'all' || t.status === filters.status;
      
      const transferDate = new Date(t.transferDate);
      const startDate = filters.startDate ? new Date(filters.startDate) : null;
      const endDate = filters.endDate ? new Date(filters.endDate) : null;
      if(startDate) startDate.setHours(0, 0, 0, 0);
      if(endDate) endDate.setHours(23, 59, 59, 999);
      const dateRangeMatch = (!startDate || transferDate >= startDate) && (!endDate || transferDate <= endDate);

      return searchTermMatch && senderBankMatch && recipientBankMatch && statusMatch && dateRangeMatch;
    });
  }, [transfers, filters]);

  const handleOpenForm = (transfer = null) => {
    setSelectedTransfer(transfer);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedTransfer(null);
  };

  const handleSaveTransfer = (formData) => {
    let updatedTransfers;
    const parsedData = {
      ...formData,
      amount: parseFloat(formData.amount),
    };

    if (selectedTransfer) {
      updatedTransfers = transfers.map(t => (t.id === selectedTransfer.id ? { ...selectedTransfer, ...parsedData } : t));
      toast({ title: "✅ Sukses", description: "Data transfer berhasil diperbarui." });
    } else {
      const newTransfer = { ...parsedData, id: Date.now() };
      updatedTransfers = [...transfers, newTransfer];
      toast({ title: "✅ Sukses", description: "Transfer baru berhasil ditambahkan." });
    }
    saveBankTransfers(updatedTransfers);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setTransferToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedTransfers = transfers.filter(t => t.id !== transferToDelete);
    saveBankTransfers(updatedTransfers);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setTransferToDelete(null);
    toast({
      title: "🗑️ Transfer Dihapus",
      description: "Data transfer telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Transfer Bank - Sistem Akuntansi</title>
        <meta name="description" content="Kelola, tambah, edit, dan lacak semua transaksi transfer bank." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Manajemen Transfer Bank</h1>
            <p className="text-muted-foreground">Lacak semua transaksi keluar masuk antar rekening bank.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Tambah Transfer
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <BankTransfersTable
          transfers={filteredTransfers}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <TransferFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveTransfer}
        transfer={selectedTransfer}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data transfer secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default BankTransfers;