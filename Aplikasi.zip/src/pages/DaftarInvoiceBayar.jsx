import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const DaftarInvoiceBayar = () => {
  return <PlaceholderPage title="Daftar Invoice Dibayar" description="Halaman untuk daftar invoice yang telah dibayar." />;
};

export default DaftarInvoiceBayar;