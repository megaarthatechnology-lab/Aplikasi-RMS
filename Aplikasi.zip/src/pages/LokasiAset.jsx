import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const LokasiAset = () => {
  return <PlaceholderPage title="Lokasi Aset" description="Halaman untuk melacak lokasi aset." />;
};

export default LokasiAset;