import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

import SummaryCards from '@/components/recurring-transactions/dashboard/SummaryCards';
import FrequencyChart from '@/components/recurring-transactions/dashboard/FrequencyChart';
import UpcomingTransactions from '@/components/recurring-transactions/dashboard/UpcomingTransactions';
import { getTransactions } from '@/lib/recurring-transactions-api';

const RecurringTransactionsDashboard = () => {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    // This function initializes data if it doesn't exist.
    const data = getTransactions();
    setTransactions(data);
  }, []);

  return (
    <>
      <Helmet>
        <title>Dashboard Transaksi Berulang - Sistem Akuntansi</title>
        <meta name="description" content="Ringkasan visual dari semua transaksi berulang Anda." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Dashboard Transaksi Berulang</h1>
            <p className="text-muted-foreground">
              Ringkasan statistik dari semua pembayaran terjadwal Anda.
            </p>
          </div>
          <Button asChild className="bg-blue-600 hover:bg-blue-700">
            <Link to="/recurring-transactions/manage">
              Kelola Transaksi <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>

        <SummaryCards transactions={transactions} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <UpcomingTransactions transactions={transactions} />
          </div>
          <div>
            <FrequencyChart transactions={transactions} />
          </div>
        </div>

      </motion.div>
    </>
  );
};

export default RecurringTransactionsDashboard;