import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const KontrakByBuyer = () => {
  return <PlaceholderPage title="Kontrak Berdasarkan Pembeli" description="Halaman untuk melihat kontrak berdasarkan pembeli." />;
};

export default KontrakByBuyer;