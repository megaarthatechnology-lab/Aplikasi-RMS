import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Construction } from 'lucide-react';

const PlaceholderPage = ({ title, description }) => {
  return (
    <>
      <Helmet>
        <title>{title} - AkuntansiPro</title>
        <meta name="description" content={description} />
      </Helmet>
      <motion.div
        className="flex flex-col items-center justify-center h-full text-center text-white bg-gray-800/50 p-8 rounded-2xl border border-gray-700"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
      >
        <Construction className="w-24 h-24 text-purple-400 mb-6 animate-pulse" />
        <h1 className="text-4xl font-bold mb-2">{title}</h1>
        <p className="text-lg text-gray-400 max-w-md">
          Halaman ini sedang dalam tahap pengembangan. Fitur lengkap akan segera hadir!
        </p>
        <p className="text-sm text-gray-500 mt-4">
          Anda dapat meminta implementasi fitur ini pada prompt berikutnya.
        </p>
      </motion.div>
    </>
  );
};

export default PlaceholderPage;