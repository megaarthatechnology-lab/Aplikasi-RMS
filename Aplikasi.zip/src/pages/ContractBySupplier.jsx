
import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getSupplierContracts, saveSupplierContracts } from '@/lib/contract-supplier-api';
import { getDynamicStatus } from '@/lib/contract-supplier-utils';

import FilterControls from '@/components/contract-supplier/FilterControls';
import SupplierContractTable from '@/components/contract-supplier/SupplierContractTable';
import SupplierContractFormDialog from '@/components/contract-supplier/SupplierContractFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const ContractBySupplier = () => {
  const [contracts, setContracts] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    contractStatus: '',
    startDate: '',
    endDate: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedContract, setSelectedContract] = useState(null);
  const [contractToDelete, setContractToDelete] = useState(null);

  const { toast } = useToast();
  const today = new Date();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getSupplierContracts();
    setContracts(data);
  };

  const filteredContracts = useMemo(() => {
    return contracts
      .map(c => ({ ...c, dynamicStatus: getDynamicStatus(c, today) }))
      .filter(c => {
        const searchMatch = !filters.searchTerm || 
          c.supplierName.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
          c.contractNumber.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
          c.contractName.toLowerCase().includes(filters.searchTerm.toLowerCase());

        // We filter based on the original contractStatus set by user
        const statusMatch = !filters.contractStatus || c.contractStatus === filters.contractStatus;
        
        // But for display and dynamic states like "Expiring Soon", we use dynamicStatus.
        // We can also let user filter by dynamic status if needed, by changing `c.contractStatus` to `c.dynamicStatus.staticStatus`
        // For now, let's stick to user-set status for filtering.

        const contractStartDate = new Date(c.startDate);
        const filterStartDate = filters.startDate ? new Date(filters.startDate) : null;
        const filterEndDate = filters.endDate ? new Date(filters.endDate) : null;

        if (filterStartDate) filterStartDate.setHours(0, 0, 0, 0);
        if (filterEndDate) filterEndDate.setHours(23, 59, 59, 999);
        
        const dateRangeMatch = (!filterStartDate || contractStartDate >= filterStartDate) && (!filterEndDate || contractStartDate <= filterEndDate);

        return searchMatch && statusMatch && dateRangeMatch;
      });
  }, [contracts, filters, today]);

  const handleOpenForm = (contract = null) => {
    setSelectedContract(contract);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedContract(null);
  };

  const handleSaveContract = (formData) => {
    let updatedContracts;
    const parsedData = {
      ...formData,
      contractValue: parseFloat(formData.contractValue),
    };

    if (selectedContract) {
      updatedContracts = contracts.map(c => (c.id === selectedContract.id ? { ...selectedContract, ...parsedData } : c));
      toast({ title: "✅ Sukses", description: "Data kontrak supplier berhasil diperbarui." });
    } else {
      const newContract = { ...parsedData, id: Date.now() };
      updatedContracts = [...contracts, newContract];
      toast({ title: "✅ Sukses", description: "Kontrak supplier baru berhasil ditambahkan." });
    }
    saveSupplierContracts(updatedContracts);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setContractToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedContracts = contracts.filter(c => c.id !== contractToDelete);
    saveSupplierContracts(updatedContracts);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setContractToDelete(null);
    toast({
      title: "🗑️ Kontrak Dihapus",
      description: "Data kontrak supplier telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Kontrak per Supplier - Sistem Akuntansi</title>
        <meta name="description" content="Kelola dan lacak semua kontrak dengan supplier secara terpusat dan efisien." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Kontrak per Supplier</h1>
            <p className="text-muted-foreground">Lacak semua kontrak yang berjalan dengan supplier Anda.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Tambah Kontrak
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <SupplierContractTable
          contracts={filteredContracts}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <SupplierContractFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveContract}
        contract={selectedContract}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data kontrak supplier secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default ContractBySupplier;
