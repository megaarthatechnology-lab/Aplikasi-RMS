import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const PembayaranTransferBank = () => {
  return <PlaceholderPage title="Pembayaran & Transfer Bank" description="Halaman untuk mengelola pembayaran dan transfer bank." />;
};

export default PembayaranTransferBank;