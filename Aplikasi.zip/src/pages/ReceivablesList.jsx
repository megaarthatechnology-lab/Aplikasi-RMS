import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getReceivables, saveReceivables } from '@/lib/receivables-api';

import FilterControls from '@/components/receivables/FilterControls';
import ReceivablesTable from '@/components/receivables/ReceivablesTable';
import ReceivableFormDialog from '@/components/receivables/ReceivableFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const ReceivablesList = () => {
  const [receivables, setReceivables] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    status: 'all',
    minAmount: '',
    maxAmount: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedReceivable, setSelectedReceivable] = useState(null);
  const [receivableToDelete, setReceivableToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getReceivables();
    setReceivables(data);
  };

  const filteredReceivables = useMemo(() => {
    return receivables.filter(r => {
      const searchTermMatch = r.customerName.toLowerCase().includes(filters.searchTerm.toLowerCase()) || r.invoiceNumber.toLowerCase().includes(filters.searchTerm.toLowerCase());
      const statusMatch = filters.status === 'all' || r.status === filters.status;
      const minAmount = parseFloat(filters.minAmount);
      const maxAmount = parseFloat(filters.maxAmount);
      const amountMatch = (isNaN(minAmount) || r.amount >= minAmount) && (isNaN(maxAmount) || r.amount <= maxAmount);
      return searchTermMatch && statusMatch && amountMatch;
    });
  }, [receivables, filters]);

  const handleOpenForm = (receivable = null) => {
    setSelectedReceivable(receivable);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedReceivable(null);
  };

  const handleSaveReceivable = (formData) => {
    let updatedReceivables;
    const parsedData = {
      ...formData,
      amount: parseFloat(formData.amount),
    };

    if (selectedReceivable) {
      updatedReceivables = receivables.map(r => (r.id === selectedReceivable.id ? { ...selectedReceivable, ...parsedData } : r));
      toast({ title: "✅ Sukses", description: "Data piutang berhasil diperbarui." });
    } else {
      const newReceivable = { ...parsedData, id: Date.now() };
      updatedReceivables = [...receivables, newReceivable];
      toast({ title: "✅ Sukses", description: "Piutang baru berhasil ditambahkan." });
    }
    saveReceivables(updatedReceivables);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setReceivableToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedReceivables = receivables.filter(r => r.id !== receivableToDelete);
    saveReceivables(updatedReceivables);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setReceivableToDelete(null);
    toast({
      title: "🗑️ Piutang Dihapus",
      description: "Data piutang telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Manajemen Piutang - Sistem Akuntansi</title>
        <meta name="description" content="Kelola, tambah, edit, dan lacak semua piutang perusahaan." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Manajemen Piutang</h1>
            <p className="text-muted-foreground">Lacak semua tagihan dan pembayaran dari pelanggan Anda.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Tambah Piutang
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <ReceivablesTable
          receivables={filteredReceivables}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <ReceivableFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveReceivable}
        receivable={selectedReceivable}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data piutang secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default ReceivablesList;