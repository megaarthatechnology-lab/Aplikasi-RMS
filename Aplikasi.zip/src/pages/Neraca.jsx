import React from 'react';
import PlaceholderPage from './PlaceholderPage';

const Neraca = () => {
  return <PlaceholderPage title="Neraca" description="Halaman untuk melihat neraca keuangan." />;
};

export default Neraca;