import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import { getDebts, saveDebts } from '@/lib/debt-api';
import { getDebtSchedules, saveDebtSchedules, generateAmortizationSchedule } from '@/lib/debt-schedule-api';

import ScheduleFilterControls from '@/components/debt-schedule/ScheduleFilterControls';
import UpcomingPayments from '@/components/debt-schedule/UpcomingPayments';
import AmortizationTable from '@/components/debt-schedule/AmortizationTable';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { AlertCircle } from 'lucide-react';

const DebtSchedule = () => {
  const [debts, setDebts] = useState([]);
  const [schedules, setSchedules] = useState({});
  const [selectedDebtId, setSelectedDebtId] = useState('all');
  const { toast } = useToast();

  useEffect(() => {
    const allDebts = getDebts().filter(d => d.status === 'active' && d.interestRate > 0);
    setDebts(allDebts);

    const allSchedules = getDebtSchedules();
    let schedulesHaveChanged = false;
    const updatedSchedules = { ...allSchedules };

    allDebts.forEach(debt => {
      if (!allSchedules[debt.id]) {
        updatedSchedules[debt.id] = generateAmortizationSchedule(debt);
        schedulesHaveChanged = true;
      }
    });

    if (schedulesHaveChanged) {
      saveDebtSchedules(updatedSchedules);
    }
    
    setSchedules(updatedSchedules);

    if (allDebts.length > 0) {
      setSelectedDebtId(allDebts[0].id.toString());
    } else {
        setSelectedDebtId('none');
    }

  }, []);

  const handleMarkAsPaid = (debtId, paymentNumber) => {
    const updatedSchedules = { ...schedules };
    const schedule = updatedSchedules[debtId];
    const payment = schedule.find(p => p.paymentNumber === paymentNumber);

    if (payment) {
      payment.status = 'paid';
      saveDebtSchedules(updatedSchedules);
      setSchedules(updatedSchedules);
      toast({
        title: "✅ Pembayaran Dicatat",
        description: `Pembayaran ke-${paymentNumber} untuk hutang telah ditandai lunas.`,
      });
    }
  };

  const selectedSchedule = useMemo(() => {
    return schedules[selectedDebtId] || [];
  }, [schedules, selectedDebtId]);
  
  const selectedDebt = useMemo(() => {
      return debts.find(d => d.id.toString() === selectedDebtId);
  }, [debts, selectedDebtId]);

  return (
    <>
      <Helmet>
        <title>Jadwal Pembayaran Hutang - Sistem Akuntansi</title>
        <meta name="description" content="Lihat jadwal pembayaran hutang, lacak pembayaran, dan lihat tanggal jatuh tempo." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Jadwal Pembayaran Hutang</h1>
            <p className="text-muted-foreground">Lacak semua jadwal pembayaran hutang berbunga Anda.</p>
          </div>
        </div>

        <UpcomingPayments schedules={schedules} debts={debts} />

        <Card className="glass-effect">
            <CardHeader>
                <CardTitle>Detail Jadwal Amortisasi</CardTitle>
                <CardDescription>Pilih hutang untuk melihat jadwal pembayaran lengkapnya.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <ScheduleFilterControls
                    debts={debts}
                    selectedDebtId={selectedDebtId}
                    setSelectedDebtId={setSelectedDebtId}
                />
                
                {selectedDebtId !== 'none' && selectedDebtId !== 'all' ? (
                     <AmortizationTable
                        schedule={selectedSchedule}
                        debt={selectedDebt}
                        onMarkAsPaid={handleMarkAsPaid}
                    />
                ) : (
                    <div className="text-center py-12 text-slate-400 flex flex-col items-center gap-4">
                        <AlertCircle className="w-12 h-12 text-blue-500" />
                        <p className="font-semibold text-lg">Tidak Ada Hutang Aktif Berbunga</p>
                        <p className="max-w-md">Fitur ini hanya menampilkan jadwal untuk hutang yang berstatus 'aktif' dan memiliki suku bunga lebih dari 0%. Silakan periksa kembali data di menu Manajemen Hutang.</p>
                    </div>
                )}
            </CardContent>
        </Card>

      </motion.div>
    </>
  );
};

export default DebtSchedule;