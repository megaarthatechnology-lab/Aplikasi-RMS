import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Calendar, Download, Printer, Filter, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const IncomeStatement = () => {
  const { toast } = useToast();

  const handleAction = (action) => {
    toast({
      title: `📊 ${action}`,
      description: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀"
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const incomeData = {
    revenue: {
      title: 'PENDAPATAN',
      items: [
        { name: 'Pendapatan Jasa Konstruksi', amount: 2450000000, percentage: 85 },
        { name: 'Pendapatan Jasa Konsultasi', amount: 350000000, percentage: 12 },
        { name: 'Pendapatan Lain-lain', amount: 100000000, percentage: 3 }
      ],
      total: 2900000000
    },
    expenses: {
      title: 'BEBAN OPERASIONAL',
      items: [
        { name: 'Beban Gaji dan Tunjangan', amount: 800000000 },
        { name: 'Beban Material', amount: 650000000 },
        { name: 'Beban Peralatan', amount: 200000000 },
        { name: 'Beban Transportasi', amount: 150000000 },
        { name: 'Beban Administrasi', amount: 100000000 },
        { name: 'Beban Penyusutan', amount: 80000000 },
        { name: 'Beban Lain-lain', amount: 70000000 }
      ],
      total: 2050000000
    },
    otherIncome: {
      title: 'PENDAPATAN LAIN-LAIN',
      items: [
        { name: 'Pendapatan Bunga', amount: 25000000 },
        { name: 'Keuntungan Penjualan Aset', amount: 15000000 }
      ],
      total: 40000000
    },
    otherExpenses: {
      title: 'BEBAN LAIN-LAIN',
      items: [
        { name: 'Beban Bunga', amount: 30000000 },
        { name: 'Kerugian Selisih Kurs', amount: 10000000 }
      ],
      total: 40000000
    }
  };

  const grossProfit = incomeData.revenue.total - incomeData.expenses.total;
  const netIncome = grossProfit + incomeData.otherIncome.total - incomeData.otherExpenses.total;

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  return (
    <>
      <Helmet>
        <title>Laporan Laba Rugi - Sistem Akuntansi Profesional</title>
        <meta name="description" content="Laporan laba rugi komprehensif dengan analisis pendapatan, beban, dan profitabilitas perusahaan." />
        <style type="text/css">{`
            @media print {
              body * {
                visibility: hidden;
              }
              .printable-area, .printable-area * {
                visibility: visible;
              }
              .printable-area {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
              }
              .no-print {
                display: none;
              }
            }
        `}</style>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between no-print"
        >
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Laporan Laba Rugi</h1>
            <p className="text-slate-400">Analisis kinerja keuangan dan profitabilitas perusahaan</p>
          </div>
          <div className="flex space-x-2 mt-4 md:mt-0">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-800 border-slate-700 text-white">
                <DropdownMenuItem onSelect={() => handleAction('Export to PDF')}>Export ke PDF</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleAction('Export to Excel')}>Export ke Excel</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button 
              onClick={handlePrint}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
            >
              <Printer className="h-4 w-4 mr-2" />
              Cetak
            </Button>
          </div>
        </motion.div>

        {/* Period Selection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass-effect rounded-xl p-6 no-print"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Periode</label>
              <Button 
                variant="outline"
                onClick={() => handleAction('Pilih Periode')}
                className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 justify-start"
              >
                <Calendar className="h-4 w-4 mr-2" />
                Januari 2024
              </Button>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Perbandingan</label>
              <Button 
                variant="outline"
                onClick={() => handleAction('Bandingkan Periode')}
                className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 justify-start"
              >
                <Filter className="h-4 w-4 mr-2" />
                Bulan Sebelumnya
              </Button>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Format</label>
              <select className="w-full bg-slate-700/50 border border-slate-600 rounded-lg text-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option>Format Standar</option>
                <option>Format Komparatif</option>
                <option>Format Persentase</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Summary Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-6 no-print"
        >
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Total Pendapatan</h3>
            <p className="text-2xl font-bold text-green-400">{formatCurrency(incomeData.revenue.total)}</p>
            <div className="flex items-center justify-center mt-2 text-green-400">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm">+12.5%</span>
            </div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Total Beban</h3>
            <p className="text-2xl font-bold text-red-400">{formatCurrency(incomeData.expenses.total)}</p>
            <div className="flex items-center justify-center mt-2 text-red-400">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm">+8.2%</span>
            </div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Laba Kotor</h3>
            <p className="text-2xl font-bold text-blue-400">{formatCurrency(grossProfit)}</p>
            <div className="flex items-center justify-center mt-2 text-blue-400">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm">+18.3%</span>
            </div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <h3 className="text-lg font-semibold text-white mb-2">Laba Bersih</h3>
            <p className="text-2xl font-bold gradient-text">{formatCurrency(netIncome)}</p>
            <div className="flex items-center justify-center mt-2 text-green-400">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm">+15.7%</span>
            </div>
          </div>
        </motion.div>

        {/* Income Statement */}
        <div className="printable-area">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="glass-effect rounded-xl overflow-hidden"
          >
            <div className="p-6 border-b border-slate-700/50">
              <h2 className="text-xl font-semibold text-white text-center">
                PT. KONSTRUKSI INDONESIA
              </h2>
              <p className="text-slate-400 text-center mt-1">LAPORAN LABA RUGI</p>
              <p className="text-slate-400 text-center">Untuk Periode yang Berakhir 31 Januari 2024</p>
            </div>

            <div className="p-6 space-y-6">
              {/* Revenue Section */}
              <div>
                <h3 className="text-lg font-semibold text-green-400 mb-4">{incomeData.revenue.title}</h3>
                {incomeData.revenue.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30">
                    <span className="text-slate-300">{item.name}</span>
                    <div className="text-right">
                      <span className="text-white font-semibold">{formatCurrency(item.amount)}</span>
                      {item.percentage && (
                        <div className="text-xs text-slate-400">({item.percentage}%)</div>
                      )}
                    </div>
                  </div>
                ))}
                <div className="flex justify-between items-center py-3 border-t-2 border-green-500/50 mt-2">
                  <span className="text-green-400 font-semibold">TOTAL PENDAPATAN</span>
                  <span className="text-green-400 font-bold text-lg">{formatCurrency(incomeData.revenue.total)}</span>
                </div>
              </div>

              {/* Expenses Section */}
              <div>
                <h3 className="text-lg font-semibold text-red-400 mb-4">{incomeData.expenses.title}</h3>
                {incomeData.expenses.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30">
                    <span className="text-slate-300">{item.name}</span>
                    <span className="text-white font-semibold">{formatCurrency(item.amount)}</span>
                  </div>
                ))}
                <div className="flex justify-between items-center py-3 border-t-2 border-red-500/50 mt-2">
                  <span className="text-red-400 font-semibold">TOTAL BEBAN OPERASIONAL</span>
                  <span className="text-red-400 font-bold text-lg">({formatCurrency(incomeData.expenses.total)})</span>
                </div>
              </div>

              {/* Gross Profit */}
              <div className="bg-slate-800/50 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="text-blue-400 font-semibold text-lg">LABA KOTOR</span>
                  <span className="text-blue-400 font-bold text-xl">{formatCurrency(grossProfit)}</span>
                </div>
              </div>

              {/* Other Income */}
              <div>
                <h3 className="text-lg font-semibold text-green-400 mb-4">{incomeData.otherIncome.title}</h3>
                {incomeData.otherIncome.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30">
                    <span className="text-slate-300">{item.name}</span>
                    <span className="text-white font-semibold">{formatCurrency(item.amount)}</span>
                  </div>
                ))}
                <div className="flex justify-between items-center py-3 border-t-2 border-green-500/50 mt-2">
                  <span className="text-green-400 font-semibold">TOTAL PENDAPATAN LAIN-LAIN</span>
                  <span className="text-green-400 font-bold">{formatCurrency(incomeData.otherIncome.total)}</span>
                </div>
              </div>

              {/* Other Expenses */}
              <div>
                <h3 className="text-lg font-semibold text-red-400 mb-4">{incomeData.otherExpenses.title}</h3>
                {incomeData.otherExpenses.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30">
                    <span className="text-slate-300">{item.name}</span>
                    <span className="text-white font-semibold">{formatCurrency(item.amount)}</span>
                  </div>
                ))}
                <div className="flex justify-between items-center py-3 border-t-2 border-red-500/50 mt-2">
                  <span className="text-red-400 font-semibold">TOTAL BEBAN LAIN-LAIN</span>
                  <span className="text-red-400 font-bold">({formatCurrency(incomeData.otherExpenses.total)})</span>
                </div>
              </div>

              {/* Net Income */}
              <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-lg p-6 border border-blue-500/30">
                <div className="flex justify-between items-center">
                  <span className="text-white font-bold text-xl">LABA BERSIH</span>
                  <span className="text-2xl font-bold gradient-text">{formatCurrency(netIncome)}</span>
                </div>
                <div className="mt-2 text-center">
                  <span className="text-slate-400 text-sm">
                    Margin Laba Bersih: {((netIncome / incomeData.revenue.total) * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default IncomeStatement;