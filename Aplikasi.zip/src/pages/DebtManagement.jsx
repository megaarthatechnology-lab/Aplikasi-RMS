import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getDebts, saveDebts } from '@/lib/debt-api';

import FilterControls from '@/components/debt-management/FilterControls';
import DebtTable from '@/components/debt-management/DebtTable';
import DebtFormDialog from '@/components/debt-management/DebtFormDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const DebtManagement = () => {
  const [debts, setDebts] = useState([]);
  const [filters, setFilters] = useState({
    searchTerm: '',
    status: 'all',
    minAmount: '',
    maxAmount: '',
  });
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedDebt, setSelectedDebt] = useState(null);
  const [debtToDelete, setDebtToDelete] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    reloadData();
  }, []);

  const reloadData = () => {
    const data = getDebts();
    setDebts(data);
  };

  const filteredDebts = useMemo(() => {
    return debts.filter(debt => {
      const searchTermMatch = debt.creditor.toLowerCase().includes(filters.searchTerm.toLowerCase());
      const statusMatch = filters.status === 'all' || debt.status === filters.status;
      const minAmount = parseFloat(filters.minAmount);
      const maxAmount = parseFloat(filters.maxAmount);
      const amountMatch = (isNaN(minAmount) || debt.amount >= minAmount) && (isNaN(maxAmount) || debt.amount <= maxAmount);
      return searchTermMatch && statusMatch && amountMatch;
    });
  }, [debts, filters]);

  const handleOpenForm = (debt = null) => {
    setSelectedDebt(debt);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setSelectedDebt(null);
  };

  const handleSaveDebt = (formData) => {
    let updatedDebts;
    const parsedData = {
      ...formData,
      amount: parseFloat(formData.amount),
      interestRate: parseFloat(formData.interestRate),
    };

    if (selectedDebt) {
      updatedDebts = debts.map(d => (d.id === selectedDebt.id ? { ...selectedDebt, ...parsedData } : d));
      toast({ title: "✅ Sukses", description: "Data hutang berhasil diperbarui." });
    } else {
      const newDebt = { ...parsedData, id: Date.now() };
      updatedDebts = [...debts, newDebt];
      toast({ title: "✅ Sukses", description: "Hutang baru berhasil ditambahkan." });
    }
    saveDebts(updatedDebts);
    reloadData();
    handleCloseForm();
  };

  const handleDeleteRequest = (id) => {
    setDebtToDelete(id);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    const updatedDebts = debts.filter(d => d.id !== debtToDelete);
    saveDebts(updatedDebts);
    reloadData();
    setIsDeleteConfirmOpen(false);
    setDebtToDelete(null);
    toast({
      title: "🗑️ Hutang Dihapus",
      description: "Data hutang telah berhasil dihapus.",
      variant: "destructive",
    });
  };

  return (
    <>
      <Helmet>
        <title>Manajemen Hutang - Sistem Akuntansi</title>
        <meta name="description" content="Kelola, tambah, edit, dan lacak semua hutang perusahaan." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Manajemen Hutang</h1>
            <p className="text-muted-foreground">Lacak dan kelola semua kewajiban hutang Anda di satu tempat.</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="bg-blue-600 hover:bg-blue-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Tambah Hutang
          </Button>
        </div>

        <FilterControls filters={filters} setFilters={setFilters} />

        <DebtTable
          debts={filteredDebts}
          onEdit={handleOpenForm}
          onDelete={handleDeleteRequest}
        />
      </motion.div>

      <DebtFormDialog
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveDebt}
        debt={selectedDebt}
      />

      <AlertDialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus data hutang secara permanen. Anda tidak dapat membatalkan tindakan ini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Ya, Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default DebtManagement;