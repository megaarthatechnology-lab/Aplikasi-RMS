import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Layout from '@/components/Layout';
import Dashboard from '@/pages/Dashboard';
import ChartOfAccounts from '@/pages/ChartOfAccounts';
import Journal from '@/pages/Journal';
import GeneralLedger from '@/pages/GeneralLedger';
import IncomeStatement from '@/pages/IncomeStatement';
import EquityStatement from '@/pages/EquityStatement';
import BalanceSheet from '@/pages/BalanceSheet';
import CashFlow from '@/pages/CashFlow';
import FinancialNotes from '@/pages/FinancialNotes';
import ProjectList from '@/pages/ProjectList';
import ProjectProgress from '@/pages/ProjectProgress';
import EmployeeList from '@/pages/EmployeeList';
import EmployeeRecap from '@/pages/EmployeeRecap';
import EquipmentMutation from '@/pages/EquipmentMutation';
import MaterialUsage from '@/pages/MaterialUsage';
import RawMaterialUsage from '@/pages/RawMaterialUsage';
import OilFuelUsage from '@/pages/OilFuelUsage';
import SparepartUsage from '@/pages/SparepartUsage';
import RecurringTransactions from '@/pages/RecurringTransactions';
import RecurringTransactionsManage from '@/pages/RecurringTransactionsManage';
import DebtManagement from '@/pages/DebtManagement';
import DebtDocuments from '@/pages/DebtDocuments';
import DebtSchedule from '@/pages/DebtSchedule';
import ReceivablesList from '@/pages/ReceivablesList';
import InvoiceList from '@/pages/InvoiceList';
import PaidInvoices from '@/pages/PaidInvoices';
import Taxation from '@/pages/Taxation';
import PrepaidTax from '@/pages/PrepaidTax';
import Payments from '@/pages/Payments';
import BankTransfers from '@/pages/BankTransfers';
import AssetManagement from '@/pages/AssetManagement';
import AssetList from '@/pages/AssetList';
import AssetLocation from '@/pages/AssetLocation';
import MaintenanceSchedule from '@/pages/MaintenanceSchedule';
import AssetDocuments from '@/pages/AssetDocuments';
import ContractList from '@/pages/ContractList';
import ContractBySupplier from '@/pages/ContractBySupplier';
import ContractByItem from '@/pages/ContractByItem';
import ContractByBuyer from '@/pages/ContractByBuyer';
import AdminPanel from '@/pages/AdminPanel';
import Settings from '@/pages/Settings';

import GlobalSearchProvider from '@/components/search/GlobalSearchProvider';
import { AppearanceProvider } from '@/components/settings/AppearanceProvider';

function App() {
  return (
    <>
      <Helmet>
        <title>Sistem Akuntansi Profesional - Dashboard Keuangan</title>
        <meta name="description" content="Sistem akuntansi lengkap dengan fitur manajemen keuangan, laporan, proyek, dan aset untuk bisnis modern." />
      </Helmet>
      <AppearanceProvider>
        <GlobalSearchProvider>
          <Layout>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/chart-of-accounts" element={<ChartOfAccounts />} />
              <Route path="/journal" element={<Journal />} />
              <Route path="/general-ledger" element={<GeneralLedger />} />
              <Route path="/income-statement" element={<IncomeStatement />} />
              <Route path="/equity-statement" element={<EquityStatement />} />
              <Route path="/balance-sheet" element={<BalanceSheet />} />
              <Route path="/cash-flow" element={<CashFlow />} />
              <Route path="/financial-notes" element={<FinancialNotes />} />
              <Route path="/project-list" element={<ProjectList />} />
              <Route path="/project-progress" element={<ProjectProgress />} />
              <Route path="/employee-list" element={<EmployeeList />} />
              <Route path="/employee-recap" element={<EmployeeRecap />} />
              <Route path="/equipment-mutation" element={<EquipmentMutation />} />
              <Route path="/material-usage" element={<MaterialUsage />} />
              <Route path="/raw-material-usage" element={<RawMaterialUsage />} />
              <Route path="/oil-fuel-usage" element={<OilFuelUsage />} />
              <Route path="/sparepart-usage" element={<SparepartUsage />} />
              <Route path="/recurring-transactions" element={<RecurringTransactions />} />
              <Route path="/recurring-transactions/manage" element={<RecurringTransactionsManage />} />
              <Route path="/debt-management" element={<DebtManagement />} />
              <Route path="/debt-documents" element={<DebtDocuments />} />
              <Route path="/debt-schedule" element={<DebtSchedule />} />
              <Route path="/receivables-list" element={<ReceivablesList />} />
              <Route path="/invoice-list" element={<InvoiceList />} />
              <Route path="/paid-invoices" element={<PaidInvoices />} />
              <Route path="/taxation" element={<Taxation />} />
              <Route path="/prepaid-tax" element={<PrepaidTax />} />
              <Route path="/payments" element={<Payments />} />
              <Route path="/bank-transfers" element={<BankTransfers />} />
              <Route path="/asset-management" element={<AssetManagement />} />
              <Route path="/asset-list" element={<AssetList />} />
              <Route path="/asset-location" element={<AssetLocation />} />
              <Route path="/maintenance-schedule" element={<MaintenanceSchedule />} />
              <Route path="/asset-documents" element={<AssetDocuments />} />
              <Route path="/contract-list" element={<ContractList />} />
              <Route path="/contract-by-supplier" element={<ContractBySupplier />} />
              <Route path="/contract-by-item" element={<ContractByItem />} />
              <Route path="/contract-by-buyer" element={<ContractByBuyer />} />
              <Route path="/admin-panel" element={<AdminPanel />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </Layout>
        </GlobalSearchProvider>
      </AppearanceProvider>
    </>
  );
}

export default App;