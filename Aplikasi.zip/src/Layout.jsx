import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import { useAppearance } from '@/components/settings/AppearanceProvider';

const Layout = ({ children, notifications, setNotifications }) => {
  const { sidebarLayout } = useAppearance();
  const isCompact = sidebarLayout === 'compact';
  
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const sidebarWidth = isCompact ? 80 : 320;

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: sidebarWidth }}
            exit={{ width: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="hidden lg:block flex-shrink-0"
          >
            <Sidebar />
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Mobile Sidebar */}
       <AnimatePresence>
        {sidebarOpen && (
           <motion.div
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="fixed inset-y-0 left-0 z-50 w-80 lg:hidden"
          >
            <Sidebar onClose={() => setSidebarOpen(false)} />
          </motion.div>
        )}
       </AnimatePresence>
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          onMenuClick={() => setSidebarOpen(!sidebarOpen)}
          sidebarOpen={sidebarOpen}
          notifications={notifications}
          setNotifications={setNotifications}
        />
        
        <main className="flex-1 overflow-auto bg-background p-6">
          <motion.div
            key={children.type.name} // Re-trigger animation on page change
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-7xl mx-auto"
          >
            {children}
          </motion.div>
        </main>
      </div>
    </div>
  );
};

export default Layout;